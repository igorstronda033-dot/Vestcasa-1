import QRCode from 'qrcode';

// Código Copia e Cola Oficial Unificado para TODAS as Scooters
export const OFFICIAL_UNIFIED_PIX_PAYLOAD =
  '00020126360014br.gov.bcb.pix0114649391660001505204000053039865802BR592564.939.166 SANDRO ROGERIO6008MONGAGUA62070503***6304051D';

// Chaves e Códigos Copia e Cola Oficiais por modelo
export const PIX_MU04_PAYLOAD = OFFICIAL_UNIFIED_PIX_PAYLOAD;
export const PIX_MU02_PAYLOAD = OFFICIAL_UNIFIED_PIX_PAYLOAD;
export const PIX_MU03_PAYLOAD = OFFICIAL_UNIFIED_PIX_PAYLOAD;
export const PIX_MU09_PAYLOAD = OFFICIAL_UNIFIED_PIX_PAYLOAD;
export const PIX_V20_PRO_PAYLOAD = OFFICIAL_UNIFIED_PIX_PAYLOAD;

export const PIX_MU04_BENEFICIARY = {
  name: '64.939.166 SANDRO ROGERIO',
  razaoSocial: '64.939.166 SANDRO ROGERIO',
  cnpj: '64.939.166/0001-50',
  city: 'MONGAGUA - SP',
  key: '64.939.166/0001-50',
};

/**
 * Verifica se um produto corresponde ao modelo MU04
 */
export function isMu04Product(productName?: string): boolean {
  if (!productName) return false;
  const normalized = productName.toUpperCase().replace(/[\s-_]/g, '');
  return normalized.includes('MU04') || normalized.includes('MU4');
}

/**
 * Verifica se um produto corresponde ao modelo MU02
 */
export function isMu02Product(productName?: string): boolean {
  if (!productName) return false;
  const normalized = productName.toUpperCase().replace(/[\s-_]/g, '');
  return normalized.includes('MU02') || normalized.includes('MU2');
}

/**
 * Verifica se um produto corresponde ao modelo MU03
 */
export function isMu03Product(productName?: string): boolean {
  if (!productName) return false;
  const normalized = productName.toUpperCase().replace(/[\s-_]/g, '');
  return normalized.includes('MU03') || normalized.includes('MU3');
}

/**
 * Verifica se um produto corresponde ao modelo MU09
 */
export function isMu09Product(productName?: string): boolean {
  if (!productName) return false;
  const normalized = productName.toUpperCase().replace(/[\s-_]/g, '');
  return normalized.includes('MU09') || normalized.includes('MU9');
}

function crc16(str: string): string {
  let crc = 0xffff;
  const strlen = str.length;
  for (let c = 0; c < strlen; c++) {
    crc ^= str.charCodeAt(c) << 8;
    for (let i = 0; i < 8; i++) {
      if ((crc & 0x8000) !== 0) {
        crc = (crc << 1) ^ 0x1021;
      } else {
        crc = crc << 1;
      }
    }
  }
  let hex = (crc & 0xffff).toString(16).toUpperCase();
  if (hex.length === 3) hex = '0' + hex;
  if (hex.length === 2) hex = '00' + hex;
  if (hex.length === 1) hex = '000' + hex;
  return hex;
}

function emvField(id: string, value: string): string {
  const len = value.length.toString().padStart(2, '0');
  return `${id}${len}${value}`;
}

export function generatePixPayload(params: {
  pixKey: string;
  merchantName: string;
  merchantCity: string;
  amount: number;
  txId: string;
}): string {
  const { pixKey, merchantName, merchantCity, amount, txId } = params;

  // Merchant Account Info
  const gui = emvField('00', 'br.gov.bcb.pix');
  const key = emvField('01', pixKey);
  const mai = emvField('26', `${gui}${key}`);

  // Formatting amount
  const formattedAmount = amount > 0 ? amount.toFixed(2) : '0.00';

  // Additional Data
  const cleanTxId = txId.replace(/[^A-Za-z0-9]/g, '').slice(0, 25) || 'PEDIDO';
  const reference = emvField('05', cleanTxId);
  const additionalData = emvField('62', reference);

  const cleanMerchant = merchantName.slice(0, 25).normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const cleanCity = merchantCity.slice(0, 15).normalize('NFD').replace(/[\u0300-\u036f]/g, '');

  const payload =
    emvField('00', '01') +
    emvField('01', '12') +
    mai +
    emvField('52', '0000') +
    emvField('53', '986') +
    emvField('54', formattedAmount) +
    emvField('58', 'BR') +
    emvField('59', cleanMerchant) +
    emvField('60', cleanCity) +
    additionalData +
    '6304';

  const checksum = crc16(payload);
  return `${payload}${checksum}`;
}

export async function generateQrCodeDataUrl(pixPayload: string): Promise<string> {
  try {
    return await QRCode.toDataURL(pixPayload, {
      margin: 2,
      width: 320,
      color: {
        dark: '#005c2d',
        light: '#ffffff',
      },
    });
  } catch (err) {
    console.error('Failed to generate QR Code:', err);
    return '';
  }
}
