import { createClient, SupabaseClient } from '@supabase/supabase-js';

/**
 * Normaliza a URL do Supabase, removendo endpoints REST (/rest/v1/) e barras extras
 * O SDK @supabase/supabase-js requer a URL raiz do projeto (ex: https://xyz.supabase.co)
 */
export const normalizeSupabaseUrl = (url: string): string => {
  if (!url) return '';
  let clean = url.trim();
  // Remove /rest/v1/ ou /rest/v1 e barras finais
  clean = clean.replace(/\/rest\/v1\/?$/i, '').replace(/\/+$/, '');
  return clean;
};

// Credenciais padrão fornecidas pelo usuário para integração direta
const DEFAULT_SUPABASE_URL = 'https://aosvgcsjhqsszightzjn.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable__lYwssdJHAXSycLzCQdMog_XaMJHSqU';

// Variáveis de ambiente (Vite / Netlify / Produção)
const envUrl = ((import.meta as any).env?.VITE_SUPABASE_URL || '') as string;
const envAnonKey = ((import.meta as any).env?.VITE_SUPABASE_ANON_KEY || '') as string;

// Suporte a credenciais salvas em tempo de execução no localStorage pelo painel de admin
const storedUrl = typeof window !== 'undefined' ? localStorage.getItem('supabase_custom_url') || '' : '';
const storedAnonKey = typeof window !== 'undefined' ? localStorage.getItem('supabase_custom_anon_key') || '' : '';

// URL e Chave finais com prioridade e normalização
const rawSelectedUrl = storedUrl || envUrl || DEFAULT_SUPABASE_URL;
const rawSelectedKey = storedAnonKey || envAnonKey || DEFAULT_SUPABASE_ANON_KEY;

export const SUPABASE_URL = normalizeSupabaseUrl(rawSelectedUrl);
export const SUPABASE_ANON_KEY = rawSelectedKey.trim();

export const isSupabaseConfigured = (): boolean => {
  return Boolean(
    SUPABASE_URL && 
    SUPABASE_ANON_KEY && 
    SUPABASE_URL.startsWith('https://') &&
    SUPABASE_URL.includes('.supabase.co') &&
    SUPABASE_ANON_KEY.length >= 20
  );
};

export const saveCustomSupabaseConfig = (url: string, anonKey: string) => {
  localStorage.setItem('supabase_custom_url', normalizeSupabaseUrl(url));
  localStorage.setItem('supabase_custom_anon_key', anonKey.trim());
  window.location.reload();
};

export const clearCustomSupabaseConfig = () => {
  localStorage.removeItem('supabase_custom_url');
  localStorage.removeItem('supabase_custom_anon_key');
  window.location.reload();
};

// Cliente de fallback seguro se não configurado
const fallbackUrl = 'https://placeholder.supabase.co';
const fallbackKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e30.placeholder';

export const supabase: SupabaseClient = createClient(
  isSupabaseConfigured() ? SUPABASE_URL : fallbackUrl,
  isSupabaseConfigured() ? SUPABASE_ANON_KEY : fallbackKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    }
  }
);
