export const SUPABASE_SQL_SCRIPT = `-- =======================================================
-- SISTEMA DE PEDIDOS E SCOOTERS VESTCASA - SUPABASE SQL COMPLETO & BLINDADO
-- Execute este script no menu: Supabase Dashboard > SQL Editor > New query > Run
-- =======================================================

-- 1. EXTENSÃO PARA GERAÇÃO DE UUID
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. TABELA PRINCIPAL 'pedidos'
CREATE TABLE IF NOT EXISTS public.pedidos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    codigo TEXT UNIQUE NOT NULL,
    nome_cliente TEXT NOT NULL,
    cpf TEXT,
    produto TEXT NOT NULL,
    cor TEXT,
    valor NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    observacao TEXT,
    status_pagamento TEXT NOT NULL DEFAULT 'Pendente' 
        CHECK (status_pagamento IN ('Pendente', 'Cliente informou pagamento', 'Pago', 'Cancelado')),
    imagem_url TEXT,
    itens JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.pedidos ADD COLUMN IF NOT EXISTS imagem_url TEXT;
ALTER TABLE public.pedidos ADD COLUMN IF NOT EXISTS itens JSONB;

-- 3. ÍNDICES DE BUSCA RÁPIDA
CREATE INDEX IF NOT EXISTS idx_pedidos_codigo ON public.pedidos(codigo);
CREATE INDEX IF NOT EXISTS idx_pedidos_status ON public.pedidos(status_pagamento);
CREATE INDEX IF NOT EXISTS idx_pedidos_created_at ON public.pedidos(created_at DESC);

-- 4. TABELA DE CONFIGURAÇÕES DO SISTEMA (CÓDIGO ADMIN BLINDADO CONTRA LEITURA EXTERNA)
CREATE TABLE IF NOT EXISTS public.configuracoes (
    chave TEXT PRIMARY KEY,
    valor TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

INSERT INTO public.configuracoes (chave, valor)
VALUES ('codigo_admin', 'ADMIN2026@i')
ON CONFLICT (chave) DO UPDATE SET valor = EXCLUDED.valor;

-- 5. TRIGGER PARA ATUALIZAÇÃO AUTOMÁTICA DE 'updated_at'
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_pedidos_updated_at ON public.pedidos;
CREATE TRIGGER tr_pedidos_updated_at
    BEFORE UPDATE ON public.pedidos
    FOR EACH ROW
    EXECUTE PROCEDURE public.handle_updated_at();

-- 6. TABELA DE PRODUTOS & ESTOQUE
CREATE TABLE IF NOT EXISTS public.produtos (
    id TEXT PRIMARY KEY,
    nome TEXT NOT NULL,
    preco NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    estoque INTEGER NOT NULL DEFAULT 15,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

INSERT INTO public.produtos (id, nome, preco, estoque) VALUES
    ('mu02', 'Scooter Elétrica MU02 350W', 1990.00, 15),
    ('mu03', 'Scooter Elétrica MU03 500W', 2390.00, 12),
    ('mu09', 'Moto Elétrica MU09 350W', 1990.00, 10),
    ('mu04', 'Triciclo Elétrico MU04 600W', 3899.00, 8)
ON CONFLICT (id) DO NOTHING;

-- 7. TABELA RELACIONAL DE ITENS DO PEDIDO
CREATE TABLE IF NOT EXISTS public.itens_pedido (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pedido_id UUID REFERENCES public.pedidos(id) ON DELETE CASCADE,
    id_produto TEXT NOT NULL,
    nome_produto TEXT NOT NULL,
    preco_unitario NUMERIC(10, 2) NOT NULL,
    quantidade INTEGER NOT NULL DEFAULT 1,
    subtotal NUMERIC(10, 2) NOT NULL,
    cor TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- =======================================================
-- FUNÇÕES DE SEGURANÇA (SECURITY DEFINER)
-- Operam com validação segura sem expor credenciais ao cliente
-- =======================================================

-- 8. FUNÇÃO RPC PARA VALIDAR CÓDIGO ADMINISTRATIVO
-- Retorna estritamente true ou false. O código NUNCA é retornado ao cliente.
CREATE OR REPLACE FUNCTION public.validar_codigo_admin(codigo_digitado TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    codigo_correto TEXT;
BEGIN
    SELECT valor INTO codigo_correto FROM public.configuracoes WHERE chave = 'codigo_admin' LIMIT 1;
    IF codigo_correto IS NULL THEN
        codigo_correto := 'ADMIN2026@i';
    END IF;
    RETURN TRIM(codigo_digitado) = TRIM(codigo_correto) OR UPPER(TRIM(codigo_digitado)) = UPPER(TRIM(codigo_correto));
END;
$$;

-- 9. FUNÇÃO PARA ALTERAÇÃO SEGURA DO CÓDIGO ADMINISTRATIVO
CREATE OR REPLACE FUNCTION public.admin_alterar_codigo(p_codigo_atual TEXT, p_novo_codigo TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT public.validar_codigo_admin(p_codigo_atual) THEN
        RAISE EXCEPTION 'Acesso negado: Código administrativo atual incorreto.';
    END IF;
    
    IF length(trim(p_novo_codigo)) < 4 THEN
        RAISE EXCEPTION 'O novo código deve ter no mínimo 4 caracteres.';
    END IF;

    UPDATE public.configuracoes
    SET valor = trim(p_novo_codigo), updated_at = timezone('utc'::text, now())
    WHERE chave = 'codigo_admin';

    RETURN TRUE;
END;
$$;

-- 10. FUNÇÃO PARA ATUALIZAÇÃO SEGURA DO STATUS DO PEDIDO
CREATE OR REPLACE FUNCTION public.admin_atualizar_status_pedido(
    p_admin_code TEXT,
    p_pedido_id UUID,
    p_novo_status TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT public.validar_codigo_admin(p_admin_code) THEN
        RAISE EXCEPTION 'Acesso negado: Código administrativo inválido.';
    END IF;

    IF p_novo_status NOT IN ('Pendente', 'Cliente informou pagamento', 'Pago', 'Cancelado') THEN
        RAISE EXCEPTION 'Status inválido.';
    END IF;

    UPDATE public.pedidos
    SET status_pagamento = p_novo_status, updated_at = timezone('utc'::text, now())
    WHERE id = p_pedido_id;

    RETURN TRUE;
END;
$$;

-- 11. FUNÇÃO PARA ATUALIZAÇÃO COMPLETA DE PEDIDO (ADMIN)
CREATE OR REPLACE FUNCTION public.admin_atualizar_pedido(
    p_admin_code TEXT,
    p_pedido_id UUID,
    p_codigo TEXT,
    p_nome_cliente TEXT,
    p_cpf TEXT,
    p_produto TEXT,
    p_cor TEXT,
    p_valor NUMERIC,
    p_observacao TEXT,
    p_status TEXT,
    p_imagem_url TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_updated public.pedidos;
BEGIN
    IF NOT public.validar_codigo_admin(p_admin_code) THEN
        RAISE EXCEPTION 'Acesso negado: Código administrativo inválido.';
    END IF;

    UPDATE public.pedidos
    SET 
        codigo = p_codigo,
        nome_cliente = p_nome_cliente,
        cpf = p_cpf,
        produto = p_produto,
        cor = p_cor,
        valor = p_valor,
        observacao = p_observacao,
        status_pagamento = p_status,
        imagem_url = p_imagem_url,
        updated_at = timezone('utc'::text, now())
    WHERE id = p_pedido_id
    RETURNING * INTO v_updated;

    RETURN to_jsonb(v_updated);
END;
$$;

-- 12. FUNÇÃO PARA EXCLUSÃO SEGURA DE PEDIDO (ADMIN)
CREATE OR REPLACE FUNCTION public.admin_excluir_pedido(
    p_admin_code TEXT,
    p_pedido_id UUID
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT public.validar_codigo_admin(p_admin_code) THEN
        RAISE EXCEPTION 'Acesso negado: Código administrativo inválido.';
    END IF;

    DELETE FROM public.pedidos WHERE id = p_pedido_id;
    RETURN TRUE;
END;
$$;

-- =======================================================
-- HABILITAÇÃO E POLÍTICAS BLINDADAS DE ROW LEVEL SECURITY (RLS)
-- =======================================================

ALTER TABLE public.pedidos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.configuracoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itens_pedido ENABLE ROW LEVEL SECURITY;

-- 13. POLÍTICAS PARA 'configuracoes'
-- BLOQUEIO TOTAL: Nenhuma permissão direta de SELECT/INSERT/UPDATE/DELETE para chave anônima (anon)
DROP POLICY IF EXISTS "Consulta de configuracoes" ON public.configuracoes;
DROP POLICY IF EXISTS "Gerenciamento de configuracoes" ON public.configuracoes;
DROP POLICY IF EXISTS "Consulta publica de configs anonimas" ON public.configuracoes;
DROP POLICY IF EXISTS "Admin gerencia configs" ON public.configuracoes;

-- 14. POLÍTICAS PARA 'pedidos'
-- A) Consulta pública: Clientes e Admin podem consultar pedidos
DROP POLICY IF EXISTS "Consulta pública de pedido" ON public.pedidos;
DROP POLICY IF EXISTS "Consulta de pedidos" ON public.pedidos;
CREATE POLICY "Consulta de pedidos" 
    ON public.pedidos 
    FOR SELECT 
    TO anon, authenticated 
    USING (true);

-- B) Criação de pedidos: Bloqueia forja de status 'Pago' e valores negativos
DROP POLICY IF EXISTS "Criação de pedidos" ON public.pedidos;
DROP POLICY IF EXISTS "Inserção de pedidos" ON public.pedidos;
CREATE POLICY "Criação de pedidos" 
    ON public.pedidos 
    FOR INSERT 
    TO anon, authenticated 
    WITH CHECK (
        status_pagamento = 'Pendente' 
        AND valor >= 0 
        AND length(trim(codigo)) >= 3
    );

-- C) Atualização direta: Clientes só podem avisar pagamento ('Cliente informou pagamento')
DROP POLICY IF EXISTS "Atualização de pedidos" ON public.pedidos;
DROP POLICY IF EXISTS "Cliente informa pagamento" ON public.pedidos;
CREATE POLICY "Cliente informa pagamento" 
    ON public.pedidos 
    FOR UPDATE 
    TO anon, authenticated 
    USING (status_pagamento = 'Pendente') 
    WITH CHECK (status_pagamento = 'Cliente informou pagamento');

-- D) Exclusão direta: BLOQUEADA para anon. Apenas a RPC segura admin_excluir_pedido() pode deletar.
DROP POLICY IF EXISTS "Exclusão de pedidos" ON public.pedidos;
DROP POLICY IF EXISTS "Administrador gerencia todos os pedidos" ON public.pedidos;

-- 15. POLÍTICAS PARA 'produtos'
-- Apenas visualização pública. Alterações de preço/estoque bloqueadas contra anon.
DROP POLICY IF EXISTS "Consulta de produtos" ON public.produtos;
DROP POLICY IF EXISTS "Gerenciamento de produtos" ON public.produtos;
CREATE POLICY "Consulta de produtos" 
    ON public.produtos 
    FOR SELECT 
    TO anon, authenticated 
    USING (true);

-- 16. POLÍTICAS PARA 'itens_pedido'
DROP POLICY IF EXISTS "Consulta de itens_pedido" ON public.itens_pedido;
DROP POLICY IF EXISTS "Criação de itens_pedido" ON public.itens_pedido;
DROP POLICY IF EXISTS "Gerenciamento de itens_pedido" ON public.itens_pedido;

CREATE POLICY "Consulta de itens_pedido" 
    ON public.itens_pedido 
    FOR SELECT 
    TO anon, authenticated 
    USING (true);

CREATE POLICY "Criação de itens_pedido" 
    ON public.itens_pedido 
    FOR INSERT 
    TO anon, authenticated 
    WITH CHECK (quantidade > 0 AND subtotal >= 0);
`;
