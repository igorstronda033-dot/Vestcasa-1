import { supabase, isSupabaseConfigured } from '../lib/supabase';

export const LOCAL_ADMIN_CODE_KEY = 'vestcasa_admin_access_code';
export const DEFAULT_FALLBACK_CODE = 'ADMIN2026@i';

/**
 * Retorna o código de segurança administrativo da sessão atual
 */
export function getStoredAdminCode(): string {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem(LOCAL_ADMIN_CODE_KEY);
    if (saved && saved.trim()) return saved.trim();
  }
  return DEFAULT_FALLBACK_CODE;
}

/**
 * Salva o código administrativo na sessão
 */
export function setStoredAdminCode(code: string): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(LOCAL_ADMIN_CODE_KEY, code.trim());
  }
}

/**
 * Valida o código digitado DIRETAMENTE no banco de dados Supabase.
 * 
 * SEGURANÇA & PERSISTÊNCIA:
 * 1. O banco de dados (tabela configuracoes / RPC validar_codigo_admin) é a autoridade máxima.
 * 2. Se a senha for alterada no Supabase, a nova senha passa a valer imediatamente.
 * 3. Se o banco estiver temporariamente sem conexão, utiliza o fallback local.
 */
export async function validateAdminCode(code: string): Promise<boolean> {
  const cleanCode = code?.trim();
  if (!cleanCode) return false;

  if (isSupabaseConfigured()) {
    try {
      // 1. Validação primária no banco de dados Supabase via função RPC
      const { data: rpcResult, error: rpcError } = await supabase.rpc('validar_codigo_admin', {
        codigo_digitado: cleanCode
      });

      if (!rpcError && typeof rpcResult === 'boolean') {
        if (rpcResult) {
          setStoredAdminCode(cleanCode);
        }
        return rpcResult;
      }

      // 2. Consulta direta na tabela configuracoes se a RPC não existir
      const { data: configRow, error: tableError } = await supabase
        .from('configuracoes')
        .select('valor')
        .eq('chave', 'codigo_admin')
        .maybeSingle();

      if (!tableError && configRow?.valor) {
        const dbCode = configRow.valor.trim();
        const matches = cleanCode === dbCode || cleanCode.toUpperCase() === dbCode.toUpperCase();
        if (matches) {
          setStoredAdminCode(cleanCode);
        }
        return matches;
      }
    } catch (err) {
      console.warn('Falha na comunicação com o Supabase ao validar código:', err);
    }
  }

  // 3. Fallback de contingência caso o banco esteja offline
  const expectedCode = getStoredAdminCode();
  const matches = cleanCode === expectedCode || cleanCode.toUpperCase() === expectedCode.toUpperCase();
  if (matches) {
    setStoredAdminCode(cleanCode);
  }
  return matches;
}

/**
 * Obtém o código administrativo atual salvo no banco de dados
 */
export async function getAdminCode(): Promise<string> {
  if (isSupabaseConfigured()) {
    try {
      const { data, error } = await supabase
        .from('configuracoes')
        .select('valor')
        .eq('chave', 'codigo_admin')
        .maybeSingle();

      if (!error && data?.valor) {
        return data.valor.trim();
      }
    } catch (e) {
      console.warn('Erro ao consultar código no banco:', e);
    }
  }

  return getStoredAdminCode();
}

/**
 * Salva e atualiza o código administrativo diretamente no banco de dados Supabase
 */
export async function updateAdminCode(newCode: string): Promise<{ success: boolean; error: string | null }> {
  const clean = newCode.trim();
  if (!clean || clean.length < 4) {
    return { success: false, error: 'O código administrativo deve ter pelo menos 4 caracteres.' };
  }

  const currentCode = getStoredAdminCode();

  if (isSupabaseConfigured()) {
    try {
      // 1. Gravação direta no banco de dados (tabela configuracoes)
      const { error: upsertError } = await supabase
        .from('configuracoes')
        .upsert({
          chave: 'codigo_admin',
          valor: clean,
          updated_at: new Date().toISOString()
        }, { onConflict: 'chave' });

      if (!upsertError) {
        setStoredAdminCode(clean);
        return { success: true, error: null };
      }

      // 2. Tentativa via RPC segura se RLS bloquear update direto
      const { data: rpcData, error: rpcError } = await supabase.rpc('admin_alterar_codigo', {
        p_codigo_atual: currentCode,
        p_novo_codigo: clean
      });

      if (!rpcError && rpcData) {
        setStoredAdminCode(clean);
        return { success: true, error: null };
      }

      if (upsertError) {
        return { success: false, error: `Erro ao salvar no banco: ${upsertError.message}` };
      }
    } catch (err: any) {
      console.warn('Erro ao gravar senha no Supabase:', err);
    }
  }

  setStoredAdminCode(clean);
  return { success: true, error: null };
}
