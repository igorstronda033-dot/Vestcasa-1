import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { ShippingRule } from '../types';

export interface ShippingCalculationResult {
  matched: boolean;
  rule?: ShippingRule;
  valor_frete: number;
  prazo_estimado?: string;
  isFree: boolean;
  nome_regiao?: string;
  message?: string;
}

const STORAGE_KEY = 'vestcasa_shipping_rules';

// Regras padrão de frete pré-configuradas para funcionamento imediato
export const DEFAULT_SHIPPING_RULES: ShippingRule[] = [
  {
    id: 'rule-sp-capital',
    nome_regiao: 'São Paulo - Capital',
    estado: 'SP',
    cidade: 'São Paulo',
    cep_inicio: '01000-000',
    cep_fim: '05999-999',
    valor_frete: 150,
    prazo_estimado: '3 a 5 dias úteis',
    ativo: true,
    frete_gratis: false,
    modelos_especificos: null,
    created_at: new Date().toISOString()
  },
  {
    id: 'rule-sp-grande-sp',
    nome_regiao: 'Grande São Paulo (Metropolitana)',
    estado: 'SP',
    cidade: null,
    cep_inicio: '06000-000',
    cep_fim: '09999-999',
    valor_frete: 180,
    prazo_estimado: '4 a 6 dias úteis',
    ativo: true,
    frete_gratis: false,
    modelos_especificos: null,
    created_at: new Date().toISOString()
  },
  {
    id: 'rule-sp-interior',
    nome_regiao: 'Interior de São Paulo & Litoral',
    estado: 'SP',
    cidade: null,
    cep_inicio: '11000-000',
    cep_fim: '19999-999',
    valor_frete: 220,
    prazo_estimado: '5 a 8 dias úteis',
    ativo: true,
    frete_gratis: false,
    modelos_especificos: null,
    created_at: new Date().toISOString()
  },
  {
    id: 'rule-rj-capital',
    nome_regiao: 'Rio de Janeiro - Capital',
    estado: 'RJ',
    cidade: 'Rio de Janeiro',
    cep_inicio: '20000-000',
    cep_fim: '23799-999',
    valor_frete: 260,
    prazo_estimado: '5 a 7 dias úteis',
    ativo: true,
    frete_gratis: false,
    modelos_especificos: null,
    created_at: new Date().toISOString()
  },
  {
    id: 'rule-rj-interior',
    nome_regiao: 'Rio de Janeiro - Baixada & Interior',
    estado: 'RJ',
    cidade: null,
    cep_inicio: '23800-000',
    cep_fim: '28999-999',
    valor_frete: 290,
    prazo_estimado: '6 a 9 dias úteis',
    ativo: true,
    frete_gratis: false,
    modelos_especificos: null,
    created_at: new Date().toISOString()
  },
  {
    id: 'rule-mg-bh',
    nome_regiao: 'Minas Gerais - Belo Horizonte & Região',
    estado: 'MG',
    cidade: 'Belo Horizonte',
    cep_inicio: '30000-000',
    cep_fim: '34999-999',
    valor_frete: 280,
    prazo_estimado: '5 a 8 dias úteis',
    ativo: true,
    frete_gratis: false,
    modelos_especificos: null,
    created_at: new Date().toISOString()
  },
  {
    id: 'rule-pr-curitiba',
    nome_regiao: 'Paraná - Curitiba & Região Metropolitana',
    estado: 'PR',
    cidade: 'Curitiba',
    cep_inicio: '80000-000',
    cep_fim: '83800-999',
    valor_frete: 290,
    prazo_estimado: '5 a 8 dias úteis',
    ativo: true,
    frete_gratis: false,
    modelos_especificos: null,
    created_at: new Date().toISOString()
  },
  {
    id: 'rule-sc-floripa',
    nome_regiao: 'Santa Catarina - Florianópolis & Litoral',
    estado: 'SC',
    cidade: 'Florianópolis',
    cep_inicio: '88000-000',
    cep_fim: '89999-999',
    valor_frete: 320,
    prazo_estimado: '6 a 9 dias úteis',
    ativo: true,
    frete_gratis: false,
    modelos_especificos: null,
    created_at: new Date().toISOString()
  },
  {
    id: 'rule-rs-poa',
    nome_regiao: 'Rio Grande do Sul - Porto Alegre & Região',
    estado: 'RS',
    cidade: 'Porto Alegre',
    cep_inicio: '90000-000',
    cep_fim: '94999-999',
    valor_frete: 340,
    prazo_estimado: '7 a 10 dias úteis',
    ativo: true,
    frete_gratis: false,
    modelos_especificos: null,
    created_at: new Date().toISOString()
  }
];

function getLocalShippingRules(): ShippingRule[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Erro ao ler regras de frete do localStorage:', e);
  }
  
  // Salva os padrões caso não exista
  saveLocalShippingRules(DEFAULT_SHIPPING_RULES);
  return DEFAULT_SHIPPING_RULES;
}

function saveLocalShippingRules(rules: ShippingRule[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rules));
  } catch (e) {
    console.warn('Erro ao salvar regras de frete no localStorage:', e);
  }
}

/**
 * Listar todas as regras de frete cadastradas
 */
export async function listShippingRules(): Promise<{ data: ShippingRule[]; error: string | null }> {
  if (!isSupabaseConfigured()) {
    return { data: getLocalShippingRules(), error: null };
  }

  try {
    const { data, error } = await supabase
      .from('shipping_rules')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      // Se a tabela ainda não existir no Supabase, usa local de forma transparente
      console.warn('Tabela shipping_rules não acessível no Supabase, usando local:', error.message);
      return { data: getLocalShippingRules(), error: null };
    }

    if (data && data.length > 0) {
      const formatted: ShippingRule[] = data.map((d: any) => ({
        id: d.id,
        nome_regiao: d.nome_regiao || 'Região',
        estado: d.estado || 'SP',
        cidade: d.cidade || null,
        cep_inicio: d.cep_inicio,
        cep_fim: d.cep_fim,
        valor_frete: Number(d.valor_frete) || 0,
        prazo_estimado: d.prazo_estimado || '3 a 5 dias úteis',
        ativo: d.ativo !== false,
        frete_gratis: Boolean(d.frete_gratis),
        modelos_especificos: d.modelos_especificos || null,
        created_at: d.created_at,
        updated_at: d.updated_at
      }));
      // Atualiza cache local
      saveLocalShippingRules(formatted);
      return { data: formatted, error: null };
    }

    // Se estiver vazio no Supabase, salva os padrões
    return { data: getLocalShippingRules(), error: null };
  } catch (err: any) {
    return { data: getLocalShippingRules(), error: null };
  }
}

/**
 * Criar nova regra de frete
 */
export async function createShippingRule(payload: Omit<ShippingRule, 'id' | 'created_at' | 'updated_at'>): Promise<{ data: ShippingRule | null; error: string | null }> {
  const newRule: ShippingRule = {
    id: `rule-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    ...payload,
    valor_frete: Number(payload.valor_frete) || 0,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  const local = getLocalShippingRules();
  local.unshift(newRule);
  saveLocalShippingRules(local);

  if (!isSupabaseConfigured()) {
    return { data: newRule, error: null };
  }

  try {
    const { data, error } = await supabase
      .from('shipping_rules')
      .insert([{
        id: newRule.id,
        nome_regiao: newRule.nome_regiao,
        estado: newRule.estado,
        cidade: newRule.cidade,
        cep_inicio: newRule.cep_inicio,
        cep_fim: newRule.cep_fim,
        valor_frete: newRule.valor_frete,
        prazo_estimado: newRule.prazo_estimado,
        ativo: newRule.ativo,
        frete_gratis: newRule.frete_gratis,
        modelos_especificos: newRule.modelos_especificos
      }])
      .select()
      .single();

    if (error) {
      console.warn('Erro ao inserir regra no Supabase, mantido em cache local:', error.message);
      return { data: newRule, error: null };
    }

    return { data: data || newRule, error: null };
  } catch (err: any) {
    return { data: newRule, error: null };
  }
}

/**
 * Atualizar regra de frete existente
 */
export async function updateShippingRule(id: string, updates: Partial<ShippingRule>): Promise<{ success: boolean; error: string | null }> {
  const local = getLocalShippingRules();
  const index = local.findIndex((r) => r.id === id);
  if (index >= 0) {
    local[index] = {
      ...local[index],
      ...updates,
      updated_at: new Date().toISOString()
    };
    saveLocalShippingRules(local);
  }

  if (!isSupabaseConfigured()) {
    return { success: true, error: null };
  }

  try {
    const { error } = await supabase
      .from('shipping_rules')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', id);

    if (error) {
      console.warn('Erro ao atualizar regra no Supabase:', error.message);
    }
    return { success: true, error: null };
  } catch (err: any) {
    return { success: true, error: null };
  }
}

/**
 * Alternar status ativo/inativo de uma regra
 */
export async function toggleShippingRuleActive(id: string, ativo: boolean): Promise<{ success: boolean }> {
  const res = await updateShippingRule(id, { ativo });
  return { success: res.success };
}

/**
 * Excluir regra de frete
 */
export async function deleteShippingRule(id: string): Promise<{ success: boolean; error: string | null }> {
  const local = getLocalShippingRules().filter((r) => r.id !== id);
  saveLocalShippingRules(local);

  if (!isSupabaseConfigured()) {
    return { success: true, error: null };
  }

  try {
    const { error } = await supabase
      .from('shipping_rules')
      .delete()
      .eq('id', id);

    if (error) {
      console.warn('Erro ao deletar regra no Supabase:', error.message);
    }
    return { success: true, error: null };
  } catch (err: any) {
    return { success: true, error: null };
  }
}

/**
 * Normaliza CEP para número inteiro de 8 dígitos para comparação de intervalos
 */
export function normalizeCepToNumber(cep: string): number | null {
  const clean = String(cep || '').replace(/\D/g, '');
  if (clean.length !== 8) return null;
  const num = parseInt(clean, 10);
  return isNaN(num) ? null : num;
}

/**
 * CALCULAR FRETE PARA CEP
 * 
 * Regra do Usuário:
 * Se não existir uma regra de frete cadastrada para o CEP informado, NÃO inventar um valor.
 * Retorna matched: false e mensagem amigável para consultar via WhatsApp.
 * Se existir regra ativa correspondente ao intervalo de CEP, retorna o valor ou Frete Grátis.
 */
export async function calculateShippingForCep(
  cep: string, 
  options?: { modelIds?: string[]; cidade?: string; estado?: string }
): Promise<ShippingCalculationResult> {
  const cleanCep = String(cep || '').replace(/\D/g, '');
  if (cleanCep.length !== 8) {
    return {
      matched: false,
      valor_frete: 0,
      isFree: false,
      message: 'CEP inválido ou incompleto. Digite os 8 dígitos do CEP.'
    };
  }

  const cepNum = normalizeCepToNumber(cleanCep);
  if (cepNum === null) {
    return {
      matched: false,
      valor_frete: 0,
      isFree: false,
      message: 'CEP inválido.'
    };
  }

  // Obtém as regras ativas
  const { data: rules } = await listShippingRules();
  const activeRules = rules.filter((r) => r.ativo);

  // Procura regras que cobrem o intervalo de CEP
  const matchingRules: { rule: ShippingRule; priority: number }[] = [];

  for (const rule of activeRules) {
    const startNum = normalizeCepToNumber(rule.cep_inicio);
    const endNum = normalizeCepToNumber(rule.cep_fim);

    if (startNum === null || endNum === null) continue;

    // Verifica se o CEP cai no intervalo [startNum, endNum]
    if (cepNum >= startNum && cepNum <= endNum) {
      // Verifica filtro de modelo específico caso a regra restrinja a determinados modelos
      if (
        Array.isArray(rule.modelos_especificos) && 
        rule.modelos_especificos.length > 0 &&
        options?.modelIds &&
        options.modelIds.length > 0
      ) {
        const matchesModel = options.modelIds.some((mId) => rule.modelos_especificos!.includes(mId));
        if (!matchesModel) {
          continue; // Regra é restrita a outro modelo
        }
      }

      // Prioridade: regras com cidade específica ou menor intervalo são mais específicas
      let priority = 1;
      if (rule.cidade && options?.cidade && rule.cidade.toLowerCase() === options.cidade.toLowerCase()) {
        priority += 10;
      }
      // Quanto menor o range de CEP, mais específica é a regra
      const range = Math.abs(endNum - startNum);
      priority += Math.max(0, 10000000 - range) / 1000000;

      matchingRules.push({ rule, priority });
    }
  }

  // Ordena por maior prioridade
  matchingRules.sort((a, b) => b.priority - a.priority);

  if (matchingRules.length > 0) {
    const bestMatch = matchingRules[0].rule;
    const isFree = bestMatch.frete_gratis || Number(bestMatch.valor_frete) === 0;
    const valor = isFree ? 0 : Number(bestMatch.valor_frete);

    return {
      matched: true,
      rule: bestMatch,
      valor_frete: valor,
      prazo_estimado: bestMatch.prazo_estimado || '3 a 5 dias úteis',
      isFree,
      nome_regiao: bestMatch.nome_regiao
    };
  }

  // Nenhuma regra cadastrada para o CEP informado
  return {
    matched: false,
    valor_frete: 0,
    isFree: false,
    message: 'Precisamos consultar o frete para o seu endereço.'
  };
}
