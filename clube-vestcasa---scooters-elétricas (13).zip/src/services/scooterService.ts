import { ScooterModel } from '../types';
import imgMu02 from '../assets/images/mu02_official.webp';
import imgMu03 from '../assets/images/mu03_official.webp';
import imgMu09 from '../assets/images/mu09_official.webp';
import imgMu04 from '../assets/images/mu04_official.webp';
import imgV20Pro from '../assets/images/v20_pro_official_1788975935690.jpg';
import pixOfficialQrCode from '../assets/images/pix_official_qrcode.png';
import { 
  OFFICIAL_UNIFIED_PIX_PAYLOAD,
  PIX_MU02_PAYLOAD, 
  PIX_MU03_PAYLOAD, 
  PIX_MU09_PAYLOAD, 
  PIX_MU04_PAYLOAD 
} from '../lib/pix';

export const DEFAULT_SCOOTER_MODELS: ScooterModel[] = [
  {
    id: 'mu02',
    name: 'MU02',
    power: '350W',
    description: 'Bicicleta elétrica scooter ágil, econômica, com cesto dianteiro e assento duplo anatômico.',
    price: 1990.00,
    oldPrice: 2490.00,
    tag: '350W',
    badge: 'Mais Econômica',
    colors: ['Vermelho', 'Preto', 'Branco'],
    image: imgMu02,
    pixQrCodeSemFrete: pixOfficialQrCode,
    pixCopiaColaSemFrete: OFFICIAL_UNIFIED_PIX_PAYLOAD,
    pixQrCodeComFrete: '',
    pixCopiaColaComFrete: '',
    autonomia: 'Até 35 km',
    velocidadeMaxima: 'Até 25 km/h',
    tempoCarga: '4 a 6 horas',
    pesoSuportado: 'Até 130 kg',
    freios: 'Tambor dianteiro e traseiro',
    bateria: '48V 12Ah Chumbo-Ácido',
    features: [
      'Cesto frontal espaçoso para compras e pertences',
      'Assento duplo com encosto macio para garupa',
      'Farol frontal em LED e buzina elétrica',
      'Pedal assistido para emergências',
      'Chave de ignição e trava de segurança'
    ],
    specs: {
      'Motor': '350W Brushless High Performance',
      'Bateria': '48V 12Ah Bivolt (110V / 220V)',
      'Autonomia média': '30 a 35 km por carga',
      'Velocidade máxima': '25 km/h',
      'Carga máxima': '130 kg',
      'Iluminação': 'Farol em LED e lanterna traseira',
      'Rodas': 'Aro 14 com pneus tubeless'
    }
  },
  {
    id: 'mu03',
    name: 'MU03',
    power: '500W',
    description: 'Motor de 500W de alto torque, suspensão reforçada, ignição inteligente e cesto espaçoso.',
    price: 2390.00,
    oldPrice: 2990.00,
    tag: '500W',
    badge: 'Mais Vendida',
    colors: ['Vermelho', 'Preto', 'Branco'],
    image: imgMu03,
    pixQrCodeSemFrete: pixOfficialQrCode,
    pixCopiaColaSemFrete: OFFICIAL_UNIFIED_PIX_PAYLOAD,
    pixQrCodeComFrete: '',
    pixCopiaColaComFrete: '',
    autonomia: 'Até 45 km',
    velocidadeMaxima: 'Até 32 km/h',
    tempoCarga: '5 a 7 horas',
    pesoSuportado: 'Até 150 kg',
    freios: 'Disco dianteiro e tambor traseiro',
    bateria: '48V 20Ah Chumbo-Ácido',
    features: [
      'Motor 500W de alto torque para aclives e ladeiras',
      'Suspensão dianteira e traseira de curso longo',
      'Painel digital completo com nível de bateria',
      'Alarme antifurto com controle remoto',
      'Amplo cesto metálico com tampa segura'
    ],
    specs: {
      'Motor': '500W Torque Reforçado',
      'Bateria': '48V 20Ah Bivolt Automático',
      'Autonomia média': '40 a 45 km por carga',
      'Velocidade máxima': '32 km/h',
      'Carga máxima': '150 kg',
      'Freios': 'Disco ventilado dianteiro + tambor traseiro',
      'Painel': 'Display digital LCD com velocímetro'
    }
  },
  {
    id: 'mu09',
    name: 'MU09',
    power: '350W',
    description: 'Moto scooter elétrica com carenagem moderna aerodinâmica, farol LED integrado e cockpit digital.',
    price: 1990.00,
    oldPrice: 2490.00,
    tag: '350W',
    badge: 'Design Esportivo',
    colors: ['Vermelho', 'Preto', 'Branco'],
    image: imgMu09,
    pixQrCodeSemFrete: pixOfficialQrCode,
    pixCopiaColaSemFrete: OFFICIAL_UNIFIED_PIX_PAYLOAD,
    pixQrCodeComFrete: '',
    pixCopiaColaComFrete: '',
    autonomia: 'Até 40 km',
    velocidadeMaxima: 'Até 30 km/h',
    tempoCarga: '4 a 6 horas',
    pesoSuportado: 'Até 140 kg',
    freios: 'Disco hidráulico dianteiro',
    bateria: '48V 12Ah Long Life',
    features: [
      'Design esportivo com carenagem envolvente',
      'Faróis Full LED com excelente visibilidade noturna',
      'Painel digital moderno estilo moto',
      'Assento ergonômico com porta-objetos inferior',
      'Rodas de liga leve com pneus reforçados'
    ],
    specs: {
      'Motor': '350W High Output Efficiency',
      'Bateria': '48V 12Ah Bivolt Automático',
      'Autonomia média': '35 a 40 km por carga',
      'Velocidade máxima': '30 km/h',
      'Carga máxima': '140 kg',
      'Freios': 'Disco hidráulico dianteiro e traseiro',
      'Design': 'Carenagem aerodinâmica estilo Sport'
    }
  },
  {
    id: 'mu04',
    name: 'MU04',
    power: '600W',
    description: 'Veículo elétrico triciclo de 600W com cesto dianteiro, bagageiro traseiro, marcha ré e amplo assento anatômico.',
    price: 3899.00,
    oldPrice: 4890.00,
    tag: '600W',
    badge: 'Máximo Conforto',
    colors: ['Vermelho', 'Preto', 'Branco'],
    image: imgMu04,
    pixQrCodeSemFrete: pixOfficialQrCode,
    pixCopiaColaSemFrete: OFFICIAL_UNIFIED_PIX_PAYLOAD,
    pixQrCodeComFrete: '',
    pixCopiaColaComFrete: '',
    autonomia: 'Até 50 km',
    velocidadeMaxima: 'Até 30 km/h',
    tempoCarga: '6 a 8 horas',
    pesoSuportado: 'Até 180 kg',
    freios: 'Freio duplo com trava de estacionamento',
    bateria: '60V 20Ah Heavy Duty',
    features: [
      'Estrutura em triciclo de estabilidade inigualável (não tomba)',
      'Marcha ré elétrica com sinal sonoro de segurança',
      'Poltrona anatômica com encosto alto e braços rebatíveis',
      'Baú traseiro com chave + cesto dianteiro',
      'Ideal para compras, idosos e mobilidade facilitada'
    ],
    specs: {
      'Motor': '600W Heavy Duty com Diferencial',
      'Bateria': '60V 20Ah Bivolt Automático',
      'Autonomia média': '45 a 50 km por carga',
      'Velocidade máxima': '30 km/h (com 3 níveis de velocidade)',
      'Carga máxima': '180 kg',
      'Recursos': 'Marcha ré com bip sonoro, trava de freio de mão',
      'Acessórios': 'Cesto frontal + Baú porta-malas traseiro com chave'
    }
  },
  {
    id: 'v20_pro',
    name: 'V20 Pro',
    power: '1000W',
    description: 'Scooter elétrica potente de 1000W com alto desempenho, suspensão premium, freios a disco e autonomia estendida.',
    price: 3990.00,
    oldPrice: 4990.00,
    tag: '1000W',
    badge: 'Super Potência',
    colors: ['Vermelho', 'Preto', 'Branco'],
    image: imgV20Pro,
    estoque: 15,
    pixQrCodeSemFrete: pixOfficialQrCode,
    pixCopiaColaSemFrete: OFFICIAL_UNIFIED_PIX_PAYLOAD,
    pixQrCodeComFrete: '',
    pixCopiaColaComFrete: '',
    autonomia: 'Até 60 km',
    velocidadeMaxima: 'Até 45 km/h',
    tempoCarga: '6 a 8 horas',
    pesoSuportado: 'Até 160 kg',
    freios: 'Freio a disco dianteiro e traseiro',
    bateria: '60V 20Ah Lithium / Chumbo Alta Densidade',
    features: [
      'Motor de alta potência de 1000W para subidas íngremes',
      'Suspensão esportiva reforçada dianteira e traseira',
      'Freios a disco de precisão para máxima segurança',
      'Painel digital digital LCD com velocímetro e odômetro',
      'Farol esportivo em LED de longo alcance e alarme antifurto'
    ],
    specs: {
      'Motor': '1000W High Torque Brushless',
      'Bateria': '60V 20Ah Bivolt Automático',
      'Autonomia média': '50 a 60 km por carga',
      'Velocidade máxima': '45 km/h (com seletor de modos)',
      'Carga máxima': '160 kg',
      'Freios': 'Disco dianteiro e traseiro',
      'Painel': 'Display digital LCD completo'
    }
  },
];

const STORAGE_KEY = 'vestcasa_scooter_models_v15_unified_pix_qrcode';

export function getScooterModels(): ScooterModel[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_SCOOTER_MODELS));
      return DEFAULT_SCOOTER_MODELS;
    }
    const parsed: ScooterModel[] = JSON.parse(stored);
    
    // Ensure default models that may be missing from storage are added
    const missingDefaults = DEFAULT_SCOOTER_MODELS.filter(
      (d) => !parsed.some((p) => p.id === d.id)
    );
    const fullList = [...parsed, ...missingDefaults];

    // Ensure default models have up-to-date image paths, colors, power, badges, specs and official prices
    return fullList.map((m) => {
      const defaultMatch = DEFAULT_SCOOTER_MODELS.find((d) => d.id === m.id);
      if (defaultMatch) {
        return { 
          ...defaultMatch,
          ...m, 
          image: defaultMatch.image, 
          colors: defaultMatch.colors,
          power: defaultMatch.power,
          tag: defaultMatch.tag,
          price: defaultMatch.price,
          oldPrice: defaultMatch.oldPrice,
          badge: defaultMatch.badge,
          estoque: m.estoque !== undefined ? m.estoque : defaultMatch.estoque,
          autonomia: defaultMatch.autonomia,
          velocidadeMaxima: defaultMatch.velocidadeMaxima,
          tempoCarga: defaultMatch.tempoCarga,
          pesoSuportado: defaultMatch.pesoSuportado,
          freios: defaultMatch.freios,
          bateria: defaultMatch.bateria,
          features: defaultMatch.features,
          specs: defaultMatch.specs,
          pixQrCodeSemFrete: defaultMatch.pixQrCodeSemFrete,
          pixCopiaColaSemFrete: defaultMatch.pixCopiaColaSemFrete,
          pixQrCodeComFrete: m.pixQrCodeComFrete || defaultMatch.pixQrCodeSemFrete,
          pixCopiaColaComFrete: m.pixCopiaColaComFrete || defaultMatch.pixCopiaColaSemFrete,
        };
      }
      return m;
    });
  } catch (e) {
    console.error('Erro ao ler modelos do localStorage:', e);
    return DEFAULT_SCOOTER_MODELS;
  }
}

export function saveScooterModels(models: ScooterModel[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(models));
  } catch (e) {
    console.error('Erro ao salvar modelos no localStorage:', e);
  }
}

export function addScooterModel(newModel: Omit<ScooterModel, 'id'>): ScooterModel {
  const models = getScooterModels();
  const id = newModel.name.toLowerCase().replace(/[^a-z0-9]/g, '_') + '_' + Date.now().toString().slice(-4);
  const createdModel: ScooterModel = {
    ...newModel,
    id,
  };
  const updated = [createdModel, ...models];
  saveScooterModels(updated);
  return createdModel;
}

export function updateScooterModel(id: string, updates: Partial<ScooterModel>): ScooterModel | null {
  const models = getScooterModels();
  const index = models.findIndex((m) => m.id === id);
  if (index === -1) return null;

  const updatedModel = { ...models[index], ...updates };
  models[index] = updatedModel;
  saveScooterModels(models);
  return updatedModel;
}

export function deleteScooterModel(id: string): void {
  const models = getScooterModels();
  const filtered = models.filter((m) => m.id !== id);
  saveScooterModels(filtered);
}

export function resetToDefaultModels(): ScooterModel[] {
  saveScooterModels(DEFAULT_SCOOTER_MODELS);
  return DEFAULT_SCOOTER_MODELS;
}

/**
 * Returns the corresponding image for a given product or model name.
 * Strictly respects the 4 official models and uploaded images:
 * - MU02 -> Imagem 1
 * - MU03 -> Imagem 2
 * - MU09 -> Imagem 3
 * - MU04 -> Imagem 4
 */
export function getModelImage(productOrModelName?: string | null): string {
  if (!productOrModelName) return imgMu02;

  const upper = productOrModelName.toUpperCase();
  const models = getScooterModels();

  // 1. Direct match with exact name
  const exact = models.find((m) => m.name.toUpperCase() === upper);
  if (exact && exact.image) return exact.image;

  // 2. Prioritize longer names first
  const sorted = [...models].sort((a, b) => b.name.length - a.name.length);
  for (const m of sorted) {
    if (upper.includes(m.name.toUpperCase())) {
      return m.image;
    }
  }

  // 3. Fallbacks based on specific model codes
  if (upper.includes('V20')) return imgV20Pro;
  if (upper.includes('MU04') || upper.includes('MU07')) return imgMu04;
  if (upper.includes('MU09')) return imgMu09;
  if (upper.includes('MU03')) return imgMu03;
  if (upper.includes('MU02')) return imgMu02;

  return imgMu02;
}
