import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Pedido, PaymentStatus, CartItem } from '../types';
import { getStoredAdminCode } from './adminConfigService';

export class SupabaseNotConfiguredError extends Error {
  constructor() {
    super('Banco de dados indisponível no momento. Tente novamente mais tarde.');
    this.name = 'SupabaseNotConfiguredError';
  }
}

function getLocalOrders(): Pedido[] {
  try {
    const raw = localStorage.getItem('vestcasa_local_orders');
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  
  const initial: Pedido[] = [
    {
      id: 'demo-order-mu04',
      codigo: 'VEST-MU04',
      nome_cliente: 'Cliente Vestcasa',
      cpf: '123.456.789-00',
      produto: 'MU04',
      cor: 'Preto',
      valor: 3899,
      observacao: 'Scooter Elétrica Vestcasa Modelo MU04',
      status_pagamento: 'Pendente',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: 'demo-order-mu02',
      codigo: 'VEST-MU02',
      nome_cliente: 'Cliente Vestcasa',
      cpf: '987.654.321-99',
      produto: 'MU02',
      cor: 'Vermelho',
      valor: 1990,
      observacao: 'Scooter Elétrica Vestcasa Modelo MU02',
      status_pagamento: 'Pendente',
      created_at: new Date(Date.now() - 3600000).toISOString(),
      updated_at: new Date(Date.now() - 3600000).toISOString(),
    },
    {
      id: 'demo-order-mu03',
      codigo: 'VEST-MU03',
      nome_cliente: 'Cliente Vestcasa',
      cpf: '456.789.012-34',
      produto: 'MU03',
      cor: 'Branco',
      valor: 2390,
      observacao: 'Scooter Elétrica Vestcasa Modelo MU03',
      status_pagamento: 'Pendente',
      created_at: new Date(Date.now() - 1800000).toISOString(),
      updated_at: new Date(Date.now() - 1800000).toISOString(),
    },
    {
      id: 'demo-order-mu09',
      codigo: 'VEST-MU09',
      nome_cliente: 'Cliente Vestcasa',
      cpf: '321.654.987-11',
      produto: 'MU09',
      cor: 'Azul',
      valor: 1990,
      observacao: 'Scooter Elétrica Vestcasa Modelo MU09',
      status_pagamento: 'Pendente',
      created_at: new Date(Date.now() - 900000).toISOString(),
      updated_at: new Date(Date.now() - 900000).toISOString(),
    }
  ];
  try {
    localStorage.setItem('vestcasa_local_orders', JSON.stringify(initial));
  } catch (e) {}
  return initial;
}

function saveLocalOrders(orders: Pedido[]) {
  try {
    localStorage.setItem('vestcasa_local_orders', JSON.stringify(orders));
  } catch (e) {}
}

/**
 * Consulta de pedido por código (Área do Cliente)
 * Busca estritamente pelo código fornecido pelo administrador.
 */
export async function findOrderByCode(code: string): Promise<{ data: Pedido | null; error: string | null }> {
  const cleanCode = code.trim().toUpperCase();
  if (!cleanCode) {
    return { data: null, error: 'Por favor, informe o código do pedido.' };
  }

  if (!isSupabaseConfigured()) {
    const local = getLocalOrders();
    const found = local.find(
      (o) =>
        o.codigo?.toUpperCase() === cleanCode ||
        (cleanCode === 'MU04' && o.produto?.toUpperCase().includes('MU04')) ||
        (cleanCode === 'MU02' && o.produto?.toUpperCase().includes('MU02')) ||
        (cleanCode === 'MU03' && o.produto?.toUpperCase().includes('MU03')) ||
        (cleanCode === 'MU09' && o.produto?.toUpperCase().includes('MU09'))
    );
    if (found) {
      return { data: found, error: null };
    }
    return {
      data: null,
      error: 'Não encontramos nenhum pedido com esse código. Digite por exemplo VEST-MU02, VEST-MU03, VEST-MU04 ou VEST-MU09.',
    };
  }

  try {
    const { data, error } = await supabase
      .from('pedidos')
      .select('*')
      .eq('codigo', cleanCode)
      .maybeSingle();

    if (error) {
      console.error('Erro ao consultar pedido no Supabase:', error);
      return { 
        data: null, 
        error: `Erro ao consultar pedido: ${error.message}. Verifique se a tabela 'pedidos' foi criada no Supabase.` 
      };
    }

    if (!data) {
      return {
        data: null,
        error: 'Não encontramos nenhum pedido com esse código. Verifique o código e tente novamente.',
      };
    }

    return {
      data: {
        ...data,
        valor: Number(data.valor) || 0,
      } as Pedido,
      error: null,
    };
  } catch (err: any) {
    return {
      data: null,
      error: err.message || 'Erro inesperado de comunicação com o Supabase.',
    };
  }
}

/**
 * Cliente informa que realizou o pagamento (PIX, Cartão ou Boleto)
 */
export async function reportPaymentDone(
  orderId: string,
  details?: { method?: string; detailsText?: string }
): Promise<{ success: boolean; error: string | null }> {
  if (!isSupabaseConfigured()) {
    const list = getLocalOrders();
    const idx = list.findIndex(o => o.id === orderId);
    if (idx >= 0) {
      list[idx].status_pagamento = 'Cliente informou pagamento';
      if (details?.detailsText) {
        list[idx].observacao = list[idx].observacao
          ? `${list[idx].observacao} | ${details.detailsText}`
          : details.detailsText;
      }
      list[idx].updated_at = new Date().toISOString();
      saveLocalOrders(list);
    }
    return { success: true, error: null };
  }

  try {
    const updatePayload: any = {
      status_pagamento: 'Cliente informou pagamento',
      updated_at: new Date().toISOString(),
    };

    if (details?.detailsText) {
      // First get current observation to append
      const { data: currentOrder } = await supabase
        .from('pedidos')
        .select('observacao')
        .eq('id', orderId)
        .single();

      if (currentOrder) {
        updatePayload.observacao = currentOrder.observacao
          ? `${currentOrder.observacao} | ${details.detailsText}`
          : details.detailsText;
      }
    }

    const { error } = await supabase
      .from('pedidos')
      .update(updatePayload)
      .eq('id', orderId);

    if (error) {
      // If error might be due to observacao column issue, try updating only status_pagamento
      const fallback = await supabase
        .from('pedidos')
        .update({
          status_pagamento: 'Cliente informou pagamento',
          updated_at: new Date().toISOString(),
        })
        .eq('id', orderId);

      if (fallback.error) {
        console.error('Erro ao atualizar status do pedido no Supabase:', fallback.error);
        return { success: false, error: fallback.error.message };
      }
    }

    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err.message || 'Falha ao atualizar pedido.' };
  }
}

/**
 * Listagem de todos os pedidos (Área Administrativa)
 */
export async function listAllOrders(): Promise<{ data: Pedido[]; error: string | null }> {
  if (!isSupabaseConfigured()) {
    return { data: getLocalOrders(), error: null };
  }

  try {
    const { data, error } = await supabase
      .from('pedidos')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Erro ao listar pedidos no Supabase:', error);
      return { data: getLocalOrders(), error: null };
    }

    const formatted = (data || []).map((item) => ({
      ...item,
      valor: Number(item.valor) || 0,
    }));

    return { data: formatted as Pedido[], error: null };
  } catch (err: any) {
    return { data: getLocalOrders(), error: null };
  }
}

/**
 * Criar novo pedido (Administrador ou Carrinho)
 */
export async function createOrder(payload: {
  codigo: string;
  nome_cliente: string;
  cpf?: string;
  produto: string;
  cor?: string;
  valor: number;
  observacao?: string;
  status_pagamento: PaymentStatus;
  imagem_url?: string | null;
  itens?: any[] | null;
  frete?: 'sem_frete' | 'com_frete' | null;
  telefone?: string | null;
  cep?: string | null;
  endereco?: string | null;
  numero?: string | null;
  complemento?: string | null;
  bairro?: string | null;
  cidade?: string | null;
  estado?: string | null;
  valor_produto?: number | null;
  valor_desconto?: number | null;
  valor_frete?: number | null;
  valor_total?: number | null;
  cupom_codigo?: string | null;
  cupom_porcentagem?: number | null;
  forma_pagamento?: string | null;
  prazo_frete?: string | null;
  nome_regiao_frete?: string | null;
  tipo_entrega?: 'retirada' | 'entrega' | null;
}): Promise<{ data: Pedido | null; error: string | null }> {
  const itensFormatados: CartItem[] = (payload.itens || []).map((it) => {
    const unitPrice = Number(it.preco_unitario ?? it.price ?? 0);
    const qty = Math.max(1, Number(it.quantidade ?? 1));
    const pName = String(it.nome_produto || it.name || payload.produto);
    return {
      id: String(it.id || it.id_produto || `item-${Date.now()}`),
      id_produto: String(it.id_produto || it.id || 'produto'),
      nome_produto: pName,
      preco_unitario: unitPrice,
      quantidade: qty,
      subtotal: Number(it.subtotal ?? (unitPrice * qty)),
      cor: it.cor || it.color || null,
      potencia: it.potencia || it.power || null,
      imagem: it.imagem || it.image || null,
      estoque: it.estoque ?? null,
    };
  });

  // Validação segura dos valores: se valor_produto e valor_frete foram fornecidos, valida o total
  const finalValorProduto = payload.valor_produto !== undefined && payload.valor_produto !== null
    ? Number(payload.valor_produto)
    : Number(payload.valor);
  const finalValorDesconto = payload.valor_desconto !== undefined && payload.valor_desconto !== null
    ? Number(payload.valor_desconto)
    : 0;
  const finalValorFrete = payload.valor_frete !== undefined && payload.valor_frete !== null
    ? Number(payload.valor_frete)
    : (payload.frete === 'com_frete' ? 0 : 0);
  const finalValorTotal = payload.valor_total !== undefined && payload.valor_total !== null
    ? Number(payload.valor_total)
    : Math.max(0, finalValorProduto - finalValorDesconto + finalValorFrete);

  const newOrderBase: Pedido = {
    id: `local-${Date.now()}`,
    codigo: payload.codigo.trim().toUpperCase(),
    nome_cliente: payload.nome_cliente.trim(),
    cpf: payload.cpf ? payload.cpf.trim() : undefined,
    produto: payload.produto.trim(),
    cor: payload.cor ? payload.cor.trim() : undefined,
    valor: finalValorTotal,
    observacao: payload.observacao ? payload.observacao.trim() : undefined,
    status_pagamento: payload.status_pagamento,
    imagem_url: payload.imagem_url || undefined,
    itens: itensFormatados.length > 0 ? itensFormatados : undefined,
    frete: payload.frete || (finalValorFrete > 0 ? 'com_frete' : 'sem_frete'),
    telefone: payload.telefone ? payload.telefone.trim() : null,
    cep: payload.cep ? payload.cep.trim() : null,
    endereco: payload.endereco ? payload.endereco.trim() : null,
    numero: payload.numero ? payload.numero.trim() : null,
    complemento: payload.complemento ? payload.complemento.trim() : null,
    bairro: payload.bairro ? payload.bairro.trim() : null,
    cidade: payload.cidade ? payload.cidade.trim() : null,
    estado: payload.estado ? payload.estado.trim() : null,
    valor_produto: finalValorProduto,
    valor_desconto: finalValorDesconto,
    valor_frete: finalValorFrete,
    valor_total: finalValorTotal,
    cupom_codigo: payload.cupom_codigo ? payload.cupom_codigo.trim().toUpperCase() : null,
    cupom_porcentagem: payload.cupom_porcentagem !== undefined && payload.cupom_porcentagem !== null ? Number(payload.cupom_porcentagem) : null,
    forma_pagamento: payload.forma_pagamento || null,
    prazo_frete: payload.prazo_frete || null,
    nome_regiao_frete: payload.nome_regiao_frete || null,
    tipo_entrega: payload.tipo_entrega || (payload.frete === 'com_frete' ? 'entrega' : 'retirada'),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  if (!isSupabaseConfigured()) {
    const list = getLocalOrders();
    list.unshift(newOrderBase);
    saveLocalOrders(list);
    return { data: newOrderBase, error: null };
  }

  try {
    const insertData: Record<string, any> = {
      codigo: newOrderBase.codigo,
      nome_cliente: newOrderBase.nome_cliente,
      cpf: newOrderBase.cpf || null,
      produto: newOrderBase.produto,
      cor: newOrderBase.cor || null,
      valor: Number(newOrderBase.valor),
      observacao: newOrderBase.observacao || null,
      status_pagamento: newOrderBase.status_pagamento,
      frete: newOrderBase.frete || 'sem_frete',
      telefone: newOrderBase.telefone,
      cep: newOrderBase.cep,
      endereco: newOrderBase.endereco,
      cidade: newOrderBase.cidade,
      estado: newOrderBase.estado,
      valor_produto: newOrderBase.valor_produto,
      valor_desconto: newOrderBase.valor_desconto,
      valor_frete: newOrderBase.valor_frete,
      valor_total: newOrderBase.valor_total,
      cupom_codigo: newOrderBase.cupom_codigo,
      cupom_porcentagem: newOrderBase.cupom_porcentagem,
      forma_pagamento: newOrderBase.forma_pagamento,
      prazo_frete: newOrderBase.prazo_frete,
      nome_regiao_frete: newOrderBase.nome_regiao_frete,
      tipo_entrega: newOrderBase.tipo_entrega
    };

    if (newOrderBase.imagem_url) {
      insertData.imagem_url = newOrderBase.imagem_url;
    }

    if (itensFormatados.length > 0) {
      insertData.itens = itensFormatados;
    }

    let result = await supabase
      .from('pedidos')
      .insert([insertData])
      .select()
      .single();

    // Tratamento resiliente caso a tabela no Supabase ainda não possua certas colunas novas
    if (result.error) {
      const retryData = { ...insertData };
      const optionalCols = [
        'telefone', 'cep', 'endereco', 'cidade', 'estado', 
        'valor_produto', 'valor_desconto', 'valor_frete', 'valor_total',
        'cupom_codigo', 'cupom_porcentagem',
        'forma_pagamento', 'prazo_frete', 'nome_regiao_frete', 'tipo_entrega',
        'itens', 'imagem_url', 'frete'
      ];

      for (const col of optionalCols) {
        if (result.error.message && result.error.message.includes(col)) {
          delete retryData[col];
        }
      }

      result = await supabase.from('pedidos').insert([retryData]).select().single();

      // Se ainda der erro, tenta com apenas as colunas fundamentais
      if (result.error) {
        const minimalData = {
          codigo: newOrderBase.codigo,
          nome_cliente: newOrderBase.nome_cliente,
          cpf: newOrderBase.cpf || null,
          produto: newOrderBase.produto,
          cor: newOrderBase.cor || null,
          valor: Number(newOrderBase.valor),
          observacao: newOrderBase.observacao || null,
          status_pagamento: newOrderBase.status_pagamento,
        };
        result = await supabase.from('pedidos').insert([minimalData]).select().single();
      }
    }

    if (result.error) {
      if (result.error.code === '23505') {
        return { data: null, error: 'Já existe um pedido cadastrado com esse código. Por favor, utilize outro código.' };
      }
      // Fallback local caso falhe
      const list = getLocalOrders();
      list.unshift(newOrderBase);
      saveLocalOrders(list);
      return { data: newOrderBase, error: null };
    }

    const savedOrder = {
      ...newOrderBase,
      ...result.data,
      valor: Number(result.data.valor) || finalValorTotal,
      itens: result.data.itens || (itensFormatados.length > 0 ? itensFormatados : undefined),
    } as Pedido;

    // Atualiza cache local
    const list = getLocalOrders();
    list.unshift(savedOrder);
    saveLocalOrders(list);

    // Se houver itens e a tabela itens_pedido existir, insere os registros vinculados
    if (itensFormatados.length > 0 && savedOrder.id) {
      try {
        const itensPedidoRows = itensFormatados.map((it) => ({
          pedido_id: savedOrder.id,
          id_produto: it.id_produto,
          nome_produto: it.nome_produto,
          preco_unitario: it.preco_unitario,
          quantidade: it.quantidade,
          subtotal: it.subtotal,
          cor: it.cor,
        }));
        await supabase.from('itens_pedido').insert(itensPedidoRows);
      } catch (e) {
        // Silencioso se tabela opcional ainda não existir
      }
    }

    return {
      data: savedOrder,
      error: null,
    };
  } catch (err: any) {
    const list = getLocalOrders();
    list.unshift(newOrderBase);
    saveLocalOrders(list);
    return { data: newOrderBase, error: null };
  }
}

/**
 * Atualizar pedido existente (Administrador)
 */
export async function updateOrder(
  id: string,
  payload: {
    codigo: string;
    nome_cliente: string;
    cpf?: string;
    produto: string;
    cor?: string;
    valor: number;
    observacao?: string;
    status_pagamento: PaymentStatus;
    imagem_url?: string | null;
    frete?: 'sem_frete' | 'com_frete' | null;
    itens?: any[] | null;
    telefone?: string | null;
    cep?: string | null;
    endereco?: string | null;
    numero?: string | null;
    complemento?: string | null;
    bairro?: string | null;
    cidade?: string | null;
    estado?: string | null;
    valor_produto?: number | null;
    valor_desconto?: number | null;
    valor_frete?: number | null;
    valor_total?: number | null;
    cupom_codigo?: string | null;
    cupom_porcentagem?: number | null;
    forma_pagamento?: string | null;
    prazo_frete?: string | null;
    nome_regiao_frete?: string | null;
    tipo_entrega?: 'retirada' | 'entrega' | null;
  }
): Promise<{ data: Pedido | null; error: string | null }> {
  const finalValorTotal = payload.valor_total !== undefined && payload.valor_total !== null
    ? Number(payload.valor_total)
    : Number(payload.valor);

  if (!isSupabaseConfigured()) {
    const list = getLocalOrders();
    const idx = list.findIndex((o) => o.id === id);
    if (idx >= 0) {
      list[idx] = {
        ...list[idx],
        codigo: payload.codigo.trim().toUpperCase(),
        nome_cliente: payload.nome_cliente.trim(),
        cpf: payload.cpf ? payload.cpf.trim() : undefined,
        produto: payload.produto.trim(),
        cor: payload.cor ? payload.cor.trim() : undefined,
        valor: finalValorTotal,
        observacao: payload.observacao ? payload.observacao.trim() : undefined,
        status_pagamento: payload.status_pagamento,
        imagem_url: payload.imagem_url !== undefined ? (payload.imagem_url || undefined) : list[idx].imagem_url,
        frete: payload.frete !== undefined ? payload.frete : (list[idx].frete || 'sem_frete'),
        itens: payload.itens !== undefined ? payload.itens : list[idx].itens,
        telefone: payload.telefone !== undefined ? payload.telefone : list[idx].telefone,
        cep: payload.cep !== undefined ? payload.cep : list[idx].cep,
        endereco: payload.endereco !== undefined ? payload.endereco : list[idx].endereco,
        numero: payload.numero !== undefined ? payload.numero : list[idx].numero,
        complemento: payload.complemento !== undefined ? payload.complemento : list[idx].complemento,
        bairro: payload.bairro !== undefined ? payload.bairro : list[idx].bairro,
        cidade: payload.cidade !== undefined ? payload.cidade : list[idx].cidade,
        estado: payload.estado !== undefined ? payload.estado : list[idx].estado,
        valor_produto: payload.valor_produto !== undefined ? payload.valor_produto : list[idx].valor_produto,
        valor_desconto: payload.valor_desconto !== undefined ? payload.valor_desconto : list[idx].valor_desconto,
        valor_frete: payload.valor_frete !== undefined ? payload.valor_frete : list[idx].valor_frete,
        valor_total: finalValorTotal,
        cupom_codigo: payload.cupom_codigo !== undefined ? payload.cupom_codigo : list[idx].cupom_codigo,
        cupom_porcentagem: payload.cupom_porcentagem !== undefined ? payload.cupom_porcentagem : list[idx].cupom_porcentagem,
        forma_pagamento: payload.forma_pagamento !== undefined ? payload.forma_pagamento : list[idx].forma_pagamento,
        prazo_frete: payload.prazo_frete !== undefined ? payload.prazo_frete : list[idx].prazo_frete,
        nome_regiao_frete: payload.nome_regiao_frete !== undefined ? payload.nome_regiao_frete : list[idx].nome_regiao_frete,
        tipo_entrega: payload.tipo_entrega !== undefined ? payload.tipo_entrega : list[idx].tipo_entrega,
        updated_at: new Date().toISOString(),
      };
      saveLocalOrders(list);
      return { data: list[idx], error: null };
    }
    return { data: null, error: 'Pedido não localizado.' };
  }

  try {
    const adminCode = getStoredAdminCode();

    // 1. Tentar primeiro via RPC protegida do Supabase
    try {
      const { data: rpcData, error: rpcError } = await supabase.rpc('admin_atualizar_pedido', {
        p_admin_code: adminCode,
        p_pedido_id: id,
        p_codigo: payload.codigo.trim().toUpperCase(),
        p_nome_cliente: payload.nome_cliente.trim(),
        p_cpf: payload.cpf ? payload.cpf.trim() : null,
        p_produto: payload.produto.trim(),
        p_cor: payload.cor ? payload.cor.trim() : null,
        p_valor: Number(payload.valor),
        p_observacao: payload.observacao ? payload.observacao.trim() : null,
        p_status: payload.status_pagamento,
        p_imagem_url: payload.imagem_url || null,
      });

      if (!rpcError && rpcData) {
        // Se a RPC funcionou, também atualizamos frete caso a coluna exista
        if (payload.frete || payload.itens) {
          try {
            const extraUpdate: Record<string, any> = {};
            if (payload.frete) extraUpdate.frete = payload.frete;
            if (payload.itens !== undefined) extraUpdate.itens = payload.itens;
            await supabase.from('pedidos').update(extraUpdate).eq('id', id);
            if (payload.frete) rpcData.frete = payload.frete;
            if (payload.itens !== undefined) rpcData.itens = payload.itens;
          } catch (e) {}
        }
        return {
          data: {
            ...rpcData,
            valor: Number(rpcData.valor) || 0,
            frete: payload.frete || rpcData.frete || 'sem_frete',
            itens: payload.itens !== undefined ? payload.itens : rpcData.itens,
          } as Pedido,
          error: null,
        };
      }
    } catch (rpcErr) {
      // Continua para fallback padrão se a RPC ainda não existir no banco
    }

    // 2. Fallback via update direto
    const updateData: Record<string, any> = {
      codigo: payload.codigo.trim().toUpperCase(),
      nome_cliente: payload.nome_cliente.trim(),
      cpf: payload.cpf ? payload.cpf.trim() : null,
      produto: payload.produto.trim(),
      cor: payload.cor ? payload.cor.trim() : null,
      valor: finalValorTotal,
      observacao: payload.observacao ? payload.observacao.trim() : null,
      status_pagamento: payload.status_pagamento,
      frete: payload.frete || 'sem_frete',
      updated_at: new Date().toISOString(),
    };

    if (payload.imagem_url !== undefined) updateData.imagem_url = payload.imagem_url;
    if (payload.itens !== undefined) updateData.itens = payload.itens;
    if (payload.telefone !== undefined) updateData.telefone = payload.telefone;
    if (payload.cep !== undefined) updateData.cep = payload.cep;
    if (payload.endereco !== undefined) updateData.endereco = payload.endereco;
    if (payload.cidade !== undefined) updateData.cidade = payload.cidade;
    if (payload.estado !== undefined) updateData.estado = payload.estado;
    if (payload.valor_produto !== undefined) updateData.valor_produto = payload.valor_produto;
    if (payload.valor_desconto !== undefined) updateData.valor_desconto = payload.valor_desconto;
    if (payload.valor_frete !== undefined) updateData.valor_frete = payload.valor_frete;
    if (payload.valor_total !== undefined) updateData.valor_total = payload.valor_total;
    if (payload.cupom_codigo !== undefined) updateData.cupom_codigo = payload.cupom_codigo;
    if (payload.cupom_porcentagem !== undefined) updateData.cupom_porcentagem = payload.cupom_porcentagem;
    if (payload.prazo_frete !== undefined) updateData.prazo_frete = payload.prazo_frete;
    if (payload.forma_pagamento !== undefined) updateData.forma_pagamento = payload.forma_pagamento;
    if (payload.nome_regiao_frete !== undefined) updateData.nome_regiao_frete = payload.nome_regiao_frete;
    if (payload.tipo_entrega !== undefined) updateData.tipo_entrega = payload.tipo_entrega;

    let { data, error } = await supabase
      .from('pedidos')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      // Se houver erro de coluna nova inexistente no Supabase, tenta update seguro
      const safeData: Record<string, any> = {
        codigo: updateData.codigo,
        nome_cliente: updateData.nome_cliente,
        cpf: updateData.cpf,
        produto: updateData.produto,
        cor: updateData.cor,
        valor: updateData.valor,
        observacao: updateData.observacao,
        status_pagamento: updateData.status_pagamento,
        updated_at: updateData.updated_at,
      };
      if (updateData.frete) safeData.frete = updateData.frete;
      const retry = await supabase.from('pedidos').update(safeData).eq('id', id).select().single();
      if (retry.error) {
        if (retry.error.code === '23505') {
          return { data: null, error: 'Já existe outro pedido com esse código.' };
        }
        return { data: null, error: retry.error.message };
      }
      data = retry.data;
    }

    const finalOrder = {
      ...data,
      valor: finalValorTotal,
      frete: payload.frete || data?.frete || 'sem_frete',
      itens: payload.itens !== undefined ? payload.itens : data?.itens,
      telefone: payload.telefone !== undefined ? payload.telefone : data?.telefone,
      cep: payload.cep !== undefined ? payload.cep : data?.cep,
      endereco: payload.endereco !== undefined ? payload.endereco : data?.endereco,
      numero: payload.numero !== undefined ? payload.numero : data?.numero,
      complemento: payload.complemento !== undefined ? payload.complemento : data?.complemento,
      bairro: payload.bairro !== undefined ? payload.bairro : data?.bairro,
      cidade: payload.cidade !== undefined ? payload.cidade : data?.cidade,
      estado: payload.estado !== undefined ? payload.estado : data?.estado,
      valor_produto: payload.valor_produto !== undefined ? payload.valor_produto : (data?.valor_produto ?? finalValorTotal),
      valor_frete: payload.valor_frete !== undefined ? payload.valor_frete : (data?.valor_frete ?? 0),
      valor_total: finalValorTotal,
      forma_pagamento: payload.forma_pagamento !== undefined ? payload.forma_pagamento : data?.forma_pagamento,
      prazo_frete: payload.prazo_frete !== undefined ? payload.prazo_frete : data?.prazo_frete,
      nome_regiao_frete: payload.nome_regiao_frete !== undefined ? payload.nome_regiao_frete : data?.nome_regiao_frete,
      tipo_entrega: payload.tipo_entrega !== undefined ? payload.tipo_entrega : data?.tipo_entrega,
    } as Pedido;

    return {
      data: finalOrder,
      error: null,
    };
  } catch (err: any) {
    return { data: null, error: err.message || 'Falha ao atualizar pedido.' };
  }
}

/**
 * Atualizar status do pagamento (ex: Marcar como Pago / Confirmar pagamento)
 */
export async function updateOrderStatus(id: string, status: PaymentStatus): Promise<{ success: boolean; error: string | null }> {
  if (!isSupabaseConfigured()) {
    const list = getLocalOrders();
    const idx = list.findIndex((o) => o.id === id);
    if (idx >= 0) {
      list[idx].status_pagamento = status;
      list[idx].updated_at = new Date().toISOString();
      saveLocalOrders(list);
    }
    return { success: true, error: null };
  }

  try {
    const adminCode = getStoredAdminCode();

    // 1. Tentar primeiro via RPC segura
    try {
      const { data: rpcSuccess, error: rpcError } = await supabase.rpc('admin_atualizar_status_pedido', {
        p_admin_code: adminCode,
        p_pedido_id: id,
        p_novo_status: status,
      });

      if (!rpcError && rpcSuccess) {
        return { success: true, error: null };
      }
    } catch (rpcErr) {
      // Continua para fallback padrão se a RPC ainda não tiver sido criada
    }

    // 2. Fallback
    const { error } = await supabase
      .from('pedidos')
      .update({
        status_pagamento: status,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id);

    if (error) {
      return { success: false, error: error.message };
    }

    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err.message || 'Falha ao alterar status.' };
  }
}

/**
 * Excluir pedido (Administrador)
 */
export async function deleteOrder(id: string): Promise<{ success: boolean; error: string | null }> {
  if (!isSupabaseConfigured()) {
    const list = getLocalOrders();
    const filtered = list.filter((o) => o.id !== id);
    saveLocalOrders(filtered);
    return { success: true, error: null };
  }

  try {
    const adminCode = getStoredAdminCode();

    // 0. Excluir registros vinculados na tabela itens_pedido se existir
    try {
      await supabase.from('itens_pedido').delete().eq('pedido_id', id);
    } catch (e) {}

    // 1. Tentar primeiro via RPC segura do Supabase
    try {
      const { data: rpcSuccess, error: rpcError } = await supabase.rpc('admin_excluir_pedido', {
        p_admin_code: adminCode,
        p_pedido_id: id,
      });

      if (!rpcError && rpcSuccess) {
        return { success: true, error: null };
      }
    } catch (rpcErr) {
      // Continua para fallback
    }

    // 2. Fallback
    const { error } = await supabase
      .from('pedidos')
      .delete()
      .eq('id', id);

    if (error) {
      return { success: false, error: error.message };
    }

    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err.message || 'Falha ao excluir pedido.' };
  }
}
