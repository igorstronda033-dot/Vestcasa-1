import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { CouponConfig } from '../types';

export const DEFAULT_COUPON_CODE = 'CLUBE2026';
const LOCAL_STORAGE_KEY = 'vestcasa_coupon_CLUBE2026';

export const INITIAL_COUPON_CONFIG: CouponConfig = {
  codigo: DEFAULT_COUPON_CODE,
  porcentagem: 10,
  ativo: true,
  descricao: 'Cupom Oficial Clube Vestcasa',
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString()
};

/**
 * Lê a configuração salva localmente como contingência rápida e offline
 */
export function getLocalCouponConfig(): CouponConfig {
  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.codigo) {
          return {
            ...INITIAL_COUPON_CONFIG,
            ...parsed,
            codigo: String(parsed.codigo).trim().toUpperCase(),
            porcentagem: Math.max(0, Math.min(100, Number(parsed.porcentagem) || 0)),
            ativo: Boolean(parsed.ativo)
          };
        }
      }
    } catch (e) {
      console.warn('Erro ao ler cupom local:', e);
    }
  }
  return { ...INITIAL_COUPON_CONFIG };
}

/**
 * Salva a configuração localmente
 */
export function saveLocalCouponConfig(config: CouponConfig): void {
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(config));
      window.dispatchEvent(new CustomEvent('vestcasa_coupon_updated', { detail: config }));
    } catch (e) {
      console.warn('Erro ao salvar cupom local:', e);
    }
  }
}

/**
 * Busca a configuração oficial do cupom (do banco de dados Supabase com fallback local resiliente)
 */
export async function getCouponConfig(code: string = DEFAULT_COUPON_CODE): Promise<CouponConfig> {
  const normalizedCode = code.trim().toUpperCase();

  if (isSupabaseConfigured()) {
    try {
      // 1. Tenta buscar na tabela 'cupons' se existir
      const { data: cupomRow, error: cupomError } = await supabase
        .from('cupons')
        .select('*')
        .eq('codigo', normalizedCode)
        .maybeSingle();

      if (!cupomError && cupomRow) {
        const result: CouponConfig = {
          codigo: cupomRow.codigo,
          porcentagem: Number(cupomRow.porcentagem) || 0,
          ativo: Boolean(cupomRow.ativo),
          descricao: cupomRow.descricao || null,
          created_at: cupomRow.created_at,
          updated_at: cupomRow.updated_at
        };
        saveLocalCouponConfig(result);
        return result;
      }

      // 2. Se a tabela 'cupons' não existir, tenta ler da tabela de 'configuracoes'
      const { data: configRow, error: configError } = await supabase
        .from('configuracoes')
        .select('valor')
        .eq('chave', `cupom_${normalizedCode}`)
        .maybeSingle();

      if (!configError && configRow?.valor) {
        try {
          const parsed = typeof configRow.valor === 'string' ? JSON.parse(configRow.valor) : configRow.valor;
          const result: CouponConfig = {
            codigo: normalizedCode,
            porcentagem: Number(parsed.porcentagem) || 0,
            ativo: Boolean(parsed.ativo),
            descricao: parsed.descricao || null,
            updated_at: parsed.updated_at || new Date().toISOString()
          };
          saveLocalCouponConfig(result);
          return result;
        } catch (e) {}
      }
    } catch (err) {
      console.warn('Supabase offline ou sem tabela de cupons, usando configuração local:', err);
    }
  }

  // Retorna a configuração local persistida
  return getLocalCouponConfig();
}

/**
 * Salva as alterações feitas pelo Administrador na área ADM
 * O novo percentual e status passam a valer imediatamente para as próximas utilizações.
 */
export async function saveCouponConfig(newConfig: {
  codigo?: string;
  porcentagem: number;
  ativo: boolean;
  descricao?: string | null;
}): Promise<{ success: boolean; data: CouponConfig; error: string | null }> {
  const cleanCode = (newConfig.codigo || DEFAULT_COUPON_CODE).trim().toUpperCase();
  const cleanPct = Math.max(0, Math.min(100, Number(newConfig.porcentagem) || 0));
  const cleanAtivo = Boolean(newConfig.ativo);

  const updatedConfig: CouponConfig = {
    codigo: cleanCode,
    porcentagem: cleanPct,
    ativo: cleanAtivo,
    descricao: newConfig.descricao || `Cupom ${cleanCode} Vestcasa`,
    updated_at: new Date().toISOString()
  };

  // Salva no armazenamento persistente local imediatamente
  saveLocalCouponConfig(updatedConfig);

  if (isSupabaseConfigured()) {
    try {
      // 1. Tenta salvar na tabela 'cupons'
      const { error: cupomError } = await supabase
        .from('cupons')
        .upsert({
          codigo: cleanCode,
          porcentagem: cleanPct,
          ativo: cleanAtivo,
          descricao: updatedConfig.descricao,
          updated_at: updatedConfig.updated_at
        }, { onConflict: 'codigo' });

      if (!cupomError) {
        return { success: true, data: updatedConfig, error: null };
      }

      // 2. Se a tabela 'cupons' não existir, tenta salvar em 'configuracoes'
      const { error: configError } = await supabase
        .from('configuracoes')
        .upsert({
          chave: `cupom_${cleanCode}`,
          valor: JSON.stringify(updatedConfig),
          updated_at: updatedConfig.updated_at
        }, { onConflict: 'chave' });

      if (!configError) {
        return { success: true, data: updatedConfig, error: null };
      }
    } catch (err: any) {
      console.warn('Erro ao sincronizar cupom no Supabase:', err);
    }
  }

  return { success: true, data: updatedConfig, error: null };
}

export interface CouponValidationResult {
  valid: boolean;
  message: string;
  codigo?: string;
  porcentagem?: number;
  ativo?: boolean;
  valorOriginalProduto: number;
  valorDesconto: number;
  valorProdutoComDesconto: number;
}

/**
 * Validação segura de cupom:
 * 1. Verifica se o cupom existe
 * 2. Se está ativo
 * 3. Qual é a porcentagem configurada no banco/persistência
 * 4. Valor original do produto
 * 5. Valor correto do desconto (apenas sobre o produto)
 * 6. Valor final do produto com desconto
 */
export async function validateAndApplyCoupon(
  inputCode: string,
  originalProductAmount: number
): Promise<CouponValidationResult> {
  const cleanInput = inputCode?.trim().toUpperCase();

  const baseReturn: CouponValidationResult = {
    valid: false,
    message: '',
    valorOriginalProduto: originalProductAmount,
    valorDesconto: 0,
    valorProdutoComDesconto: originalProductAmount
  };

  if (!cleanInput) {
    return { ...baseReturn, message: 'Por favor, informe o código do cupom.' };
  }

  // Busca a configuração atual autoritativa
  const config = await getCouponConfig(cleanInput);

  // Validação 1: O código digitado precisa corresponder ao cupom
  if (cleanInput !== config.codigo.toUpperCase()) {
    return {
      ...baseReturn,
      message: `Cupom "${cleanInput}" inválido ou não encontrado.`
    };
  }

  // Validação 2: Verificar se o cupom está ativo
  if (!config.ativo) {
    return {
      ...baseReturn,
      message: `O cupom ${config.codigo} está temporariamente desativado.`
    };
  }

  // Validação 3: Porcentagem configurada
  const porcentagem = Math.max(0, Math.min(100, Number(config.porcentagem) || 0));
  if (porcentagem <= 0) {
    return {
      ...baseReturn,
      message: `O cupom ${config.codigo} não possui desconto configurado no momento.`
    };
  }

  // Validação 4 & 5: Aplicação da fórmula solicitada pelo usuário
  // Desconto = valor do produto * porcentagem / 100
  const valorDesconto = Math.round((originalProductAmount * (porcentagem / 100)) * 100) / 100;
  const valorProdutoComDesconto = Math.max(0, originalProductAmount - valorDesconto);

  return {
    valid: true,
    message: `Cupom ${config.codigo} aplicado!`,
    codigo: config.codigo,
    porcentagem: porcentagem,
    ativo: true,
    valorOriginalProduto: originalProductAmount,
    valorDesconto: valorDesconto,
    valorProdutoComDesconto: valorProdutoComDesconto
  };
}
