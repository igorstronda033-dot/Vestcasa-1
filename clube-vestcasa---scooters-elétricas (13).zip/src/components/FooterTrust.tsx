import React from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Phone, 
  Mail, 
  Clock, 
  MapPin, 
  QrCode, 
  CreditCard, 
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { RainbowBar } from './RainbowBar';

interface FooterTrustProps {
  onAdminClick?: () => void;
  onClientClick: () => void;
  onCatalogClick?: () => void;
}

export const FooterTrust: React.FC<FooterTrustProps> = ({ 
  onAdminClick, 
  onClientClick,
  onCatalogClick 
}) => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#0f1713] text-slate-300 pt-14 pb-10 border-t border-slate-800 text-xs selection:bg-emerald-500 selection:text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Main Grid: 6 Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8 pb-12 border-b border-slate-800">
          
          {/* Column 1: Vestcasa Brand (Spans 2 columns on lg) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex flex-col items-start select-none">
              <div className="flex items-baseline text-4xl sm:text-5xl lg:text-6xl font-black italic tracking-tight text-white">
                <span className="text-white mr-2">Clube</span>
                <span className="text-white">Vestcasa</span>
              </div>
              <div className="w-48 sm:w-56 mt-2">
                <RainbowBar height="h-1 sm:h-1.5" rounded="rounded-full" />
              </div>
            </div>

            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-sm">
              Líder em inovação e utilidades no Brasil, trazendo agora mobilidade elétrica sustentável, econômica e acessível para o dia a dia de famílias e empreendedores.
            </p>

            <div className="pt-2 text-[11px] text-slate-400 space-y-1">
              <p>Vestcasa Indústria e Comércio de Utilidades LTDA.</p>
              <p>CNPJ: 07.869.756/0001-08</p>
              <p className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#00c853] shrink-0" />
                <span>São Paulo / SP • Atendimento em todo o território nacional</span>
              </p>
            </div>
          </div>

          {/* Column 2: Institucional */}
          <div className="space-y-3">
            <h4 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
              Institucional
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button 
                  onClick={onClientClick} 
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Sobre a Vestcasa
                </button>
              </li>
              <li>
                <button 
                  onClick={onCatalogClick || onClientClick} 
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Nossas Lojas (+100)
                </button>
              </li>
              <li>
                <button 
                  onClick={onCatalogClick || onClientClick} 
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Mobilidade Elétrica
                </button>
              </li>
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Trabalhe Conosco
                </span>
              </li>
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Sustentabilidade & ESG
                </span>
              </li>
            </ul>
          </div>

          {/* Column 3: Atendimento */}
          <div className="space-y-3">
            <h4 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
              Atendimento
            </h4>
            <ul className="space-y-2.5 text-slate-400">
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#00c853] shrink-0" />
                <a 
                  href="https://wa.me/5511971583047" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  (11) 97158-3047 (WhatsApp)
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#00c853] shrink-0" />
                <span>sac@vestcasa.com.br</span>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="w-3.5 h-3.5 text-[#00c853] shrink-0 mt-0.5" />
                <span>Seg. a Sex.: 08h às 18h<br />Sáb.: 09h às 14h</span>
              </li>
              <li className="pt-1">
                <button
                  onClick={onClientClick}
                  className="text-xs font-bold text-[#00c853] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Consultar Meu Pedido</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Políticas */}
          <div className="space-y-3">
            <h4 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
              Políticas
            </h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Política de Privacidade
                </span>
              </li>
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Termos de Uso
                </span>
              </li>
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Trocas e Devoluções (CDC)
                </span>
              </li>
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Garantia de Fábrica
                </span>
              </li>
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Regras de Retirada em Loja
                </span>
              </li>
            </ul>
          </div>

          {/* Column 5: Formas de Pagamento & Segurança */}
          <div className="space-y-3">
            <h4 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
              Pagamento & Segurança
            </h4>
            <div className="space-y-3">
              {/* PIX Badge */}
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2">
                <QrCode className="w-5 h-5 text-[#00c853]" />
                <div>
                  <span className="font-bold text-white block">PIX Oficial</span>
                  <span className="text-[10px] text-slate-400">Liquidação Instantânea</span>
                </div>
              </div>

              {/* SSL & LGPD Badge */}
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-yellow-400" />
                <div>
                  <span className="font-bold text-white block">SSL 256-Bit</span>
                  <span className="text-[10px] text-slate-400">Proteção de Dados LGPD</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Strip: Social Media, Legal Copyright, Admin Lock */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <p className="text-center sm:text-left">
            © {currentYear} Clube Vestcasa • Scooters Elétricas. Todos os direitos reservados.
          </p>

          <div className="flex items-center gap-4">
            <span className="text-slate-400">Siga a Vestcasa:</span>
            <span className="hover:text-white cursor-pointer transition-colors">Instagram</span>
            <span>•</span>
            <span className="hover:text-white cursor-pointer transition-colors">Facebook</span>
            <span>•</span>
            <span className="hover:text-white cursor-pointer transition-colors">YouTube</span>
            <span>•</span>
            <span className="hover:text-white cursor-pointer transition-colors">TikTok</span>

            {/* Discreet Admin Lock */}
            {onAdminClick && (
              <button 
                onClick={onAdminClick}
                className="text-slate-700 hover:text-slate-400 transition-colors p-1 ml-2 cursor-pointer"
                title="Acesso Administrativo Restrito"
                aria-label="Painel Administrativo"
              >
                <Lock className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

      </div>
    </footer>
  );
};
