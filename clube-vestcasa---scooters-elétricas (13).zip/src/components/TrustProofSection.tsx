import React from 'react';
import { ShieldCheck, CreditCard, Headphones, HeartHandshake, Truck } from 'lucide-react';

export const TrustProofSection: React.FC = () => {
  const trustPoints = [
    {
      icon: ShieldCheck,
      title: 'Compra Segura',
      description: 'Plataforma protegida com criptografia e validação de pedidos.',
      badge: '100% Protegido',
    },
    {
      icon: CreditCard,
      title: 'Pagamento Protegido',
      description: 'PIX oficial com liquidação rápida e verificação instantânea de chave.',
      badge: 'PIX Seguro',
    },
    {
      icon: Headphones,
      title: 'Atendimento Especializado',
      description: 'Consultores de mobilidade prontos para tirar dúvidas pelo WhatsApp.',
      badge: 'Suporte Direto',
    },
    {
      icon: HeartHandshake,
      title: 'Suporte ao Cliente',
      description: 'Acompanhamento do status em tempo real através do código único.',
      badge: 'Pós-Venda',
    },
    {
      icon: Truck,
      title: 'Entrega Acompanhada',
      description: 'Opção de retirada imediata ou envio com rastreamento detalhado.',
      badge: 'Garantido',
    },
  ];

  return (
    <section className="py-12 bg-white border-y border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-[11px] font-black uppercase tracking-widest text-[#008f43] bg-emerald-50 border border-emerald-200/60 px-3 py-1 rounded-full">
            Segurança & Confiabilidade
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-3">
            Por que confiar na Mobilidade Vestcasa?
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-2">
            Mais de 100 lojas em todo o Brasil e a tranquilidade de comprar de uma marca consolidada.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {trustPoints.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="group p-5 rounded-2xl bg-stone-50/70 border border-slate-200/80 hover:bg-white hover:border-[#00a650] hover:shadow-[0_10px_25px_-5px_rgba(0,166,80,0.12)] transition-all duration-300 flex flex-col items-start justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-white group-hover:bg-[#00a650] border border-slate-200/80 group-hover:border-[#00a650] text-[#008f43] group-hover:text-white flex items-center justify-center mb-4 shadow-2xs transition-colors">
                    <Icon className="w-6 h-6 stroke-[1.8]" />
                  </div>
                  <h3 className="text-sm font-black text-slate-900 mb-1.5 group-hover:text-[#005c2d] transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {item.description}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-200/60 w-full flex items-center justify-between text-[10px] font-bold text-slate-400 group-hover:text-[#008f43]">
                  <span>{item.badge}</span>
                  <span className="text-xs">✓</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
