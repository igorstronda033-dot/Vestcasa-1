import React, { useState, useEffect } from 'react';
import { ShoppingBag, CheckCircle2, X } from 'lucide-react';
import { listAllOrders } from '../services/orderService';
import { Pedido } from '../types';

export const RealTimePurchasesToast: React.FC = () => {
  const [realOrders, setRealOrders] = useState<Pedido[]>([]);
  const [activeOrder, setActiveOrder] = useState<Pedido | null>(null);
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [dismissed, setDismissed] = useState<boolean>(false);

  useEffect(() => {
    // Fetch ONLY real orders from Supabase database
    listAllOrders()
      .then(({ data }) => {
        if (data && data.length > 0) {
          // Filter valid orders only (not cancelled)
          const validOrders = data.filter(
            (o) => o.status_pagamento !== 'Cancelado' && o.produto
          );
          setRealOrders(validOrders);
        }
      })
      .catch((err) => {
        console.error('Error fetching real orders for notifications:', err);
      });
  }, []);

  useEffect(() => {
    // Rule: If there are NO real orders in the database, do not show any popup
    if (realOrders.length === 0 || dismissed) return;

    // Show a notification every 35 seconds, display it for 5 seconds
    const interval = setInterval(() => {
      const order = realOrders[currentIndex % realOrders.length];
      setActiveOrder(order);
      setIsVisible(true);

      const hideTimeout = setTimeout(() => {
        setIsVisible(false);
        setCurrentIndex((prev) => prev + 1);
      }, 5500);

      return () => clearTimeout(hideTimeout);
    }, 35000);

    // Initial trigger after 8 seconds of browsing
    const initialTimer = setTimeout(() => {
      if (realOrders.length > 0) {
        setActiveOrder(realOrders[0]);
        setIsVisible(true);
        setTimeout(() => {
          setIsVisible(false);
          setCurrentIndex(1);
        }, 5500);
      }
    }, 8000);

    return () => {
      clearInterval(interval);
      clearTimeout(initialTimer);
    };
  }, [realOrders, currentIndex, dismissed]);

  if (!activeOrder || !isVisible || dismissed) {
    return null;
  }

  // Sanitize customer data: NEVER show full name, NEVER show full address
  const getSanitizedCustomerName = (fullName?: string) => {
    if (!fullName || fullName.trim().length === 0) return 'Cliente';
    const first = fullName.trim().split(' ')[0];
    return first.charAt(0).toUpperCase() + first.slice(1).toLowerCase();
  };

  const customerFirstName = getSanitizedCustomerName(activeOrder.nome_cliente);
  const productName = activeOrder.produto || 'Scooter Elétrica Vestcasa';

  return (
    <div
      className="fixed bottom-4 left-4 sm:bottom-6 sm:left-6 z-40 max-w-[290px] sm:max-w-[340px] bg-white/95 backdrop-blur-md rounded-2xl p-3 sm:p-3.5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.12)] border border-slate-200/90 text-slate-800 transition-all duration-300 animate-in fade-in slide-in-from-bottom-3"
      role="status"
      aria-live="polite"
    >
      <div className="flex items-start gap-2.5 sm:gap-3">
        {/* Icon */}
        <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-emerald-50 border border-emerald-200 text-[#00a650] flex items-center justify-center shrink-0 shadow-2xs">
          <ShoppingBag className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          <div className="flex items-center gap-1.5 text-[10px] sm:text-[11px] font-bold text-emerald-700 uppercase tracking-wide">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>Compra Confirmada no Sistema</span>
          </div>

          <p className="text-xs sm:text-xs font-black text-slate-900 truncate mt-0.5">
            {customerFirstName} adquiriu {productName}
          </p>

          <p className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
            <CheckCircle2 className="w-3 h-3 text-[#00a650]" />
            <span>Registro oficial em loja Vestcasa</span>
          </p>
        </div>

        {/* Dismiss Button */}
        <button
          type="button"
          onClick={() => {
            setIsVisible(false);
            setDismissed(true);
          }}
          className="text-slate-400 hover:text-slate-600 p-1 -mr-1 -mt-1 cursor-pointer transition-colors"
          aria-label="Fechar notificação"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
