import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  CreditCard,
  MessageCircle,
  Banknote
} from 'lucide-react';
import { Pedido } from '../types';
import { reportPaymentDone } from '../services/orderService';

interface PaymentModalProps {
  pedido: Pedido;
  onClose: () => void;
  onPaymentReported: () => void;
}

type PaymentMethod = 'pix' | 'cartao';

const WHATSAPP_AVISTA_URL = 'https://wa.me/5511971583047?text=Olá%21%20Estou%20finalizando%20meu%20pedido%20pelo%20site%20Vestcasa%20Scooters%20e%20gostaria%20de%20informar%20que%20vou%20realizar%20o%20pagamento%20à%20vista.';

export const PaymentModal: React.FC<PaymentModalProps> = ({ 
  pedido, 
  onClose, 
  onPaymentReported 
}) => {
  if (!pedido || !pedido.codigo) return null;

  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('pix');
  const [reportedSuccess, setReportedSuccess] = useState(false);
  const [reportedMessage, setReportedMessage] = useState<string>('');

  // Cartão de Crédito State (Simulação de Parcelas 1x a 12x)
  const [selectedInstallments, setSelectedInstallments] = useState<number>(12);
  const valorTotal = pedido.valor || 0;
  const valorParcela = Math.round((valorTotal / (selectedInstallments || 1)) * 100) / 100;

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(val);
  };

  const handleSolicitarLinkPagamento = () => {
    const msg = `Olá! Quero finalizar meu pedido no cartão de crédito.

Código do pedido: ${pedido.codigo}
Valor total: ${formatCurrency(valorTotal)}
Parcelamento escolhido: ${selectedInstallments}x de ${formatCurrency(valorParcela)}

Gostaria de receber o link de pagamento.`;

    const whatsappUrl = `https://wa.me/5511971583047?text=${encodeURIComponent(msg)}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  const handleInformarPagamentoWhatsApp = async () => {
    if (pedido?.id) {
      try {
        await reportPaymentDone(pedido.id, {
          method: 'PIX à Vista',
          detailsText: 'Cliente informou pagamento à vista via WhatsApp'
        });
        setReportedSuccess(true);
        setReportedMessage('Aviso registrado! O pedido permanece aguardando conferência do pagamento.');
        onPaymentReported();
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        id="modal-pagamento-pedido"
        className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="bg-[#005c2d] text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-white/15 flex items-center justify-center">
              {selectedMethod === 'pix' ? (
                <Banknote className="w-5 h-5 text-yellow-300" />
              ) : (
                <CreditCard className="w-5 h-5 text-yellow-300" />
              )}
            </div>
            <div>
              <h3 className="font-extrabold text-base leading-tight">Pagamento do Pedido</h3>
              <p className="text-xs text-emerald-200 font-mono">Código: {pedido.codigo}</p>
            </div>
          </div>
          <button
            id="btn-fechar-pagamento"
            onClick={onClose}
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="Fechar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Order Details Summary */}
        <div className="bg-slate-50 border-b border-slate-200 p-4 shrink-0">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-slate-500 font-medium">Cliente:</span>
              <p className="font-bold text-slate-800 truncate">{pedido.nome_cliente}</p>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Produto:</span>
              <p className="font-bold text-slate-800 truncate">{pedido.produto} {pedido.cor ? `(${pedido.cor})` : ''}</p>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Status Atual:</span>
              <p className="font-bold text-amber-700">{pedido.status_pagamento}</p>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Valor Total:</span>
              <p className="font-black text-emerald-700 text-sm">{formatCurrency(pedido.valor)}</p>
            </div>
          </div>
        </div>

        {/* Payment Tabs (À Vista e Cartão de Crédito) */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200">
            <button
              id="tab-pagamento-pix"
              type="button"
              onClick={() => setSelectedMethod('pix')}
              className={`py-2.5 px-3 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
                selectedMethod === 'pix'
                  ? 'bg-[#00a650] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Banknote className="w-4 h-4 shrink-0" />
              <span>Pagamento à Vista</span>
            </button>

            <button
              id="tab-pagamento-cartao"
              type="button"
              onClick={() => setSelectedMethod('cartao')}
              className={`py-2.5 px-3 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
                selectedMethod === 'cartao'
                  ? 'bg-[#00a650] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CreditCard className="w-4 h-4 shrink-0" />
              <span>Cartão de Crédito</span>
            </button>
          </div>

          {/* TAB 1: DADOS PARA PAGAMENTO À VISTA */}
          {selectedMethod === 'pix' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-5 text-slate-800 space-y-3.5 shadow-2xs">
                <div className="text-center space-y-1 pb-1 border-b border-slate-200">
                  <h4 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center justify-center gap-1.5 uppercase">
                    💳 DADOS PARA PAGAMENTO À VISTA
                  </h4>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed">
                  Para valores inferiores a R$ 30.000,00, os recebimentos são direcionados à conta do sócio majoritário responsável pelo setor financeiro, conforme os dados abaixo:
                </p>

                <div className="bg-white border-2 border-emerald-500/40 rounded-xl p-3.5 sm:p-4 space-y-2.5 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 border-b border-slate-100">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Chave Pix (CNPJ):</span>
                    <span className="text-sm font-black font-mono text-emerald-800 select-all">
                      61.873.556/0001-87
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 border-b border-slate-100">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Instituição:</span>
                    <span className="text-xs sm:text-sm font-bold text-slate-800">
                      NU PAGAMENTOS – IP
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Responsável financeiro:</span>
                    <span className="text-xs sm:text-sm font-bold text-slate-800">
                      Maria Eduarda Silva
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  Para valores acima de R$ 30.000,00, são utilizados os dados bancários do CNPJ da empresa Vestcasa.
                </p>

                <p className="text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg p-2.5">
                  Após a transferência, encaminhe o comprovante para conferência.
                </p>
              </div>

              {/* Botão para WhatsApp */}
              <div className="pt-1">
                <a
                  id="btn-informar-pagamento-whatsapp-modal"
                  href={WHATSAPP_AVISTA_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={handleInformarPagamentoWhatsApp}
                  className="w-full py-4 px-4 bg-[#25D366] hover:bg-[#20ba59] active:scale-[0.99] text-white font-black text-xs sm:text-sm rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wider text-center group"
                >
                  <span>🟢 INFORMAR PAGAMENTO PELO WHATSAPP</span>
                </a>
              </div>
            </div>
          )}

          {/* TAB 2: CARTÃO DE CRÉDITO - PAGAMENTO COM CARTÃO DE CRÉDITO */}
          {selectedMethod === 'cartao' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="text-center space-y-1">
                <h4 className="text-lg font-black text-slate-900 uppercase tracking-tight">
                  PAGAMENTO COM CARTÃO DE CRÉDITO
                </h4>
                <p className="text-xs text-slate-600 font-semibold">
                  Simule seu parcelamento no cartão
                </p>
              </div>

              {/* Seletor visual de parcelas de 1x a 12x */}
              <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black uppercase text-slate-800 tracking-wide block">
                    Escolha as parcelas (1x até 12x):
                  </label>
                  <span className="text-xs font-bold text-[#00a650] font-mono">
                    {selectedInstallments}x selecionado
                  </span>
                </div>

                {/* Grade visual de botões de 1x a 12x */}
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((num) => {
                    const valParc = Math.round((valorTotal / num) * 100) / 100;
                    const isSelected = selectedInstallments === num;

                    return (
                      <button
                        key={num}
                        type="button"
                        onClick={() => setSelectedInstallments(num)}
                        className={`p-2 sm:p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#00a650] text-white border-[#008f43] shadow-sm font-black ring-2 ring-emerald-500/20 scale-[1.02]'
                            : 'bg-stone-50 hover:bg-slate-100 text-slate-700 border-slate-200 font-bold'
                        }`}
                      >
                        <span className="text-xs sm:text-sm font-black block">{num}x</span>
                        <span className={`text-[10px] block truncate ${isSelected ? 'text-yellow-200 font-bold' : 'text-slate-500 font-medium'}`}>
                          {formatCurrency(valParc)}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Seletor Dropdown Completo */}
                <div className="pt-1 border-t border-slate-100">
                  <select
                    id="select-parcelas-modal"
                    value={selectedInstallments}
                    onChange={(e) => setSelectedInstallments(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border border-slate-300 bg-stone-50 focus:bg-white text-xs font-bold text-slate-800 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20 outline-none cursor-pointer"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((num) => {
                      const valParc = Math.round((valorTotal / num) * 100) / 100;
                      return (
                        <option key={num} value={num}>
                          {num}x de {formatCurrency(valParc)}
                        </option>
                      );
                    })}
                  </select>
                </div>
              </div>

              {/* Quando o cliente selecionar uma parcela, mostrar:
                  Valor do pedido: R$ X.XXX,XX
                  Parcelamento escolhido: 12x de R$ XXX,XX
                  Total: R$ X.XXX,XX
              */}
              <div className="p-4 bg-stone-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-600">
                  <span className="font-semibold">Valor do pedido:</span>
                  <strong className="font-mono text-slate-900 text-sm">{formatCurrency(valorTotal)}</strong>
                </div>

                <div className="flex items-center justify-between text-emerald-950 font-bold bg-emerald-100/70 p-2.5 rounded-xl border border-emerald-300">
                  <span>Parcelamento escolhido:</span>
                  <strong className="font-mono text-emerald-800 text-sm sm:text-base">
                    {selectedInstallments}x de {formatCurrency(valorParcela)}
                  </strong>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-200">
                  <span className="text-slate-900 font-extrabold uppercase">Total:</span>
                  <span className="text-base sm:text-lg font-black text-[#005c2d] font-mono">
                    {formatCurrency(valorTotal)}
                  </span>
                </div>
              </div>

              {/* Botão verde grande: SOLICITAR LINK DE PAGAMENTO */}
              <button
                type="button"
                id="btn-solicitar-link-pagamento-modal"
                onClick={handleSolicitarLinkPagamento}
                className="w-full py-4 px-5 bg-[#25D366] hover:bg-[#20ba59] active:scale-[0.99] text-white font-black text-sm sm:text-base rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2.5 uppercase tracking-wider cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 fill-white stroke-none shrink-0" />
                <span>SOLICITAR LINK DE PAGAMENTO</span>
              </button>
            </div>
          )}

          {/* Feedback message if reported */}
          {reportedSuccess ? (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>{reportedMessage || 'Aviso enviado ao administrador! O status do seu pedido foi atualizado para "Cliente informou pagamento".'}</span>
            </div>
          ) : null}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="py-2.5 px-5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-xl transition-all cursor-pointer"
          >
            Fechar Modal
          </button>
        </div>
      </div>
    </div>
  );
};
