import React, { useState } from 'react';
import { 
  Zap, 
  CheckCircle2, 
  Bike, 
  Send, 
  Check, 
  Sparkles, 
  Phone, 
  ShieldCheck, 
  Eye, 
  Store, 
  Truck, 
  ShoppingBag,
  BatteryCharging,
  ArrowRight
} from 'lucide-react';
import { ScooterModel } from '../types';
import { useCart } from '../context/CartContext';
import { getScooterModels } from '../services/scooterService';

const COLOR_CONFIGS: Record<string, { hex: string; border: string }> = {
  'Vermelho': { hex: '#dc2626', border: 'border-red-500' },
  'Preto': { hex: '#0f172a', border: 'border-slate-800' },
  'Branco': { hex: '#ffffff', border: 'border-slate-300' },
};

interface ScooterCatalogProps {
  onNavigateToConsultation?: () => void;
  onOpenProductModal?: (model: ScooterModel) => void;
  onBuyNow?: (model: ScooterModel, color?: string) => void;
}

export const ScooterCatalog: React.FC<ScooterCatalogProps> = ({ 
  onNavigateToConsultation,
  onOpenProductModal,
  onBuyNow,
}) => {
  const models = getScooterModels();
  const { addToCart, setIsCartOpen } = useCart();
  const [selectedModel, setSelectedModel] = useState<ScooterModel>(models[0]);
  const [selectedColor, setSelectedColor] = useState<string>(models[0]?.colors[0] || 'Vermelho');
  const [tipoRecebimento, setTipoRecebimento] = useState<'retirada' | 'entrega'>('retirada');
  const [selectionFeedback, setSelectionFeedback] = useState<string | null>(null);
  const [cartToast, setCartToast] = useState<string | null>(null);

  const whatsappPhone = '5511971583047';

  const handleAddToCartSelected = () => {
    if (onBuyNow) {
      onBuyNow(selectedModel, selectedColor);
      return;
    }

    const res = addToCart({
      id: selectedModel.id,
      name: selectedModel.name,
      price: selectedModel.price,
      power: selectedModel.power,
      image: selectedModel.image,
      color: selectedColor,
      estoque: selectedModel.estoque,
    }, 1);

    if (res.success) {
      setCartToast(res.message);
      setIsCartOpen(true);
      setTimeout(() => setCartToast(null), 4000);
    } else {
      alert(res.message);
    }
  };

  const handleQuickAddToCart = (model: ScooterModel, e: React.MouseEvent) => {
    e.stopPropagation();
    const defaultColor = model.colors[0] || 'Vermelho';

    if (onBuyNow) {
      onBuyNow(model, defaultColor);
      return;
    }

    const res = addToCart({
      id: model.id,
      name: model.name,
      price: model.price,
      power: model.power,
      image: model.image,
      color: defaultColor,
      estoque: model.estoque,
    }, 1);

    if (res.success) {
      setCartToast(res.message);
      setIsCartOpen(true);
      setTimeout(() => setCartToast(null), 4000);
    } else {
      alert(res.message);
    }
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(val);
  };

  const handleSelectModel = (model: ScooterModel) => {
    setSelectedModel(model);
    if (!model.colors.includes(selectedColor)) {
      setSelectedColor(model.colors[0] || 'Vermelho');
    }
    setSelectionFeedback(`Você selecionou a ${model.name} (${model.power})`);
    setTimeout(() => {
      setSelectionFeedback(null);
    }, 4000);

    const el = document.getElementById('painel-modelo-selecionado');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  };

  const generateWhatsappMessage = () => {
    const opcaoRecebimento = tipoRecebimento === 'retirada'
      ? 'Retirada na Loja / CD'
      : 'Entrega em Domicílio (Sob consulta de frete/CEP)';

    return `Olá! Quero comprar uma scooter elétrica na Vestcasa.\n\nModelo: ${selectedModel.name}\nPotência: ${selectedModel.power}\nCor: ${selectedColor}\nOpção de Recebimento: ${opcaoRecebimento}\nPreço: ${formatCurrency(selectedModel.price)}`;
  };

  const handleSendWhatsapp = () => {
    const message = generateWhatsappMessage();
    const encodedMessage = encodeURIComponent(message);
    const url = `https://wa.me/${whatsappPhone}?text=${encodedMessage}`;
    window.open(url, '_blank');
  };

  return (
    <section id="secao-catalogo" className="max-w-7xl mx-auto px-4 sm:px-6 py-14">
      {/* Header Badge */}
      <div className="flex justify-center mb-3">
        <div className="inline-flex items-center gap-1.5 bg-[#004d25] text-emerald-300 px-4 py-1.5 rounded-full text-xs font-black tracking-wide shadow-xs uppercase">
          <Sparkles className="w-3.5 h-3.5 text-[#ffd000]" />
          <span>Catálogo Oficial de Mobilidade</span>
        </div>
      </div>

      {/* Main Section Title */}
      <div className="text-center mb-10">
        <h2 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight">
          Nossa Linha de Scooters Elétricas
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-2 max-w-xl mx-auto leading-relaxed">
          Veículos elétricos silenciosos, econômicos e sustentáveis. Escolha seu modelo, configure as cores ou adquira direto com código de pedido.
        </p>
      </div>

      {/* Dynamic Feedback Toast when model is selected or item added to cart */}
      {cartToast && (
        <div className="max-w-xl mx-auto mb-6 bg-[#00a650] text-white px-5 py-3 rounded-2xl text-center text-xs sm:text-sm font-bold shadow-md flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-yellow-300 shrink-0" />
            <span>{cartToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setIsCartOpen(true)}
            className="bg-white text-[#005c2d] px-3 py-1 rounded-xl text-xs font-black hover:bg-emerald-50 transition-colors uppercase tracking-wider cursor-pointer"
          >
            Ver Carrinho
          </button>
        </div>
      )}

      {selectionFeedback && !cartToast && (
        <div className="max-w-xl mx-auto mb-8 bg-emerald-50 border border-[#00a650] text-emerald-950 px-4 py-3 rounded-2xl text-center text-xs sm:text-sm font-bold shadow-xs flex items-center justify-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-[#00a650] shrink-0" />
          <span>{selectionFeedback} — Detalhes e cores atualizados abaixo!</span>
        </div>
      )}

      {/* 4 Cards Grid - Modern, Premium, Consistent Sizing, Non-distorted Images */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16 items-stretch">
        {models.map((model) => {
          const isSelected = selectedModel.name === model.name;
          const installment = model.price / 12;

          return (
            <div
              key={model.id}
              id={`card-scooter-${model.id}`}
              onClick={() => handleSelectModel(model)}
              className={`group relative bg-white rounded-2xl border transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-pointer ${
                isSelected
                  ? 'border-[#00a650] shadow-[0_12px_28px_-6px_rgba(0,166,80,0.22),0_4px_12px_-2px_rgba(0,0,0,0.06)] ring-2 ring-emerald-500/20 -translate-y-1'
                  : 'border-slate-200/90 shadow-[0_2px_12px_-2px_rgba(0,0,0,0.04)] hover:border-emerald-500/60 hover:shadow-[0_14px_30px_-6px_rgba(0,0,0,0.09),0_4px_14px_-2px_rgba(0,166,80,0.09)] hover:-translate-y-1'
              }`}
            >
              {/* 1. IMAGEM DA SCOOTER - Studio Display Container with subtle zoom */}
              <div className="relative w-full h-56 sm:h-60 bg-gradient-to-b from-stone-50/90 via-slate-100/30 to-white flex items-center justify-center p-6 border-b border-slate-100/90 overflow-hidden select-none">
                {/* Promo Badge */}
                <div className="absolute top-3.5 left-3.5 z-10">
                  {model.badge ? (
                    <span className="inline-flex items-center gap-1 bg-[#00a650] text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-full shadow-xs">
                      {model.badge}
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 bg-white/90 text-slate-600 text-[10px] font-bold px-2.5 py-1 rounded-full border border-slate-200/80 shadow-2xs">
                      100% Elétrica
                    </span>
                  )}
                </div>

                {/* Power Badge */}
                <div className="absolute top-3.5 right-3.5 z-10">
                  <span className="inline-flex items-center gap-1 bg-slate-900 text-[#ffd000] text-[11px] font-black px-2.5 py-1 rounded-lg shadow-xs tracking-tight">
                    <Zap className="w-3 h-3 fill-[#ffd000]" />
                    <span>{model.power}</span>
                  </span>
                </div>

                {/* Soft floor shadow */}
                <div className="absolute bottom-5 left-1/2 -translate-x-1/2 w-48 sm:w-52 h-3.5 bg-slate-900/10 rounded-[100%] blur-[5px] pointer-events-none transition-all duration-500 group-hover:scale-x-110 group-hover:opacity-80" />

                {/* Vehicle Image */}
                <div className="relative z-1 w-full h-full flex items-center justify-center">
                  <img
                    src={model.image}
                    alt={`Scooter Elétrica ${model.name}`}
                    loading="lazy"
                    className="max-h-full max-w-full object-contain filter drop-shadow-[0_8px_16px_rgba(0,0,0,0.08)] group-hover:drop-shadow-[0_16px_26px_rgba(0,0,0,0.14)] group-hover:scale-[1.05] transition-all duration-500 ease-out will-change-transform select-none"
                  />
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-3">
                  {/* Model Name & Power */}
                  <div>
                    <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider block">
                      Modelo
                    </span>
                    <div className="flex items-baseline justify-between gap-2">
                      <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight group-hover:text-[#005c2d] transition-colors">
                        {model.name}
                      </h3>
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                        {model.power}
                      </span>
                    </div>
                  </div>

                  {/* Description & Autonomia */}
                  <div className="space-y-2">
                    <p className="text-xs text-slate-500 leading-relaxed line-clamp-2 min-h-[32px]">
                      {model.description}
                    </p>

                    <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs text-slate-500">
                      <span className="flex items-center gap-1 font-medium">
                        <BatteryCharging className="w-3.5 h-3.5 text-[#00a650]" />
                        {model.autonomia || 'Até 40 km'}
                      </span>
                      <div className="flex items-center gap-1.5" title={model.colors.join(', ')}>
                        {model.colors.map((color) => {
                          const conf = COLOR_CONFIGS[color] || { hex: '#475569', border: 'border-slate-400' };
                          return (
                            <span
                              key={color}
                              className={`w-3 h-3 rounded-full border shadow-2xs ${conf.border}`}
                              style={{ backgroundColor: conf.hex }}
                              title={color}
                            />
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Pricing Block with Old Price */}
                  <div className="pt-2 border-t border-slate-100 space-y-0.5">
                    {model.oldPrice && (
                      <span className="text-[11px] text-slate-400 line-through block font-medium">
                        De {formatCurrency(model.oldPrice)}
                      </span>
                    )}
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-2xl sm:text-3xl font-black text-[#008f43] tracking-tight">
                        {formatCurrency(model.price)}
                      </span>
                      <span className="text-[10px] font-black text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded">
                        À VISTA
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500 font-medium block">
                      ou 12x de {formatCurrency(installment)}
                    </span>
                  </div>
                </div>

                {/* Card Action Buttons: Ver Detalhes + Comprar */}
                <div className="space-y-2 pt-2">
                  <div className="grid grid-cols-2 gap-2">
                    {/* Botão Ver Detalhes */}
                    <button
                      type="button"
                      id={`btn-detalhes-${model.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (onOpenProductModal) {
                          onOpenProductModal(model);
                        } else {
                          handleSelectModel(model);
                        }
                      }}
                      className="py-2.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                    >
                      <Eye className="w-3.5 h-3.5 text-slate-500" />
                      <span>Detalhes</span>
                    </button>

                    {/* Botão Comprar (Adiciona ao Carrinho) */}
                    <button
                      type="button"
                      id={`btn-comprar-${model.id}`}
                      onClick={(e) => handleQuickAddToCart(model, e)}
                      className="py-2.5 px-2 bg-[#00a650] hover:bg-[#008f43] text-white rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 shadow-xs active:scale-95 cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5 text-yellow-300" />
                      <span>Comprar</span>
                    </button>
                  </div>

                  {/* Botão Secundário para Configurar Cores no Estúdio */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectModel(model);
                    }}
                    className={`w-full py-2 rounded-xl text-[11px] font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer ${
                      isSelected
                        ? 'text-[#005c2d] bg-emerald-50'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <span>{isSelected ? '✓ Cor selecionada' : 'Personalizar Cores'}</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Painel da Scooter Selecionada com Estúdio de Detalhes e Cores */}
      <div 
        id="painel-modelo-selecionado" 
        className="bg-white rounded-3xl border-2 border-[#00a650] shadow-xl overflow-hidden scroll-mt-24"
      >
        <div className="bg-[#005c2d] text-white px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <Bike className="w-5 h-5 text-[#ffd000]" />
            <h3 className="text-base sm:text-lg font-black uppercase tracking-wider">
              CONFIGURAR MODELO: {selectedModel.name} ({selectedModel.power})
            </h3>
          </div>
          <div className="flex items-center gap-2 text-xs text-emerald-200">
            <ShieldCheck className="w-4 h-4 text-[#ffd000]" />
            <span>Garantia de Fábrica & Nota Fiscal</span>
          </div>
        </div>

        <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Foto Grande em Estúdio do Modelo Selecionado */}
          <div className="lg:col-span-5 bg-gradient-to-b from-stone-50 via-slate-100/40 to-stone-50 rounded-2xl p-6 border border-slate-200/90 flex flex-col items-center justify-center text-center relative min-h-[300px]">
            <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-3/4 max-w-[260px] h-4 bg-slate-900/10 rounded-[100%] blur-[6px] pointer-events-none" />

            <div className="relative z-1 w-full max-w-[320px] h-64 flex items-center justify-center">
              <img
                src={selectedModel.image}
                alt={`Scooter ${selectedModel.name} ${selectedColor}`}
                loading="lazy"
                className="max-h-full max-w-full object-contain filter drop-shadow-[0_16px_24px_rgba(0,0,0,0.14)] select-none"
              />
            </div>

            <div className="mt-4 inline-flex items-center gap-2 bg-white/95 px-4 py-1.5 rounded-full border border-slate-200 shadow-2xs text-xs font-extrabold text-slate-800">
              <span className="w-2.5 h-2.5 rounded-full bg-[#00a650]" />
              <span>Cor Selecionada: {selectedColor.toUpperCase()}</span>
            </div>
          </div>

          {/* Opções de Configuração e Compra */}
          <div className="lg:col-span-7 space-y-6">
            <div>
              <span className="text-xs font-bold uppercase text-[#008f43] tracking-wider">
                Mobilidade Elétrica Inteligente
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-0.5">
                {selectedModel.name} - {selectedModel.power}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                {selectedModel.description}
              </p>
            </div>

            {/* Seletor de Cores */}
            <div className="space-y-2.5">
              <label className="text-xs font-black uppercase text-slate-900 tracking-wider flex items-center justify-between">
                <span>Escolha a cor da carenagem:</span>
                <span className="text-[#008f43] font-bold">{selectedColor}</span>
              </label>

              <div className="grid grid-cols-3 gap-2.5">
                {selectedModel.colors.map((color) => {
                  const conf = COLOR_CONFIGS[color] || { hex: '#475569', border: 'border-slate-400' };
                  const isColorActive = selectedColor === color;

                  return (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setSelectedColor(color)}
                      className={`p-3 rounded-2xl border-2 flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                        isColorActive
                          ? 'border-[#00a650] bg-emerald-50 text-[#005c2d] ring-2 ring-emerald-500/20 shadow-xs'
                          : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <span
                        className={`w-4 h-4 rounded-full border shadow-2xs shrink-0 ${conf.border}`}
                        style={{ backgroundColor: conf.hex }}
                      />
                      <span className="text-xs font-extrabold">{color}</span>
                      {isColorActive && (
                        <Check className="w-3.5 h-3.5 text-[#00a650] stroke-[3]" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Opções de Recebimento */}
            <div className="space-y-2.5">
              <label className="text-xs font-black uppercase text-slate-900 tracking-wider block">
                Forma de Recebimento:
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  id="opcao-recebimento-retirada"
                  onClick={() => setTipoRecebimento('retirada')}
                  className={`p-3.5 rounded-2xl border-2 text-left transition-all flex items-start gap-3 cursor-pointer ${
                    tipoRecebimento === 'retirada'
                      ? 'border-[#00a650] bg-emerald-50/70 text-slate-900 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className={`p-2 rounded-xl shrink-0 ${
                    tipoRecebimento === 'retirada' ? 'bg-[#00a650] text-white shadow-xs' : 'bg-slate-100 text-slate-600'
                  }`}>
                    <Store className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="font-black text-sm text-slate-900 block">Retirada na Loja / CD</span>
                    <p className="text-xs text-slate-500 mt-1 leading-snug">
                      Retire diretamente no Centro de Distribuição ou Loja Física Vestcasa.
                    </p>
                  </div>
                  {tipoRecebimento === 'retirada' && (
                    <Check className="w-4 h-4 text-[#00a650] shrink-0 mt-0.5 stroke-[3]" />
                  )}
                </button>

                <button
                  type="button"
                  id="opcao-recebimento-entrega"
                  onClick={() => setTipoRecebimento('entrega')}
                  className={`p-3.5 rounded-2xl border-2 text-left transition-all flex items-start gap-3 cursor-pointer ${
                    tipoRecebimento === 'entrega'
                      ? 'border-[#00a650] bg-emerald-50/70 text-slate-900 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className={`p-2 rounded-xl shrink-0 ${
                    tipoRecebimento === 'entrega' ? 'bg-[#00a650] text-white shadow-xs' : 'bg-slate-100 text-slate-600'
                  }`}>
                    <Truck className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-black text-sm text-slate-900">Entrega em Domicílio</span>
                      <span className="text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full shrink-0">
                        Sob Consulta
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1 leading-snug">
                      Envio seguro via transportadora especializada com rastreio e nota fiscal.
                    </p>
                  </div>
                  {tipoRecebimento === 'entrega' && (
                    <Check className="w-4 h-4 text-[#00a650] shrink-0 mt-0.5 stroke-[3]" />
                  )}
                </button>
              </div>
            </div>

            {/* Prévia da Mensagem do Pedido */}
            <div className="bg-emerald-50/60 border border-emerald-200/90 rounded-2xl p-4">
              <span className="text-[11px] font-extrabold text-emerald-950 uppercase block mb-1.5">
                Resumo da mensagem para o WhatsApp:
              </span>
              <div className="bg-white p-3.5 rounded-xl border border-emerald-100 font-mono text-xs text-slate-800 whitespace-pre-line shadow-2xs">
                {generateWhatsappMessage()}
              </div>
            </div>

            {/* Botões de Finalização */}
            <div className="space-y-2.5">
              {/* Botão Adicionar ao Carrinho do Modelo Configurado */}
              <button
                type="button"
                id="btn-adicionar-carrinho-painel"
                onClick={handleAddToCartSelected}
                className="w-full py-4 bg-gradient-to-r from-[#00a650] to-[#008f43] hover:from-[#008f43] hover:to-[#007335] text-white font-black text-sm sm:text-base rounded-2xl shadow-lg hover:shadow-xl active:scale-[0.99] transition-all flex items-center justify-center gap-2.5 uppercase tracking-wide cursor-pointer"
              >
                <ShoppingBag className="w-5 h-5 text-yellow-300" />
                <span>ADICIONAR {selectedModel.name} ({selectedColor.toUpperCase()}) AO CARRINHO</span>
              </button>

              {onNavigateToConsultation && (
                <button
                  type="button"
                  id="btn-ir-consultar-pedido"
                  onClick={onNavigateToConsultation}
                  className="w-full py-3 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs sm:text-sm rounded-2xl border border-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Eye className="w-4 h-4 text-[#006e33]" />
                  <span>JÁ TEM UM PEDIDO? CONSULTAR CÓDIGO PARA PAGAR</span>
                </button>
              )}

              <button
                type="button"
                id="btn-pedir-whatsapp-modelo"
                onClick={handleSendWhatsapp}
                className="w-full py-3.5 bg-gradient-to-r from-[#ffd000] to-[#fbc02d] hover:brightness-105 text-slate-950 font-black text-sm sm:text-base rounded-2xl shadow-md hover:shadow-lg active:scale-[0.99] transition-all flex items-center justify-center gap-2 uppercase tracking-wide cursor-pointer"
              >
                <span>CONCLUIR PEDIDO DA {selectedModel.name.toUpperCase()} VIA WHATSAPP</span>
                <Send className="w-4 h-4 text-slate-950" />
              </button>
              <div className="flex items-center justify-center gap-1.5 text-xs text-slate-500 font-medium">
                <Phone className="w-3.5 h-3.5 text-[#00a650]" />
                <span>WhatsApp Oficial Vestcasa: +55 (11) 97158-3047</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
