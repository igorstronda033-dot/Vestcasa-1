import React, { useState } from 'react';
import { ChevronDown, HelpCircle, MessageSquare } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'Como funciona a compra no site?',
      answer: 'É muito simples: você escolhe o modelo de scooter elétrica desejado (MU02, MU03, MU09 ou MU04), seleciona a cor e adiciona ao carrinho. Ao finalizar, o sistema gera o código exclusivo do seu pedido. Com esse código, você consulta o pedido e realiza o pagamento seguro via PIX (QR Code).',
    },
    {
      question: 'Quais são as formas de pagamento aceitas?',
      answer: 'O pagamento principal é via PIX oficial com confirmação rápida e geração automática de QR Code e chave Copia e Cola. Para opções de parcelamento no cartão de crédito em até 12x, você também pode solicitar o link de pagamento através do nosso atendimento oficial.',
    },
    {
      question: 'Como acompanho o andamento do meu pedido?',
      answer: 'Basta acessar a aba "Consultar Pedido" no topo do site e digitar o código gerado no momento da compra (ex: VEST-...). Você verá o status atualizado em tempo real (Pendente, Aguardando confirmação ou Pago) e poderá visualizar as instruções de entrega ou retirada.',
    },
    {
      question: 'Como funciona a entrega e a retirada?',
      answer: 'Você pode optar por retirar o veículo diretamente em um de nossos Centros de Distribuição ou Lojas Vestcasa habilitadas sem custo de frete, ou solicitar entrega em domicílio para a sua região com frete calculado pela nossa equipe de logística.',
    },
    {
      question: 'As scooters elétricas têm garantia de fábrica?',
      answer: 'Sim! Todas as scooters comercializadas pela Vestcasa contam com garantia legal e contratual de fábrica contra defeitos de fabricação, além de disponibilidade de peças e suporte técnico oficial.',
    },
    {
      question: 'Como falar com o atendimento ao cliente?',
      answer: 'Nosso canal oficial de atendimento é via WhatsApp pelo número (11) 97158-3047 de segunda a sexta-feira, das 08h às 18h, e aos sábados das 09h às 14h. Nossos especialistas estão sempre disponíveis para tirar suas dúvidas.',
    },
  ];

  const handleToggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="secao-faq" className="py-16 bg-stone-50/70 border-t border-slate-200/80">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-1.5 text-[#008f43] bg-emerald-100/70 border border-emerald-200/80 px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider mb-2">
            <HelpCircle className="w-3.5 h-3.5 text-[#00a650]" />
            <span>Tire Suas Dúvidas</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight">
            Perguntas Frequentes
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-2">
            Tudo o que você precisa saber sobre a aquisição das scooters elétricas Vestcasa.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className={`bg-white rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'border-[#00a650] shadow-sm ring-1 ring-emerald-500/10'
                    : 'border-slate-200/80 hover:border-slate-300'
                }`}
              >
                <button
                  type="button"
                  onClick={() => handleToggle(index)}
                  className="w-full p-4 sm:p-5 text-left font-bold text-slate-900 text-sm sm:text-base flex items-center justify-between gap-4 cursor-pointer"
                >
                  <span className="flex-1">{faq.question}</span>
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center transition-transform duration-200 shrink-0 ${
                      isOpen ? 'bg-emerald-100 text-[#006e33] rotate-180' : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-4 sm:px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 animate-in fade-in">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Support contact banner below FAQ */}
        <div className="mt-10 p-6 rounded-2xl bg-emerald-50/80 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#00a650] text-white flex items-center justify-center shrink-0">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-black text-slate-900">Ainda tem dúvidas?</h4>
              <p className="text-xs text-slate-600">Nossa equipe de atendimento está pronta para te atender.</p>
            </div>
          </div>
          <a
            href="https://wa.me/5511971583047?text=Ol%C3%A1!%20Gostaria%20de%20tirar%20uma%20d%C3%BAvida%20sobre%20as%20scooters%20el%C3%A9tricas%20Vestcasa."
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 bg-[#00a650] hover:bg-[#008f43] text-white rounded-xl text-xs font-black uppercase tracking-wide transition-all shadow-xs shrink-0 cursor-pointer"
          >
            Falar no WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
};
