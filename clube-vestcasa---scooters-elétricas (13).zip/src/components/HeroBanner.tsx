import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Bike, 
  CheckCircle2, 
  Sparkles, 
  BatteryCharging, 
  ShieldCheck, 
  Zap, 
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import { RainbowBar } from './RainbowBar';
import imgFlagship from '../assets/images/mu03_official.webp';

interface HeroBannerProps {
  onConsultarClick: () => void;
  onCatalogoClick: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ 
  onConsultarClick, 
  onCatalogoClick 
}) => {
  // Animated counters for store credibility
  const [storesCount, setStoresCount] = useState(0);
  const [followersCount, setFollowersCount] = useState(0);
  const [economyPercent, setEconomyPercent] = useState(0);

  useEffect(() => {
    const duration = 1200;
    const steps = 30;
    const intervalTime = duration / steps;
    let step = 0;

    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      setStoresCount(Math.round(100 * progress));
      setFollowersCount(Math.round(10 * progress));
      setEconomyPercent(Math.round(70 * progress));

      if (step >= steps) {
        clearInterval(timer);
        setStoresCount(100);
        setFollowersCount(10);
        setEconomyPercent(70);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#008f43] via-[#00a650] to-[#007a38] text-white pt-8 sm:pt-14 pb-14 sm:pb-20 px-4 sm:px-6">
      {/* Subtle Geometric Background Pattern */}
      <div className="absolute inset-0 opacity-10 [background-image:radial-gradient(#ffffff_1.5px,transparent_1.5px)] [background-size:24px_24px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* LEFT COLUMN: Headlines, CTAs, Trust Guarantees */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            
            {/* Top Brand Tag */}
            <div className="inline-flex items-center gap-2 bg-black/25 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/20 text-xs sm:text-xs font-black uppercase tracking-wider text-yellow-300 shadow-sm animate-in fade-in duration-500">
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>MOBILIDADE ELÉTRICA OFICIAL • VESTCASA</span>
            </div>

            {/* Main Headline */}
            <div className="space-y-1 sm:space-y-2">
              <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-7xl xl:text-8xl font-black tracking-tight text-white leading-[1.05] sm:leading-[1.05]">
                A Economia Inteligente
              </h1>
              <h2 className="text-4xl sm:text-6xl md:text-7xl lg:text-7xl xl:text-8xl font-black italic tracking-tight text-yellow-300 leading-[1.05] sm:leading-[1.05]">
                Mora Aqui.
              </h2>
            </div>

            {/* Rainbow Accent Bar */}
            <div className="w-48 mx-auto lg:mx-0 py-1">
              <RainbowBar height="h-2" rounded="rounded-full" />
            </div>

            {/* Subtitle */}
            <p className="text-white/95 text-sm sm:text-lg font-medium leading-relaxed max-w-xl mx-auto lg:mx-0">
              Da sua casa ao seu negócio: scooters elétricas de alta durabilidade, zero emissão de poluentes e a maior economia por quilômetro rodado com garantia Vestcasa.
            </p>

            {/* CTAs: Primary "Ver scooters" & Secondary "Saiba mais" (Consultar) */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2">
              {/* Primary Button */}
              <button
                id="btn-hero-ver-scooters"
                onClick={onCatalogoClick}
                className="w-full sm:w-auto py-4 px-8 bg-[#ffd000] hover:bg-[#ffbe00] active:scale-[0.98] text-slate-950 font-black text-sm sm:text-base rounded-2xl shadow-[0_10px_25px_-5px_rgba(255,208,0,0.4)] transition-all flex items-center justify-center gap-2.5 uppercase tracking-wide cursor-pointer group"
              >
                <Bike className="w-5 h-5 text-slate-950 group-hover:scale-110 transition-transform" />
                <span>VER SCOOTERS</span>
                <ArrowRight className="w-4 h-4 text-slate-950 group-hover:translate-x-1 transition-transform" />
              </button>

              {/* Secondary Button */}
              <button
                id="btn-hero-consultar-pedido"
                onClick={onConsultarClick}
                className="w-full sm:w-auto py-4 px-7 bg-white/10 hover:bg-white/20 active:scale-[0.98] text-white font-black text-sm sm:text-base rounded-2xl border border-white/40 backdrop-blur-xs transition-all flex items-center justify-center gap-2 uppercase tracking-wide cursor-pointer"
              >
                <Search className="w-4.5 h-4.5 text-yellow-300" />
                <span>CONSULTAR PEDIDO</span>
              </button>
            </div>

            {/* Trust Proof Bullets */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-y-2 gap-x-4 text-xs font-semibold text-white/90 pt-2">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-yellow-300 shrink-0" />
                <span>Pagamento Protegido via PIX</span>
              </span>
              <span className="hidden sm:inline text-white/40">•</span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-yellow-300 shrink-0" />
                <span>Garantia de Fábrica</span>
              </span>
              <span className="hidden sm:inline text-white/40">•</span>
              <span className="flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-yellow-300 shrink-0" />
                <span>Pronta Entrega & Retirada</span>
              </span>
            </div>

          </div>

          {/* RIGHT COLUMN: Professional Product Studio Showcase */}
          <div className="lg:col-span-5 relative mt-6 lg:mt-0">
            {/* Backdrop Pedestal Glow */}
            <div className="absolute inset-0 bg-radial from-white/20 to-transparent rounded-full filter blur-2xl pointer-events-none" />

            {/* Scooter Showcase Card */}
            <div className="relative bg-white/10 backdrop-blur-md rounded-3xl border border-white/25 p-6 sm:p-8 shadow-2xl overflow-hidden group">
              
              {/* Floating Badge 1: Top Right */}
              <div className="absolute top-4 right-4 bg-slate-900/90 backdrop-blur-md text-yellow-300 text-[10px] sm:text-xs font-black px-3 py-1.5 rounded-full border border-white/10 shadow-lg flex items-center gap-1.5 z-10 animate-in fade-in">
                <Zap className="w-3.5 h-3.5 fill-yellow-400" />
                <span>500W Torque Reforçado</span>
              </div>

              {/* Flagship Image with very subtle hover zoom */}
              <div className="flex items-center justify-center py-4 sm:py-6">
                <img
                  src={imgFlagship}
                  alt="Scooter Elétrica Vestcasa Flagship"
                  className="max-h-64 sm:max-h-80 w-auto object-contain drop-shadow-[0_20px_30px_rgba(0,0,0,0.35)] transition-transform duration-700 group-hover:scale-105 select-none"
                />
              </div>

              {/* Floating Badge 2: Bottom Info Pill */}
              <div className="bg-black/40 backdrop-blur-md rounded-2xl p-3 border border-white/15 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[#ffd000] text-slate-950 flex items-center justify-center font-black">
                    <BatteryCharging className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="block font-black text-white">Autonomia até 45km</span>
                    <span className="block text-[10px] text-white/80">Recarga em tomada comum</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-yellow-300 block font-bold">100% Ecológica</span>
                  <span className="text-xs font-black text-white">Zero Poluição</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* STATS COUNTER ROW (Smooth animated numbers) */}
        <div className="grid grid-cols-3 pt-10 sm:pt-14 mt-10 sm:mt-12 border-t border-white/20 max-w-4xl mx-auto">
          <div className="text-center px-2">
            <span className="block text-2xl sm:text-4xl font-black text-white tracking-tight">
              +{storesCount}
            </span>
            <span className="block text-[10px] sm:text-xs font-bold text-white/85 uppercase tracking-wider mt-1">
              LOJAS FÍSICAS
            </span>
          </div>

          <div className="text-center px-2 border-x border-white/25">
            <span className="block text-2xl sm:text-4xl font-black text-white tracking-tight">
              +{followersCount}M
            </span>
            <span className="block text-[10px] sm:text-xs font-bold text-white/85 uppercase tracking-wider mt-1">
              CLIENTES & SEGUIDORES
            </span>
          </div>

          <div className="text-center px-2">
            <span className="block text-2xl sm:text-4xl font-black text-yellow-300 tracking-tight">
              Até {economyPercent}%
            </span>
            <span className="block text-[10px] sm:text-xs font-bold text-white/85 uppercase tracking-wider mt-1">
              ECONOMIA VS COMBUSTÍVEL
            </span>
          </div>
        </div>

      </div>
    </section>
  );
};
