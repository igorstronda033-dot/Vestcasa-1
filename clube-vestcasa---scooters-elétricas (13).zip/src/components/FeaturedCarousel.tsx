import React, { useRef } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Sparkles, 
  ShoppingBag, 
  Eye, 
  Check, 
  Zap, 
  BatteryCharging 
} from 'lucide-react';
import { ScooterModel } from '../types';
import { useCart } from '../context/CartContext';

interface FeaturedCarouselProps {
  models: ScooterModel[];
  onOpenDetails: (model: ScooterModel) => void;
  onBuyNow?: (model: ScooterModel) => void;
}

export const FeaturedCarousel: React.FC<FeaturedCarouselProps> = ({
  models,
  onOpenDetails,
  onBuyNow,
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const { addToCart, setIsCartOpen } = useCart();

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(val);
  };

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const offset = direction === 'left' ? -clientWidth * 0.75 : clientWidth * 0.75;
      scrollRef.current.scrollTo({ left: scrollLeft + offset, behavior: 'smooth' });
    }
  };

  const handleQuickBuy = (model: ScooterModel, e: React.MouseEvent) => {
    e.stopPropagation();
    if (onBuyNow) {
      onBuyNow(model);
      return;
    }
    const defaultColor = model.colors[0] || 'Vermelho';
    addToCart({
      id: model.id,
      name: model.name,
      price: model.price,
      power: model.power,
      image: model.image,
      color: defaultColor,
      estoque: model.estoque,
    }, 1);
    setIsCartOpen(true);
  };

  return (
    <section className="py-14 bg-stone-50/60 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-[#008f43] bg-emerald-100/70 border border-emerald-200/80 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Alta Performance & Economia</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight">
              Modelos em Destaque
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              As scooters elétricas mais procuradas com condições exclusivas e entrega garantida.
            </p>
          </div>

          {/* Carousel Arrows (Desktop) */}
          <div className="hidden sm:flex items-center gap-2">
            <button
              onClick={() => handleScroll('left')}
              className="p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-2xs transition-all active:scale-95 cursor-pointer"
              aria-label="Anterior"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => handleScroll('right')}
              className="p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-2xs transition-all active:scale-95 cursor-pointer"
              aria-label="Próximo"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Carousel Container:
            On mobile: snap-x with peek of next card (showing 1 card + part of next)
            On desktop: 3-4 visible cards */}
        <div
          ref={scrollRef}
          className="flex gap-4 sm:gap-6 overflow-x-auto snap-x snap-mandatory pb-6 pt-2 scrollbar-none no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {models.map((model) => {
            const installment = model.price / 12;

            return (
              <div
                key={model.id}
                onClick={() => onOpenDetails(model)}
                className="w-[85vw] sm:w-[calc(50%-12px)] lg:w-[calc(25%-18px)] shrink-0 snap-start bg-white rounded-2xl border border-slate-200/90 shadow-[0_4px_16px_-4px_rgba(0,0,0,0.05)] hover:border-[#00a650] hover:shadow-[0_16px_32px_-8px_rgba(0,166,80,0.16)] transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-pointer group"
              >
                {/* Image Container with Studio Background & Subtle Hover Zoom */}
                <div className="relative w-full h-56 sm:h-64 bg-gradient-to-b from-stone-50 via-slate-100/30 to-white flex items-center justify-center p-6 border-b border-slate-100 overflow-hidden">
                  {/* Promo Badge */}
                  {model.badge && (
                    <div className="absolute top-3 left-3 z-10">
                      <span className="bg-[#00a650] text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-full shadow-2xs">
                        {model.badge}
                      </span>
                    </div>
                  )}

                  {/* Power Tag */}
                  <div className="absolute top-3 right-3 z-10">
                    <span className="bg-slate-900/80 text-yellow-300 backdrop-blur-xs text-[10px] font-black px-2 py-0.5 rounded-md flex items-center gap-1 shadow-2xs">
                      <Zap className="w-3 h-3 fill-yellow-400" />
                      <span>{model.power}</span>
                    </span>
                  </div>

                  {/* Scooter Image with subtle zoom */}
                  <img
                    src={model.image}
                    alt={model.name}
                    loading="lazy"
                    className="max-h-44 sm:max-h-52 w-auto object-contain transition-transform duration-500 group-hover:scale-105 select-none drop-shadow-md"
                  />
                </div>

                {/* Card Body */}
                <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      Linha Oficial
                    </span>
                    <h3 className="text-lg font-black text-slate-900 group-hover:text-[#005c2d] transition-colors leading-tight">
                      Scooter {model.name}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {model.description}
                    </p>

                    {/* Quick spec pills */}
                    <div className="flex items-center gap-2 pt-1 text-[11px] text-slate-500">
                      <span className="flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-md font-medium">
                        <BatteryCharging className="w-3 h-3 text-[#00a650]" />
                        {model.autonomia || '35km'}
                      </span>
                      <span className="text-slate-300">•</span>
                      <span className="bg-slate-100 px-2 py-0.5 rounded-md font-medium">
                        {model.colors.length} cores
                      </span>
                    </div>
                  </div>

                  {/* Pricing Block */}
                  <div className="pt-2 border-t border-slate-100 space-y-1">
                    {model.oldPrice && (
                      <span className="text-xs text-slate-400 line-through block font-medium">
                        De {formatCurrency(model.oldPrice)}
                      </span>
                    )}
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-xl sm:text-2xl font-black text-[#005c2d]">
                        {formatCurrency(model.price)}
                      </span>
                      <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                        À VISTA NO PIX
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500 font-medium block">
                      ou 12x de {formatCurrency(installment)}
                    </span>
                  </div>

                  {/* Action Buttons: Ver Detalhes + Comprar */}
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenDetails(model);
                      }}
                      className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                    >
                      <Eye className="w-3.5 h-3.5 text-slate-500" />
                      <span>Detalhes</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => handleQuickBuy(model, e)}
                      className="py-2.5 px-3 bg-[#00a650] hover:bg-[#008f43] text-white rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 shadow-2xs active:scale-95 cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5 text-yellow-300" />
                      <span>Comprar</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Mobile Swipe Hint */}
        <div className="flex sm:hidden items-center justify-center gap-1.5 text-xs text-slate-400 mt-2 font-medium">
          <span>← Deslize para ver mais modelos →</span>
        </div>
      </div>
    </section>
  );
};
