import React from 'react';
import { 
  Building2, 
  Sparkles, 
  Headphones, 
  ShieldCheck, 
  ShoppingBag, 
  CheckCircle2 
} from 'lucide-react';

export const WhyBuyVestcasa: React.FC = () => {
  const differentials = [
    {
      icon: Building2,
      title: 'Confiança & Tradição',
      description: 'Mais de 100 megalojas pelo Brasil e a credibilidade de um dos maiores grupos varejistas.',
    },
    {
      icon: Sparkles,
      title: 'Economia Sem Intermediários',
      description: 'Veículos direto de fábrica com preços imbatíveis e custo por km rodado menor que R$ 0,05.',
    },
    {
      icon: Headphones,
      title: 'Atendimento Dedicado',
      description: 'Equipe especializada pronta para orientar sobre modelos, recargas e suporte pós-venda.',
    },
    {
      icon: ShieldCheck,
      title: 'Segurança Total na Compra',
      description: 'Emissão de código único para cada pedido, pagamento via PIX oficial e rastreio de status.',
    },
    {
      icon: ShoppingBag,
      title: 'Experiência Ágil e Prática',
      description: 'Opção de retirada rápida em loja ou entrega com acompanhamento integral do pedido.',
    },
  ];

  return (
    <section className="py-16 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-[#008f43] bg-emerald-50 border border-emerald-200/60 px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider mb-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#00a650]" />
            <span>Diferenciais Exclusivos</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight">
            Por que comprar na Vestcasa?
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-2 leading-relaxed">
            Mais do que uma scooter elétrica: você leva economia real, tranquilidade e o respaldo de uma grande marca.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6">
          {differentials.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="p-6 rounded-2xl bg-stone-50/80 border border-slate-200/70 hover:bg-white hover:border-[#00a650] hover:shadow-[0_12px_24px_-6px_rgba(0,166,80,0.12)] transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-white group-hover:bg-[#00a650] border border-slate-200/80 group-hover:border-[#00a650] text-[#008f43] group-hover:text-white flex items-center justify-center mb-4 shadow-2xs transition-colors">
                    <Icon className="w-6 h-6 stroke-[1.8]" />
                  </div>
                  <h3 className="text-sm font-black text-slate-900 mb-2 group-hover:text-[#005c2d] transition-colors leading-snug">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {item.description}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-200/50 flex items-center justify-between text-[11px] font-bold text-slate-400 group-hover:text-[#008f43]">
                  <span>Vantagem {index + 1}</span>
                  <span>✓</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
