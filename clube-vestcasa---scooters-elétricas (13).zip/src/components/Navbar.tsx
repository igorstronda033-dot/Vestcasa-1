import React, { useState, useEffect } from 'react';
import { 
  Menu, 
  X, 
  Search, 
  Bike, 
  Lock, 
  ShoppingBag, 
  Phone, 
  Sparkles, 
  ArrowRight,
  HelpCircle,
  ShieldCheck
} from 'lucide-react';
import { RainbowBar } from './RainbowBar';
import { useCart } from '../context/CartContext';
import { TopBenefitsBar } from './TopBenefitsBar';

interface NavbarProps {
  currentTab: 'cliente' | 'catalogo' | 'admin';
  onSelectTab: (tab: 'cliente' | 'catalogo' | 'admin') => void;
  pendingCount?: number;
  onSearchClick?: () => void;
  onNavigateToSection?: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  currentTab, 
  onSelectTab, 
  pendingCount = 0,
  onSearchClick,
  onNavigateToSection,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { totalQuantity, setIsCartOpen } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 15) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleTabClick = (tab: 'cliente' | 'catalogo' | 'admin') => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
  };

  const handleSectionClick = (sectionId: string) => {
    setMobileMenuOpen(false);
    if (currentTab !== 'cliente') {
      onSelectTab('cliente');
    }
    setTimeout(() => {
      const el = document.getElementById(sectionId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const whatsappPhone = '5511971583047';
  const whatsappUrl = `https://wa.me/${whatsappPhone}?text=Ol%C3%A1!%20Gostaria%20de%20falar%20com%20a%20equipe%20de%20vendas%20das%20scooters%20el%C3%A9tricas%20Vestcasa.`;

  return (
    <header className="sticky top-0 z-40 bg-white transition-all duration-300">
      {/* 1. Top Benefits Bar */}
      <TopBenefitsBar />

      {/* 2. Brand Rainbow Stripe */}
      <RainbowBar height="h-[3px]" />

      {/* 3. Main Header Bar with dynamic scroll shadow */}
      <div 
        className={`w-full transition-all duration-300 ${
          isScrolled 
            ? 'bg-white/95 backdrop-blur-md shadow-[0_4px_20px_-2px_rgba(0,0,0,0.08)] py-2 sm:py-2.5' 
            : 'bg-white shadow-2xs py-3 sm:py-3.5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between">
          
          {/* DESKTOP & MOBILE LEFT / CENTER: Brand Logo */}
          <div className="flex items-center gap-3">
            {/* Mobile Hamburger Button on Left */}
            <button
              id="btn-mobile-menu"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 -ml-2 text-slate-900 hover:bg-slate-100 rounded-xl transition-colors md:hidden cursor-pointer"
              aria-label="Abrir Menu"
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6 stroke-[2.2]" />
              ) : (
                <Menu className="w-6 h-6 stroke-[2.2]" />
              )}
            </button>

            {/* Logo Vestcasa */}
            <div 
              onClick={() => handleTabClick('cliente')}
              className="cursor-pointer select-none group flex flex-col items-start"
            >
              <div className="flex items-baseline text-2xl sm:text-3xl lg:text-4xl tracking-tight leading-none font-black italic">
                <span className="text-[#009b4b] mr-1.5 transition-colors group-hover:text-[#00b055]">
                  Clube
                </span>
                <span className="text-[#006e33] transition-colors group-hover:text-[#005c2d]">
                  Vestcasa
                </span>
              </div>
              <div className="w-full mt-1">
                <RainbowBar height="h-[3px]" rounded="rounded-full" />
              </div>
            </div>
          </div>

          {/* DESKTOP CENTERED MENU */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            <button
              onClick={() => handleTabClick('cliente')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                currentTab === 'cliente'
                  ? 'bg-emerald-50 text-[#006e33]'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
              }`}
            >
              Início
            </button>

            <button
              onClick={() => handleSectionClick('secao-catalogo')}
              className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-100/70 transition-all cursor-pointer"
            >
              Scooters Elétricas
            </button>

            <button
              onClick={() => handleSectionClick('secao-consulta')}
              className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-100/70 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Search className="w-3.5 h-3.5 text-[#009b4b]" />
              <span>Consultar Pedido</span>
            </button>

            <button
              onClick={() => handleSectionClick('secao-faq')}
              className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-100/70 transition-all cursor-pointer"
            >
              Dúvidas (FAQ)
            </button>
          </nav>

          {/* RIGHT ACTIONS: Search, WhatsApp, Cart, Admin */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick Search / Consultation trigger */}
            <button
              onClick={() => {
                if (onSearchClick) onSearchClick();
                else handleSectionClick('secao-consulta');
              }}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
              title="Consultar código do pedido"
            >
              <Search className="w-3.5 h-3.5 text-slate-500" />
              <span>Buscar Pedido</span>
            </button>

            {/* WhatsApp Contact Button */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-[#006e33] bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 transition-all cursor-pointer"
              title="Fale conosco no WhatsApp"
            >
              <Phone className="w-3.5 h-3.5 text-[#00a650]" />
              <span>Atendimento</span>
            </a>

            {/* Cart Button */}
            <button
              id="btn-abrir-carrinho-desktop"
              onClick={() => setIsCartOpen(true)}
              className="relative px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl bg-gradient-to-r from-[#00a650] to-[#008f43] hover:brightness-105 text-white text-xs sm:text-xs font-black transition-all flex items-center gap-2 shadow-xs active:scale-95 cursor-pointer"
              title="Abrir Carrinho de Compras"
            >
              <ShoppingBag className="w-4 h-4 text-yellow-300" />
              <span className="hidden sm:inline">CARRINHO</span>
              {totalQuantity > 0 ? (
                <span className="bg-white text-[#005c2d] text-[11px] font-black px-1.5 py-0.2 rounded-full shadow-xs animate-bounce">
                  {totalQuantity}
                </span>
              ) : (
                <span className="text-[10px] text-emerald-100 hidden sm:inline">(0)</span>
              )}
            </button>

            {/* Admin Lock Button (Discreet) */}
            <button
              onClick={() => handleTabClick('admin')}
              className={`p-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                currentTab === 'admin'
                  ? 'bg-[#005c2d] text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
              }`}
              title="Área Administrativa"
              aria-label="Painel Administrativo"
            >
              <Lock className="w-3.5 h-3.5" />
              {pendingCount > 0 && (
                <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                  {pendingCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* MOBILE DRAWER NAVIGATION (Handheld friendly, high-contrast, clean) */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 px-4 py-4 shadow-xl animate-in slide-in-from-top duration-200">
          <div className="space-y-2">
            {/* Quick Search Order Button */}
            <button
              onClick={() => handleSectionClick('secao-consulta')}
              className="w-full p-3.5 rounded-xl text-left font-bold text-sm flex items-center justify-between border border-[#00a650] bg-emerald-50 text-[#005c2d] transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#00a650] flex items-center justify-center text-white shadow-2xs">
                  <Search className="w-4 h-4" />
                </div>
                <span>CONSULTAR MEU PEDIDO</span>
              </div>
              <ArrowRight className="w-4 h-4 text-[#00a650]" />
            </button>

            {/* Catálogo de Scooters */}
            <button
              onClick={() => handleSectionClick('secao-catalogo')}
              className="w-full p-3.5 rounded-xl text-left font-bold text-sm flex items-center justify-between border border-slate-200 text-slate-700 hover:bg-slate-50 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center text-[#00a650]">
                  <Bike className="w-4 h-4" />
                </div>
                <span>SCOOTERS ELÉTRICAS</span>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400" />
            </button>

            {/* Dúvidas FAQ */}
            <button
              onClick={() => handleSectionClick('secao-faq')}
              className="w-full p-3.5 rounded-xl text-left font-bold text-sm flex items-center justify-between border border-slate-200 text-slate-700 hover:bg-slate-50 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center text-[#00a650]">
                  <HelpCircle className="w-4 h-4" />
                </div>
                <span>PERGUNTAS FREQUENTES (FAQ)</span>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400" />
            </button>

            {/* WhatsApp Atendimento */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full p-3.5 rounded-xl text-left font-bold text-sm flex items-center justify-between border border-emerald-300 bg-white text-[#006e33] transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#25D366] flex items-center justify-center text-white shadow-2xs">
                  <Phone className="w-4 h-4" />
                </div>
                <span>FALAR NO WHATSAPP</span>
              </div>
              <ArrowRight className="w-4 h-4 text-[#00a650]" />
            </a>

            {/* Admin Area */}
            <button
              onClick={() => handleTabClick('admin')}
              className="w-full p-3.5 rounded-xl text-left font-bold text-sm flex items-center justify-between border border-slate-200 text-slate-700 hover:bg-slate-50 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600">
                  <Lock className="w-4 h-4" />
                </div>
                <span>PAINEL ADMINISTRATIVO</span>
              </div>
              {pendingCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-amber-400 text-slate-900 text-xs font-black">
                  {pendingCount} pendentes
                </span>
              )}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
