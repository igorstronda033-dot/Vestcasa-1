import React, { useState, useEffect } from 'react';
import { 
  Search, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  CreditCard, 
  QrCode, 
  ExternalLink, 
  Bike,
  Sparkles,
  Loader2,
  Lock,
  Tag
} from 'lucide-react';
import { Pedido, PaymentStatus } from '../types';
import { findOrderByCode, reportPaymentDone } from '../services/orderService';
import { validateAdminCode } from '../services/adminConfigService';
import { isSupabaseConfigured } from '../lib/supabase';
import { RainbowBar } from './RainbowBar';
import { getModelImage } from '../services/scooterService';

interface OrderConsultationProps {
  onOpenPayment: (pedido: Pedido) => void;
  onAdminAccess?: () => void;
  defaultCode?: string;
}

export const OrderConsultation: React.FC<OrderConsultationProps> = ({ 
  onOpenPayment, 
  onAdminAccess, 
  defaultCode = '' 
}) => {
  const [orderCode, setOrderCode] = useState(defaultCode);
  const [isLoading, setIsLoading] = useState(false);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [pedido, setPedido] = useState<Pedido | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  useEffect(() => {
    if (defaultCode) {
      setOrderCode(defaultCode);
      handleSearch(defaultCode);
    }
  }, [defaultCode]);

  const handleSearch = async (codeToSearch?: string) => {
    const code = (codeToSearch || orderCode).trim();
    setErrorMessage(null);
    setSuccessNotice(null);

    if (!code) {
      setErrorMessage('Por favor, digite o código do seu pedido.');
      return;
    }

    setIsLoading(true);
    setPedido(null);

    try {
      // 1. Verificação segura do código administrativo especial
      const isAdmin = await validateAdminCode(code);
      if (isAdmin) {
        setIsLoading(false);
        localStorage.setItem('vestcasa_admin_logged', 'true');
        if (onAdminAccess) {
          onAdminAccess();
        }
        return;
      }

      // 2. Consulta normal de pedido
      const { data, error } = await findOrderByCode(code);
      if (error) {
        setErrorMessage(error);
      } else if (data) {
        setPedido(data);
        setSuccessNotice('Pedido localizado com sucesso.');
      }
    } catch (err: any) {
      setErrorMessage('Ocorreu um erro ao consultar. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReportPayment = async () => {
    if (!pedido) return;

    if (pedido.status_pagamento === 'Pago') {
      alert('Este pedido já consta como PAGO no sistema!');
      return;
    }

    if (pedido.status_pagamento === 'Cliente informou pagamento') {
      alert('Você já informou o pagamento deste pedido. O administrador está verificando o comprovante.');
      return;
    }

    setIsUpdatingStatus(true);
    try {
      const { success, error } = await reportPaymentDone(pedido.id);
      if (success) {
        setPedido({
          ...pedido,
          status_pagamento: 'Cliente informou pagamento',
        });
        setSuccessNotice('Aviso registrado com sucesso! Nosso setor financeiro irá confirmar seu pagamento.');
      } else {
        setErrorMessage(error || 'Não foi possível registrar seu aviso de pagamento.');
      }
    } catch (err: any) {
      setErrorMessage('Erro ao notificar pagamento.');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(val);
  };

  const getStatusBadge = (status: PaymentStatus) => {
    switch (status) {
      case 'Pago':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Pago
          </span>
        );
      case 'Cliente informou pagamento':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
            <Clock className="w-3.5 h-3.5 text-amber-700" />
            Cliente informou pagamento
          </span>
        );
      case 'Cancelado':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300">
            <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
            Cancelado
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-yellow-100 text-yellow-900 border border-yellow-300">
            <Clock className="w-3.5 h-3.5 text-yellow-700" />
            Pagamento pendente
          </span>
        );
    }
  };

  return (
    <div id="secao-consulta" className="max-w-xl mx-auto px-4 py-8">
      {/* Official Portal Pill Badge */}
      <div className="flex justify-center mb-4">
        <div className="inline-flex items-center gap-2 bg-[#004d25] text-emerald-300 px-4 py-1.5 rounded-full text-xs font-bold tracking-wide shadow-sm">
          <ShieldCheck className="w-4 h-4 text-[#00a650]" />
          <span>PORTAL OFICIAL DE CONSULTA E PAGAMENTO</span>
        </div>
      </div>

      {/* Main Title & Subtitle */}
      <div className="text-center mb-6">
        <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Consulte seu pedido
        </h2>
        <p className="text-sm text-slate-600 mt-2 max-w-md mx-auto leading-relaxed">
          Digite seu código exclusivo gerado pelo atendente para visualizar os dados e realizar o pagamento.
        </p>
      </div>

      {/* Search Input Box */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-6">
        <RainbowBar height="h-1.5" />
        <div className="p-5 sm:p-6">
          <label 
            htmlFor="input-codigo-pedido"
            className="block text-xs font-extrabold uppercase tracking-wider text-slate-700 mb-2"
          >
            DIGITE SEU CÓDIGO DE ATENDIMENTO
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <input
              id="input-codigo-pedido"
              type="text"
              value={orderCode}
              onChange={(e) => setOrderCode(e.target.value.toUpperCase())}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Ex: SCO4821 ou ABC123"
              className="w-full px-4 py-3.5 rounded-xl border-2 border-slate-200 focus:border-[#00a650] focus:ring-2 focus:ring-emerald-500/20 text-slate-900 font-mono font-bold tracking-wider placeholder:font-sans placeholder:font-normal placeholder:text-slate-400 outline-none text-base transition-all uppercase"
            />
            {orderCode && (
              <button
                type="button"
                onClick={() => { setOrderCode(''); setPedido(null); setErrorMessage(null); setSuccessNotice(null); }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 hover:text-slate-600 px-2 py-1"
              >
                Limpar
              </button>
            )}
          </div>

          <button
            id="btn-consultar-pedido"
            onClick={() => handleSearch()}
            disabled={isLoading}
            className="px-6 py-3.5 bg-[#00a650] hover:bg-[#008f43] text-white font-extrabold rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60 whitespace-nowrap active:scale-[0.98]"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Buscando...</span>
              </>
            ) : (
              <>
                <Search className="w-5 h-5" />
                <span>Consultar pedido</span>
              </>
            )}
          </button>
        </div>

        {/* Search Feedback / Errors */}
        {errorMessage && (
          <div className="mt-4 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs sm:text-sm font-medium flex items-start gap-2.5 animate-in fade-in">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="leading-snug">
              {errorMessage}
            </div>
          </div>
        )}

        {successNotice && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs sm:text-sm font-semibold flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successNotice}</span>
          </div>
        )}
        </div>
      </div>

      {/* Found Order Card */}
      {pedido && (
        <div 
          id="card-pedido-localizado" 
          className="bg-white rounded-2xl shadow-lg border-2 border-emerald-500 overflow-hidden animate-in slide-in-from-bottom-3 duration-300"
        >
          <RainbowBar height="h-2" />
          {/* Card Header */}
          <div className="bg-gradient-to-r from-[#005c2d] to-[#00a650] text-white px-5 py-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-sm">
              <CheckCircle2 className="w-4 h-4 text-yellow-300" />
              <span>Pedido encontrado</span>
            </div>
            <div className="text-xs font-mono bg-white/20 px-2.5 py-0.5 rounded-full font-bold">
              {pedido.codigo}
            </div>
          </div>

          {/* Card Body - Read Only for Customer */}
          <div className="p-5 sm:p-6 space-y-4">
            {/* Scooter Visual Presentation - Studio Quality Showcase */}
            <div className="bg-gradient-to-b from-slate-50 via-slate-100/40 to-slate-50 rounded-2xl p-4 sm:p-5 border border-slate-200/90 flex flex-col sm:flex-row items-center gap-5">
              <div className="group relative w-32 h-32 sm:w-36 sm:h-36 bg-white rounded-2xl border border-slate-200/90 p-3 shrink-0 flex items-center justify-center overflow-hidden shadow-xs">
                {/* Floor shadow */}
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-20 h-2 bg-slate-900/10 rounded-[100%] blur-[3px] pointer-events-none transition-all duration-300 group-hover:scale-x-110" />
                <img
                  src={pedido.imagem_url || getModelImage(pedido.produto)}
                  alt={`Scooter ${pedido.produto}`}
                  referrerPolicy="no-referrer"
                  loading="eager"
                  className="relative z-1 max-h-full max-w-full object-contain filter drop-shadow-sm transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="flex-1 text-center sm:text-left space-y-1.5">
                <div className="flex items-center justify-center sm:justify-start gap-2">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full inline-block">
                    Modelo do Pedido
                  </span>
                  <span className="text-[10px] font-bold text-slate-500 bg-white border border-slate-200 px-2 py-0.5 rounded-full">
                    100% Elétrica
                  </span>
                </div>
                <h4 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                  {pedido.produto}
                </h4>
                <p className="text-xs text-slate-600">
                  Cor Selecionada: <strong className="text-slate-900 font-bold">{pedido.cor || 'Padrão'}</strong>
                </p>
                <div className="text-[11px] text-emerald-700 font-bold flex items-center justify-center sm:justify-start gap-1.5 pt-0.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#ffd000]" />
                  <span>Foto oficial correspondente ao modelo cadastrado</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm pb-4 border-b border-slate-100">
              <div>
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Cliente</span>
                <span className="text-base font-bold text-slate-900">{pedido.nome_cliente}</span>
              </div>

              <div>
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Código do pedido</span>
                <span className="text-base font-mono font-bold text-[#005c2d]">{pedido.codigo}</span>
              </div>

              <div>
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Produto/Scooter</span>
                <span className="text-base font-bold text-slate-900 flex items-center gap-1.5">
                  <Bike className="w-4 h-4 text-[#00a650]" />
                  {pedido.produto}
                </span>
              </div>

              <div>
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Cor</span>
                <span className="text-base font-bold text-slate-900">
                  {pedido.cor ? pedido.cor : 'Não especificada'}
                </span>
              </div>
            </div>

            {/* Value and Status Section */}
            <div className="bg-slate-50 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Valor total do pedido</span>
                <span className="text-2xl font-black text-emerald-700">
                  {formatCurrency(pedido.valor)}
                </span>
                {pedido.cupom_codigo && (
                  <div className="flex items-center gap-1.5 mt-1 text-xs text-amber-900 font-bold bg-amber-100/70 px-2 py-0.5 rounded-md inline-flex">
                    <Tag className="w-3 h-3 text-amber-700" />
                    <span>Cupom {pedido.cupom_codigo} (-{pedido.cupom_porcentagem}%): -{formatCurrency(pedido.valor_desconto || 0)}</span>
                  </div>
                )}
              </div>

              <div className="sm:text-right">
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Status do pagamento</span>
                {getStatusBadge(pedido.status_pagamento)}
              </div>
            </div>

            {/* Read-only Security Note */}
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 bg-slate-100/70 px-3 py-1.5 rounded-lg">
              <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>Os dados deste pedido foram emitidos com segurança e são restritos para edição apenas pelo administrador.</span>
            </div>

            {/* Action Buttons requested by User */}
            <div className="pt-2 space-y-3">
              {/* Button 1: REALIZAR PAGAMENTO */}
              <button
                id="btn-realizar-pagamento"
                onClick={() => onOpenPayment(pedido)}
                className="w-full py-4 bg-gradient-to-r from-[#ffd000] to-[#fbc02d] text-slate-950 font-black text-base rounded-xl shadow-md hover:shadow-lg hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 uppercase tracking-wide cursor-pointer"
              >
                <div className="flex items-center gap-1.5">
                  <QrCode className="w-5 h-5" />
                  <CreditCard className="w-5 h-5" />
                </div>
                <span>FINALIZAR PAGAMENTO (PIX OU CARTÃO)</span>
              </button>

              {/* Button 2: Já realizei o pagamento */}
              <button
                id="btn-ja-realizei-pagamento"
                onClick={handleReportPayment}
                disabled={isUpdatingStatus || pedido.status_pagamento === 'Pago'}
                className="w-full py-3 bg-white hover:bg-slate-50 text-slate-700 font-bold text-sm rounded-xl border border-slate-300 shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-[0.98]"
              >
                {isUpdatingStatus ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-slate-600" />
                    <span>Atualizando no sistema...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Já realizei o pagamento</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
