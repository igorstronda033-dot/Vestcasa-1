import React, { useState, useEffect } from 'react';
import { 
  X, 
  Bike, 
  User, 
  CreditCard, 
  DollarSign, 
  FileText, 
  Tag, 
  Sparkles, 
  Save, 
  Loader2,
  ExternalLink,
  Copy,
  Check,
  Share2,
  Store,
  Truck,
  Trash2,
  Edit3,
  Plus,
  Minus,
  AlertTriangle,
  ShoppingCart,
  MapPin
} from 'lucide-react';
import { Pedido, PaymentStatus, CartItem, ScooterModel } from '../../types';
import { createOrder, updateOrder, deleteOrder } from '../../services/orderService';
import { getScooterModels, getModelImage } from '../../services/scooterService';

interface OrderModalProps {
  mode: 'create' | 'edit' | 'view';
  pedido?: Pedido | null;
  onClose: () => void;
  onSaved: () => void;
  onDeleteOrder?: (orderId: string, code: string) => void;
}

export const OrderModal: React.FC<OrderModalProps> = ({ 
  mode: initialMode, 
  pedido, 
  onClose, 
  onSaved,
  onDeleteOrder 
}) => {
  const models = getScooterModels();
  const [currentMode, setCurrentMode] = useState<'create' | 'edit' | 'view'>(initialMode);
  const [nomeCliente, setNomeCliente] = useState('');
  const [cpf, setCpf] = useState('');
  const [produto, setProduto] = useState('Scooter MU09 (350W)');
  const [cor, setCor] = useState('Preto');
  const [valor, setValor] = useState('2190.00');
  const [codigo, setCodigo] = useState('');
  const [observacao, setObservacao] = useState('');
  const [statusPagamento, setStatusPagamento] = useState<PaymentStatus>('Pendente');
  const [imagemUrl, setImagemUrl] = useState('');
  const [frete, setFrete] = useState<'sem_frete' | 'com_frete'>('sem_frete');
  const [orderItems, setOrderItems] = useState<CartItem[]>([]);

  // Shipping and Customer Details
  const [telefone, setTelefone] = useState('');
  const [cep, setCep] = useState('');
  const [endereco, setEndereco] = useState('');
  const [numero, setNumero] = useState('');
  const [complemento, setComplemento] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [estado, setEstado] = useState('');
  const [valorFrete, setValorFrete] = useState('0.00');
  const [tipoEntrega, setTipoEntrega] = useState<'entrega' | 'retirada'>('retirada');

  // Item addition state
  const [showAddItem, setShowAddItem] = useState(false);
  const [selectedNewModelId, setSelectedNewModelId] = useState<string>(models[0]?.id || '');
  const [selectedNewColor, setSelectedNewColor] = useState<string>('Preto');

  // Deletion prompt state
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Generate random code like SCO4821
  const generateRandomCode = () => {
    const num = Math.floor(1000 + Math.random() * 9000);
    return `SCO${num}`;
  };

  useEffect(() => {
    setCurrentMode(initialMode);
    setShowDeleteConfirm(false);
  }, [initialMode]);

  useEffect(() => {
    if (pedido && (currentMode === 'edit' || currentMode === 'view')) {
      setNomeCliente(pedido.nome_cliente || '');
      setCpf(pedido.cpf || '');
      setProduto(pedido.produto || '');
      setCor(pedido.cor || '');
      setValor(Number(pedido.valor || 0).toFixed(2));
      setCodigo(pedido.codigo || '');
      setObservacao(pedido.observacao || '');
      setStatusPagamento(pedido.status_pagamento || 'Pendente');
      setImagemUrl(pedido.imagem_url || '');
      setFrete(pedido.frete === 'com_frete' ? 'com_frete' : 'sem_frete');
      setOrderItems(Array.isArray(pedido.itens) ? [...pedido.itens] : []);
      setTelefone(pedido.telefone || '');
      setCep(pedido.cep || '');
      setEndereco(pedido.endereco || '');
      setNumero(pedido.numero || '');
      setComplemento(pedido.complemento || '');
      setBairro(pedido.bairro || '');
      setCidade(pedido.cidade || '');
      setEstado(pedido.estado || '');
      setValorFrete(Number(pedido.valor_frete || 0).toFixed(2));
      setTipoEntrega(pedido.tipo_entrega || (pedido.observacao?.toLowerCase().includes('entrega') ? 'entrega' : 'retirada'));
    } else if (currentMode === 'create') {
      setCodigo(generateRandomCode());
      setFrete('sem_frete');
      setOrderItems([]);
      setTelefone('');
      setCep('');
      setEndereco('');
      setNumero('');
      setComplemento('');
      setBairro('');
      setCidade('');
      setEstado('');
      setValorFrete('0.00');
      setTipoEntrega('retirada');
      const defaultModel = models[1] || models[0];
      if (defaultModel) {
        setProduto(`Scooter ${defaultModel.name} (${defaultModel.power})`);
        setValor(defaultModel.price.toFixed(2));
        setCor(defaultModel.colors[0] || 'Vermelho');
        setImagemUrl(defaultModel.image);
      }
    }
  }, [pedido, currentMode]);

  const handleProductSelect = (selectedName: string) => {
    setProduto(selectedName);
    const found = models.find((m) => selectedName.includes(m.name));
    if (found) {
      if (currentMode === 'create') {
        setValor(found.price.toFixed(2));
        setCor(found.colors[0] || 'Vermelho');
      }
      setImagemUrl(found.image);
    }
  };

  const handleModelOptionClick = (m: ScooterModel) => {
    setProduto(`Scooter ${m.name} (${m.power})`);
    setValor(m.price.toFixed(2));
    setImagemUrl(m.image);
    if (!['Vermelho', 'Preto', 'Branco'].includes(cor)) {
      setCor('Vermelho');
    }
  };

  const handleCpfChange = (val: string) => {
    const clean = val.replace(/\D/g, '').slice(0, 11);
    if (clean.length <= 3) {
      setCpf(clean);
    } else if (clean.length <= 6) {
      setCpf(`${clean.slice(0, 3)}.${clean.slice(3)}`);
    } else if (clean.length <= 9) {
      setCpf(`${clean.slice(0, 3)}.${clean.slice(3, 6)}.${clean.slice(6)}`);
    } else {
      setCpf(`${clean.slice(0, 3)}.${clean.slice(3, 6)}.${clean.slice(6, 9)}-${clean.slice(9, 11)}`);
    }
  };

  const handleCopyClientLink = () => {
    const url = `${window.location.origin}/?codigo=${codigo}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  // Item quantity update in cart
  const handleUpdateItemQty = (index: number, delta: number) => {
    setOrderItems((prev) => {
      const updated = [...prev];
      const newQty = Math.max(1, updated[index].quantidade + delta);
      updated[index] = {
        ...updated[index],
        quantidade: newQty,
        subtotal: updated[index].preco_unitario * newQty,
      };
      return updated;
    });
  };

  const handleRemoveItem = (index: number) => {
    setOrderItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAddItemToOrder = () => {
    const model = models.find((m) => m.id === selectedNewModelId) || models[0];
    if (!model) return;

    const newItem: CartItem = {
      id: `item-${Date.now()}`,
      id_produto: model.id,
      nome_produto: `Scooter ${model.name}`,
      preco_unitario: model.price,
      quantidade: 1,
      subtotal: model.price,
      cor: selectedNewColor,
      potencia: model.power,
      imagem: model.image,
    };

    setOrderItems((prev) => [...prev, newItem]);
    setShowAddItem(false);
  };

  const handleRecalculateTotal = () => {
    if (orderItems.length > 0) {
      const sum = orderItems.reduce((acc, item) => acc + (Number(item.subtotal) || 0), 0);
      setValor(sum.toFixed(2));
    }
  };

  // Handle Order Deletion directly from modal
  const handleDeleteOrder = async () => {
    if (!pedido?.id) return;
    setIsDeleting(true);
    setErrorMessage(null);
    try {
      if (onDeleteOrder) {
        onDeleteOrder(pedido.id, pedido.codigo);
        onClose();
        return;
      }

      const { success, error } = await deleteOrder(pedido.id);
      if (success) {
        onSaved();
        onClose();
      } else {
        setErrorMessage(error || 'Erro ao excluir pedido.');
        setIsDeleting(false);
        setShowDeleteConfirm(false);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Falha ao excluir pedido.');
      setIsDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!nomeCliente.trim()) {
      setErrorMessage('Informe o nome do cliente.');
      return;
    }

    if (!codigo.trim()) {
      setErrorMessage('Informe ou gere o código do pedido.');
      return;
    }

    const numericValue = parseFloat(valor.replace(',', '.'));
    if (isNaN(numericValue) || numericValue < 0) {
      setErrorMessage('Informe um valor numérico válido.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Determine final product name description
      let finalProduto = produto.trim();
      if (orderItems.length > 0) {
        finalProduto = orderItems.map((it) => `${it.quantidade}x ${it.nome_produto} (${it.cor || 'Padrão'})`).join(' + ');
      }

      const numericFrete = parseFloat(valorFrete.replace(',', '.')) || 0;
      const totalComFrete = numericValue + numericFrete;

      if (currentMode === 'create') {
        const { error } = await createOrder({
          codigo: codigo.trim().toUpperCase(),
          nome_cliente: nomeCliente.trim(),
          cpf: cpf.trim() || undefined,
          telefone: telefone.trim() || undefined,
          cep: cep.trim() || undefined,
          endereco: endereco.trim() || undefined,
          numero: numero.trim() || undefined,
          complemento: complemento.trim() || undefined,
          bairro: bairro.trim() || undefined,
          cidade: cidade.trim() || undefined,
          estado: estado.trim() || undefined,
          valor_frete: numericFrete,
          valor_total: totalComFrete,
          tipo_entrega: tipoEntrega,
          produto: finalProduto,
          cor: cor.trim() || undefined,
          valor: numericValue,
          observacao: observacao.trim() || undefined,
          status_pagamento: statusPagamento,
          imagem_url: imagemUrl.trim() || undefined,
          frete: numericFrete > 0 ? 'com_frete' : frete,
          itens: orderItems.length > 0 ? orderItems : undefined,
        });

        if (error) {
          setErrorMessage(error);
        } else {
          onSaved();
          onClose();
        }
      } else if (currentMode === 'edit' && pedido) {
        const { error } = await updateOrder(pedido.id, {
          codigo: codigo.trim().toUpperCase(),
          nome_cliente: nomeCliente.trim(),
          cpf: cpf.trim() || undefined,
          telefone: telefone.trim() || undefined,
          cep: cep.trim() || undefined,
          endereco: endereco.trim() || undefined,
          numero: numero.trim() || undefined,
          complemento: complemento.trim() || undefined,
          bairro: bairro.trim() || undefined,
          cidade: cidade.trim() || undefined,
          estado: estado.trim() || undefined,
          valor_frete: numericFrete,
          valor_total: totalComFrete,
          tipo_entrega: tipoEntrega,
          produto: finalProduto,
          cor: cor.trim() || undefined,
          valor: numericValue,
          observacao: observacao.trim() || undefined,
          status_pagamento: statusPagamento,
          imagem_url: imagemUrl.trim() || undefined,
          frete: numericFrete > 0 ? 'com_frete' : frete,
          itens: orderItems.length > 0 ? orderItems : undefined,
        });

        if (error) {
          setErrorMessage(error);
        } else {
          onSaved();
          onClose();
        }
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Falha na operação.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isReadOnly = currentMode === 'view';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div 
        id="modal-pedido-admin"
        className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-200 max-h-[95vh] flex flex-col"
      >
        {/* Header */}
        <div className="bg-[#005c2d] text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-white/15 flex items-center justify-center">
              <Bike className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base sm:text-lg">
                  {currentMode === 'create' && 'Criar Novo Pedido'}
                  {currentMode === 'edit' && `Alterar Pedido #${codigo}`}
                  {currentMode === 'view' && `Visualizar Pedido #${codigo}`}
                </h3>
                {currentMode === 'view' && (
                  <span className="px-2 py-0.5 rounded bg-emerald-700/80 text-[10px] font-bold uppercase tracking-wider text-emerald-100">
                    Modo Leitura
                  </span>
                )}
              </div>
              <p className="text-xs text-emerald-200">
                {currentMode === 'create' ? 'Salva diretamente no banco de dados' : 'Edição e exclusão permitidas para administradores'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Quick toggle from view to edit mode */}
            {currentMode === 'view' && (
              <button
                type="button"
                onClick={() => setCurrentMode('edit')}
                className="px-3 py-1.5 rounded-lg bg-yellow-400 hover:bg-yellow-300 text-slate-950 text-xs font-black flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Alterar dados do pedido"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Alterar Dados</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* In-Modal Delete Confirmation Banner */}
        {showDeleteConfirm && (
          <div className="bg-rose-50 border-b-2 border-rose-300 p-4 shrink-0 animate-in fade-in">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-100 border border-rose-300 flex items-center justify-center shrink-0 text-rose-600">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h4 className="font-black text-rose-900 text-sm">
                  Confirmar Exclusão do Pedido #{codigo}?
                </h4>
                <p className="text-xs text-rose-700 mt-0.5">
                  Esta ação excluirá permanentemente o pedido de <strong>{nomeCliente}</strong> do banco de dados. Esta operação não pode ser desfeita.
                </p>
                <div className="mt-3 flex items-center gap-2">
                  <button
                    type="button"
                    disabled={isDeleting}
                    onClick={handleDeleteOrder}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl shadow-xs transition-colors flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                  >
                    {isDeleting ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Excluindo...</span>
                      </>
                    ) : (
                      <>
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>SIM, EXCLUIR PEDIDO</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    disabled={isDeleting}
                    onClick={() => setShowDeleteConfirm(false)}
                    className="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-4">
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold">
              {errorMessage}
            </div>
          )}

          {/* Direct Link Share (Helpful for Admin to send to WhatsApp) */}
          {currentMode !== 'create' && (
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between gap-2">
              <div className="text-xs">
                <span className="font-bold text-[#005c2d] block">Link de Consulta do Cliente:</span>
                <span className="font-mono text-slate-600 text-[11px] truncate block max-w-xs sm:max-w-sm">
                  {window.location.origin}/?codigo={codigo}
                </span>
              </div>
              <button
                type="button"
                onClick={handleCopyClientLink}
                className="px-3 py-1.5 bg-[#00a650] text-white rounded-lg text-xs font-bold flex items-center gap-1 shrink-0 hover:bg-[#008f43] transition-colors cursor-pointer"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copiado!' : 'Copiar'}</span>
              </button>
            </div>
          )}

          {/* Form Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Nome Completo */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                NOME COMPLETO DO CLIENTE *
              </label>
              <input
                type="text"
                disabled={isReadOnly}
                required
                value={nomeCliente}
                onChange={(e) => setNomeCliente(e.target.value)}
                placeholder="Ex: João da Silva"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-emerald-500/20 text-slate-900 text-sm outline-none disabled:bg-slate-100"
              />
            </div>

            {/* CPF */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                CPF DO CLIENTE
              </label>
              <input
                type="text"
                disabled={isReadOnly}
                value={cpf}
                onChange={(e) => handleCpfChange(e.target.value)}
                placeholder="000.000.000-00"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-emerald-500/20 text-slate-900 text-sm font-mono outline-none disabled:bg-slate-100"
              />
            </div>

            {/* Código do Pedido */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                CÓDIGO DO PEDIDO *
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  disabled={isReadOnly}
                  required
                  value={codigo}
                  onChange={(e) => setCodigo(e.target.value.toUpperCase())}
                  placeholder="Ex: SCO4821"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-emerald-500/20 text-slate-900 text-sm font-mono font-bold uppercase outline-none disabled:bg-slate-100"
                />
                {!isReadOnly && (
                  <button
                    type="button"
                    onClick={() => setCodigo(generateRandomCode())}
                    title="Gerar novo código"
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 shrink-0 cursor-pointer"
                  >
                    Gerar
                  </button>
                )}
              </div>
            </div>

            {/* ITENS DO PEDIDO (Multi-item support) */}
            {orderItems.length > 0 && (
              <div className="sm:col-span-2 bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <ShoppingCart className="w-4 h-4 text-[#00a650]" />
                    <span>ITENS DO PEDIDO ({orderItems.length})</span>
                  </span>
                  {!isReadOnly && (
                    <button
                      type="button"
                      onClick={handleRecalculateTotal}
                      className="text-[11px] font-bold text-[#005c2d] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Sparkles className="w-3 h-3 text-[#00a650]" />
                      Recalcular Valor Total
                    </button>
                  )}
                </div>

                <div className="space-y-2">
                  {orderItems.map((item, idx) => (
                    <div 
                      key={item.id || idx}
                      className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between gap-3 shadow-2xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <div className="w-11 h-11 bg-slate-50 rounded-lg border border-slate-100 p-0.5 shrink-0 flex items-center justify-center overflow-hidden">
                          <img 
                            src={item.imagem || getModelImage(item.nome_produto)} 
                            alt={item.nome_produto}
                            referrerPolicy="no-referrer"
                            className="max-h-full max-w-full object-contain"
                          />
                        </div>
                        <div className="min-w-0">
                          <p className="font-extrabold text-xs text-slate-900 truncate">
                            {item.nome_produto}
                          </p>
                          <div className="flex items-center gap-2 text-[11px] text-slate-500">
                            <span className="font-semibold text-[#008f43]">
                              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.preco_unitario)}
                            </span>
                            {item.cor && (
                              <span className="bg-slate-100 px-1.5 py-0.2 rounded font-medium text-slate-700">
                                Cor: {item.cor}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Quantity & Actions */}
                      <div className="flex items-center gap-2 shrink-0">
                        {!isReadOnly ? (
                          <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
                            <button
                              type="button"
                              onClick={() => handleUpdateItemQty(idx, -1)}
                              className="p-1.5 hover:bg-slate-200 text-slate-700 transition-colors"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 font-black text-xs text-slate-900">
                              {item.quantidade}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleUpdateItemQty(idx, 1)}
                              className="p-1.5 hover:bg-slate-200 text-slate-700 transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2 py-1 rounded-md">
                            Qtd: {item.quantidade}
                          </span>
                        )}

                        <span className="text-xs font-black text-slate-900 min-w-[70px] text-right">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.subtotal)}
                        </span>

                        {!isReadOnly && (
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(idx)}
                            title="Remover este item do pedido"
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {!isReadOnly && (
                  <div className="pt-2">
                    {!showAddItem ? (
                      <button
                        type="button"
                        onClick={() => setShowAddItem(true)}
                        className="text-xs font-bold text-[#005c2d] hover:text-[#004d25] flex items-center gap-1.5 py-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Adicionar outro item ao pedido</span>
                      </button>
                    ) : (
                      <div className="p-3 bg-white rounded-xl border border-emerald-300 space-y-2.5 animate-in fade-in">
                        <span className="text-xs font-bold text-slate-800 block">
                          Selecionar item para adicionar:
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <select
                            value={selectedNewModelId}
                            onChange={(e) => setSelectedNewModelId(e.target.value)}
                            className="px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold outline-none bg-white"
                          >
                            {models.map((m) => (
                              <option key={m.id} value={m.id}>
                                Scooter {m.name} ({m.power}) - {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(m.price)}
                              </option>
                            ))}
                          </select>

                          <select
                            value={selectedNewColor}
                            onChange={(e) => setSelectedNewColor(e.target.value)}
                            className="px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold outline-none bg-white"
                          >
                            <option value="Vermelho">Vermelho</option>
                            <option value="Preto">Preto</option>
                            <option value="Branco">Branco</option>
                          </select>
                        </div>

                        <div className="flex items-center gap-2 justify-end">
                          <button
                            type="button"
                            onClick={() => setShowAddItem(false)}
                            className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-xs font-bold hover:bg-slate-200"
                          >
                            Cancelar
                          </button>
                          <button
                            type="button"
                            onClick={handleAddItemToOrder}
                            className="px-3.5 py-1 bg-[#00a650] text-white rounded-lg text-xs font-black hover:bg-[#008f43]"
                          >
                            Adicionar
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* ESCOLHA POR OPÇÃO: MODELO DA SCOOTER (Caso pedido de item único) */}
            <div className="sm:col-span-2">
              <div className="flex items-center justify-between mb-2">
                <label className="block text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <Bike className="w-4 h-4 text-[#00a650]" />
                  <span>MODELO DA SCOOTER *</span>
                </label>
                {!isReadOnly && orderItems.length === 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      const found = models.find((m) => produto.includes(m.name)) || models[0];
                      setOrderItems([{
                        id: `item-${Date.now()}`,
                        id_produto: found.id,
                        nome_produto: `Scooter ${found.name}`,
                        preco_unitario: Number(valor) || found.price,
                        quantidade: 1,
                        subtotal: Number(valor) || found.price,
                        cor: cor || 'Preto',
                        potencia: found.power,
                        imagem: imagemUrl || found.image,
                      }]);
                    }}
                    className="text-[11px] font-bold text-[#005c2d] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    Transformar em Carrinho Multi-Itens
                  </button>
                )}
              </div>

              {/* Opções Visuais dos 4 Modelos Oficiais */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-2.5">
                {models.map((m) => {
                  const isSelected = produto.includes(m.name);
                  return (
                    <button
                      key={m.id}
                      type="button"
                      disabled={isReadOnly}
                      onClick={() => handleModelOptionClick(m)}
                      className={`p-2.5 rounded-2xl border-2 text-center transition-all flex flex-col items-center justify-between min-h-[145px] cursor-pointer ${
                        isSelected
                          ? 'border-[#00a650] bg-emerald-50/80 ring-2 ring-emerald-500/20 shadow-xs'
                          : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <div className="w-full h-16 flex items-center justify-center p-1 overflow-hidden">
                        <img
                          src={m.image}
                          alt={m.name}
                          referrerPolicy="no-referrer"
                          className="max-h-full max-w-full object-contain"
                        />
                      </div>
                      <div className="w-full pt-1.5 border-t border-slate-100">
                        <div className="flex items-center justify-center gap-1">
                          <span className="font-black text-xs sm:text-sm text-slate-900">{m.name}</span>
                          <span className="text-[10px] font-black text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded-md">
                            {m.power}
                          </span>
                        </div>
                        <span className="text-xs font-black text-[#008f43] block mt-0.5">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(m.price)}
                        </span>
                        {isSelected && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-black text-[#005c2d] mt-1 bg-emerald-200/70 px-2 py-0.5 rounded-full">
                            <Check className="w-3 h-3 stroke-[3]" /> Selecionado
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Seletor Dropdown Alternativo / Manual */}
              {!isReadOnly ? (
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-slate-500 shrink-0">Ou selecione:</span>
                  <select
                    value={produto}
                    onChange={(e) => handleProductSelect(e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded-xl border border-slate-300 focus:border-[#00a650] text-slate-800 text-xs outline-none bg-white font-medium"
                  >
                    {models.map((m) => (
                      <option key={m.id} value={`Scooter ${m.name} (${m.power})`}>
                        Scooter {m.name} ({m.power}) - {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(m.price)}
                      </option>
                    ))}
                    <option value="Personalizado">Outro modelo / Personalizado</option>
                  </select>
                </div>
              ) : (
                <input
                  type="text"
                  disabled
                  value={produto}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-slate-100 text-sm font-bold"
                />
              )}
            </div>

            {/* ESCOLHA POR OPÇÃO: CORES */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-black uppercase tracking-wider text-slate-800 mb-2 flex items-center gap-1.5">
                <Tag className="w-4 h-4 text-[#00a650]" />
                <span>COR DA SCOOTER *</span>
              </label>

              <div className="grid grid-cols-3 gap-2.5">
                {[
                  { name: 'Vermelho', hex: '#dc2626', border: 'border-red-500' },
                  { name: 'Preto', hex: '#0f172a', border: 'border-slate-800' },
                  { name: 'Branco', hex: '#ffffff', border: 'border-slate-300' },
                ].map((c) => {
                  const isSelected = cor.toLowerCase() === c.name.toLowerCase();
                  return (
                    <button
                      key={c.name}
                      type="button"
                      disabled={isReadOnly}
                      onClick={() => setCor(c.name)}
                      className={`p-3 rounded-xl border-2 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                        isSelected
                          ? 'border-[#00a650] bg-emerald-50 text-slate-950 ring-2 ring-emerald-500/20 shadow-xs'
                          : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <span
                        className={`w-4 h-4 rounded-full border shadow-2xs ${c.border}`}
                        style={{ backgroundColor: c.hex }}
                      />
                      <span className="font-extrabold text-sm">{c.name}</span>
                      {isSelected && <Check className="w-4 h-4 text-[#00a650] stroke-[3]" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Informações do Cupom de Desconto (se houver) */}
            {pedido?.cupom_codigo && (
              <div className="sm:col-span-2 p-4 bg-amber-50/80 border border-amber-200 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase text-amber-900 flex items-center gap-1.5">
                    <Tag className="w-4 h-4 text-amber-700" />
                    <span>Cupom de Desconto Aplicado</span>
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-amber-200 text-amber-900 border border-amber-300">
                    {pedido.cupom_codigo} (-{pedido.cupom_porcentagem || 0}%)
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs">
                  <div className="p-2 bg-white rounded-lg border border-amber-100">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Subtotal Produto</span>
                    <span className="font-bold text-slate-800">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(pedido.valor_produto || 0)}
                    </span>
                  </div>
                  <div className="p-2 bg-white rounded-lg border border-amber-100">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Desconto ({pedido.cupom_porcentagem}%)</span>
                    <span className="font-bold text-emerald-700">
                      - {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(pedido.valor_desconto || 0)}
                    </span>
                  </div>
                  <div className="p-2 bg-white rounded-lg border border-amber-100">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Frete</span>
                    <span className="font-bold text-slate-800">
                      {pedido.valor_frete ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(pedido.valor_frete) : 'Grátis'}
                    </span>
                  </div>
                  <div className="p-2 bg-emerald-50 rounded-lg border border-emerald-200">
                    <span className="text-[10px] uppercase font-black text-emerald-800 block">Total Final</span>
                    <span className="font-black text-emerald-900 text-sm">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(pedido.valor_total || pedido.valor || 0)}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Valor do Pedido */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                VALOR TOTAL DO PEDIDO (R$) *
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">R$</span>
                <input
                  type="text"
                  disabled={isReadOnly}
                  required
                  value={valor}
                  onChange={(e) => setValor(e.target.value)}
                  placeholder="3899.00"
                  className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-[#00a650] text-slate-900 text-sm font-bold outline-none disabled:bg-slate-100"
                />
              </div>
            </div>

            {/* Status do Pagamento */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                STATUS DO PAGAMENTO *
              </label>
              <select
                disabled={isReadOnly}
                value={statusPagamento}
                onChange={(e) => setStatusPagamento(e.target.value as PaymentStatus)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-[#00a650] text-slate-900 text-sm font-bold outline-none bg-white disabled:bg-slate-100"
              >
                <option value="Pendente">Pendente</option>
                <option value="Cliente informou pagamento">Cliente informou pagamento</option>
                <option value="Pago">Pago</option>
                <option value="Cancelado">Cancelado</option>
              </select>
            </div>

            {/* Frete */}
            <div className="sm:col-span-2 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
              <label className="block text-xs font-black uppercase tracking-wider text-slate-800 mb-2 flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-[#00a650]" />
                <span>FRETE / ENTREGA:</span>
              </label>

              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 cursor-pointer text-sm font-bold text-slate-800">
                  <input
                    type="radio"
                    name="frete"
                    value="sem_frete"
                    disabled={isReadOnly}
                    checked={frete === 'sem_frete'}
                    onChange={() => setFrete('sem_frete')}
                    className="w-4 h-4 text-[#00a650] focus:ring-[#00a650] border-slate-300 accent-[#00a650]"
                  />
                  <span>Sem frete</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-sm font-bold text-slate-800">
                  <input
                    type="radio"
                    name="frete"
                    value="com_frete"
                    disabled={isReadOnly}
                    checked={frete === 'com_frete'}
                    onChange={() => setFrete('com_frete')}
                    className="w-4 h-4 text-[#00a650] focus:ring-[#00a650] border-slate-300 accent-[#00a650]"
                  />
                  <span>Com frete</span>
                </label>
              </div>
            </div>

            {/* FORMA DE RECEBIMENTO: RETIRADA OU ENTREGA */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-black uppercase tracking-wider text-slate-800 mb-2 flex items-center gap-1.5">
                <Store className="w-4 h-4 text-[#00a650]" />
                <span>OPÇÃO DE RECEBIMENTO (RETIRADA OU ENTREGA)</span>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-2.5">
                <button
                  type="button"
                  disabled={isReadOnly}
                  onClick={() => {
                    const text = 'Retirada na Loja / CD';
                    setObservacao((prev) => {
                      if (prev.includes('Entrega')) {
                        return prev.replace(/Entrega[^\n|]*/g, text);
                      }
                      if (!prev.includes('Retirada')) {
                        return prev ? `${prev} | ${text}` : text;
                      }
                      return prev;
                    });
                  }}
                  className={`p-3 rounded-xl border-2 text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                    observacao.toLowerCase().includes('retirada')
                      ? 'border-[#00a650] bg-emerald-50 text-emerald-950 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Store className="w-4 h-4 text-emerald-700" />
                    <span>Retirada na Loja / CD</span>
                  </div>
                  {observacao.toLowerCase().includes('retirada') && (
                    <Check className="w-3.5 h-3.5 text-[#00a650] stroke-[3]" />
                  )}
                </button>

                <button
                  type="button"
                  disabled={isReadOnly}
                  onClick={() => {
                    const text = 'Entrega em Domicílio';
                    setObservacao((prev) => {
                      if (prev.includes('Retirada')) {
                        return prev.replace(/Retirada[^\n|]*/g, text);
                      }
                      if (!prev.includes('Entrega')) {
                        return prev ? `${prev} | ${text}` : text;
                      }
                      return prev;
                    });
                  }}
                  className={`p-3 rounded-xl border-2 text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                    observacao.toLowerCase().includes('entrega')
                      ? 'border-[#00a650] bg-emerald-50 text-emerald-950 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-slate-700" />
                    <span>Entrega em Domicílio</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                      Transportadora
                    </span>
                    {observacao.toLowerCase().includes('entrega') && (
                      <Check className="w-3.5 h-3.5 text-[#00a650] stroke-[3]" />
                    )}
                  </div>
                </button>
              </div>
            </div>

            {/* Dados de Entrega / Endereço do Cliente */}
            <div className="sm:col-span-2 bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[#00a650]" />
                  <span>DADOS DE ENTREGA E CONTATO DO CLIENTE</span>
                </span>
                <span className="text-[11px] text-slate-500 font-medium">
                  Informações preenchidas no checkout
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Telefone / WhatsApp</label>
                  <input
                    type="text"
                    disabled={isReadOnly}
                    value={telefone}
                    onChange={(e) => setTelefone(e.target.value)}
                    placeholder="(11) 99999-9999"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-[#00a650] text-slate-900 bg-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">CEP</label>
                  <input
                    type="text"
                    disabled={isReadOnly}
                    value={cep}
                    onChange={(e) => setCep(e.target.value)}
                    placeholder="00000-000"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-[#00a650] text-slate-900 bg-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Valor do Frete (R$)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    disabled={isReadOnly}
                    value={valorFrete}
                    onChange={(e) => setValorFrete(e.target.value)}
                    placeholder="0.00"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-[#00a650] text-slate-900 font-bold bg-white outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Logradouro / Endereço</label>
                  <input
                    type="text"
                    disabled={isReadOnly}
                    value={endereco}
                    onChange={(e) => setEndereco(e.target.value)}
                    placeholder="Rua / Avenida..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-[#00a650] text-slate-900 bg-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Número</label>
                  <input
                    type="text"
                    disabled={isReadOnly}
                    value={numero}
                    onChange={(e) => setNumero(e.target.value)}
                    placeholder="123"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-[#00a650] text-slate-900 bg-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Complemento</label>
                  <input
                    type="text"
                    disabled={isReadOnly}
                    value={complemento}
                    onChange={(e) => setComplemento(e.target.value)}
                    placeholder="Apto, Bloco..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-[#00a650] text-slate-900 bg-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Bairro</label>
                  <input
                    type="text"
                    disabled={isReadOnly}
                    value={bairro}
                    onChange={(e) => setBairro(e.target.value)}
                    placeholder="Bairro"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:border-[#00a650] text-slate-900 bg-white outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Cidade</label>
                    <input
                      type="text"
                      disabled={isReadOnly}
                      value={cidade}
                      onChange={(e) => setCidade(e.target.value)}
                      placeholder="Cidade"
                      className="w-full px-2.5 py-2 rounded-lg border border-slate-300 focus:border-[#00a650] text-slate-900 bg-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">UF</label>
                    <input
                      type="text"
                      maxLength={2}
                      disabled={isReadOnly}
                      value={estado}
                      onChange={(e) => setEstado(e.target.value.toUpperCase())}
                      placeholder="SP"
                      className="w-full px-2.5 py-2 rounded-lg border border-slate-300 focus:border-[#00a650] text-slate-900 bg-white outline-none uppercase"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Observação / Detalhes / Endereço */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                OBSERVAÇÃO, ENDEREÇO OU DETALHES DE CONTATO
              </label>
              <textarea
                rows={3}
                disabled={isReadOnly}
                value={observacao}
                onChange={(e) => setObservacao(e.target.value)}
                placeholder="Ex: Endereço completo para entrega, ponto de referência, telefone de contato ou instruções especiais..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-[#00a650] text-slate-900 text-sm outline-none disabled:bg-slate-100 resize-none"
              />
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div>
              {/* Botão de Excluir Pedido no ADM */}
              {pedido && currentMode !== 'create' && (
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(true)}
                  className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Excluir este pedido"
                >
                  <Trash2 className="w-4 h-4 text-rose-600" />
                  <span>Excluir Pedido</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
              >
                {isReadOnly ? 'Fechar' : 'Cancelar'}
              </button>

              {currentMode === 'view' && (
                <button
                  type="button"
                  onClick={() => setCurrentMode('edit')}
                  className="px-5 py-2.5 bg-gradient-to-r from-[#ffd000] to-[#fbc02d] text-slate-950 text-xs font-black rounded-xl shadow-md hover:brightness-105 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>ALTERAR DADOS</span>
                </button>
              )}

              {!isReadOnly && (
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 bg-[#00a650] hover:bg-[#008f43] text-white text-xs font-extrabold rounded-xl shadow-md hover:shadow-lg transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Salvando no Supabase...</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4" />
                      <span>{currentMode === 'create' ? 'CRIAR PEDIDO' : 'SALVAR ALTERAÇÕES'}</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
