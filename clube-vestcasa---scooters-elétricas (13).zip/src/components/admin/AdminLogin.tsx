import React, { useState } from 'react';
import { 
  Lock, 
  KeyRound, 
  ArrowRight, 
  AlertCircle, 
  Loader2, 
  ArrowLeft,
  Eye,
  EyeOff
} from 'lucide-react';
import { validateAdminCode, setStoredAdminCode } from '../../services/adminConfigService';

interface AdminLoginProps {
  onSuccess: (user?: any) => void;
  onBackToClient: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ 
  onSuccess, 
  onBackToClient
}) => {
  const [accessCode, setAccessCode] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanCode = accessCode.trim();

    if (!cleanCode) {
      setErrorMessage('Por favor, digite o código de acesso.');
      return;
    }

    setLoading(true);

    try {
      // Validação prioritária e direta no banco de dados Supabase
      const isValid = await validateAdminCode(cleanCode);

      if (isValid) {
        setStoredAdminCode(cleanCode);
        const adminData = { id: 'admin', email: 'ADMIN2026@i', role: 'admin' };
        localStorage.setItem('vestcasa_admin_logged', 'true');
        localStorage.setItem('vestcasa_admin_user', JSON.stringify(adminData));
        
        setTimeout(() => {
          setLoading(false);
          onSuccess(adminData);
        }, 200);
      } else {
        setLoading(false);
        setErrorMessage('Código de acesso incorreto. Verifique e tente novamente.');
      }
    } catch (err: any) {
      // Fallback de segurança de contingência
      const isValidFallback = await validateAdminCode(cleanCode);
      if (isValidFallback) {
        setStoredAdminCode(cleanCode);
        const adminData = { id: 'admin', email: 'ADMIN2026@i', role: 'admin' };
        localStorage.setItem('vestcasa_admin_logged', 'true');
        setLoading(false);
        onSuccess(adminData);
      } else {
        setLoading(false);
        setErrorMessage(err.message || 'Código de acesso incorreto.');
      }
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-[#004d25] text-white p-6 text-center relative">
          <button
            onClick={onBackToClient}
            className="absolute left-4 top-4 text-xs font-bold text-emerald-200 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar</span>
          </button>

          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#005c2d] to-[#00a650] flex items-center justify-center mx-auto mb-3 shadow-md">
            <Lock className="w-7 h-7 text-white" />
          </div>

          <h2 className="text-xl font-black tracking-tight">ÁREA ADMINISTRATIVA</h2>
          <p className="text-xs text-emerald-200 mt-1">
            Acesso restrito à equipe autorizada
          </p>
        </div>

        {/* Form */}
        <div className="p-6">
          {errorMessage && (
            <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold flex items-start gap-2.5 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label 
                htmlFor="admin-access-code"
                className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-1.5"
              >
                CÓDIGO DE ACESSO
              </label>
              <div className="relative">
                <KeyRound className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="admin-access-code"
                  type={showCode ? 'text' : 'password'}
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  autoFocus
                  value={accessCode}
                  onChange={(e) => setAccessCode(e.target.value)}
                  placeholder="Digite o código de acesso"
                  required
                  className="w-full pl-11 pr-11 py-3.5 rounded-xl border-2 border-slate-200 focus:border-[#00a650] focus:ring-2 focus:ring-emerald-500/20 text-slate-900 text-base font-mono font-bold tracking-wider outline-none transition-all placeholder:text-slate-400"
                />
                <button
                  type="button"
                  onClick={() => setShowCode(!showCode)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer transition-colors"
                  title={showCode ? 'Ocultar código' : 'Exibir código'}
                >
                  {showCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-slate-400 mt-1.5 font-medium">
                Insira o código de segurança para acessar o painel de pedidos.
              </p>
            </div>

            <button
              id="btn-admin-submit"
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-gradient-to-r from-[#005c2d] to-[#00a650] hover:from-[#004d25] hover:to-[#008f43] text-white font-black text-sm rounded-xl shadow-md hover:shadow-lg active:scale-[0.98] transition-all flex items-center justify-center gap-2 uppercase tracking-wider cursor-pointer disabled:opacity-60 mt-4"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Validando Código...</span>
                </>
              ) : (
                <>
                  <span>ACESSAR PAINEL ADMINISTRATIVO</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
