import React, { useState, useEffect } from 'react';
import { 
  Tag, 
  Percent, 
  CheckCircle2, 
  Save, 
  AlertCircle, 
  ArrowLeft, 
  ShieldCheck, 
  Sparkles,
  Info,
  Power
} from 'lucide-react';
import { CouponConfig } from '../../types';
import { getCouponConfig, saveCouponConfig, DEFAULT_COUPON_CODE } from '../../services/couponService';

interface CouponManagementProps {
  onBackToOrders?: () => void;
}

export const CouponManagement: React.FC<CouponManagementProps> = ({ onBackToOrders }) => {
  const [codigo] = useState<string>(DEFAULT_COUPON_CODE);
  const [porcentagem, setPorcentagem] = useState<string>('10');
  const [ativo, setAtivo] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Carrega configuração atual salva
  const loadConfig = async () => {
    setIsLoading(true);
    try {
      const config = await getCouponConfig(DEFAULT_COUPON_CODE);
      setPorcentagem(String(config.porcentagem));
      setAtivo(config.ativo);
    } catch (err) {
      console.warn('Erro ao carregar cupom:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadConfig();
  }, []);

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(null);
    setSaveError(null);

    const numericPct = parseFloat(porcentagem.replace(',', '.'));
    if (isNaN(numericPct) || numericPct < 0 || numericPct > 100) {
      setSaveError('Por favor, informe uma porcentagem válida entre 0% e 100%.');
      setIsSaving(false);
      return;
    }

    try {
      const result = await saveCouponConfig({
        codigo,
        porcentagem: numericPct,
        ativo,
        descricao: `Cupom ${codigo} Vestcasa - ${numericPct}% OFF`
      });

      if (result.success) {
        setSaveSuccess(`Alterações salvas com sucesso! O cupom ${codigo} com ${numericPct}% de desconto (${ativo ? 'ATIVO' : 'DESATIVADO'}) já está valendo para as próximas compras.`);
        setTimeout(() => setSaveSuccess(null), 5000);
      } else {
        setSaveError(result.error || 'Erro ao salvar configuração do cupom.');
      }
    } catch (err: any) {
      setSaveError(err.message || 'Falha ao salvar cupom.');
    } finally {
      setIsSaving(false);
    }
  };

  // Cálculo de exemplo em tempo real com base no valor digitado
  const numPct = Math.max(0, Math.min(100, parseFloat(porcentagem.replace(',', '.')) || 0));
  const simProduto = 2390;
  const simDesconto = ativo ? Math.round((simProduto * (numPct / 100)) * 100) / 100 : 0;
  const simFrete = 180;
  const simTotal = simProduto - simDesconto + simFrete;

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(val);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header com Navegação */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shadow-sm">
            <Tag className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              CUPOM DE DESCONTO
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Gerencie a porcentagem e ativação do cupom oficial para o checkout
            </p>
          </div>
        </div>

        {onBackToOrders && (
          <button
            type="button"
            onClick={onBackToOrders}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar para Pedidos</span>
          </button>
        )}
      </div>

      {/* Alertas de Sucesso / Erro */}
      {saveSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 border-2 border-emerald-400 text-emerald-900 text-xs sm:text-sm font-bold flex items-start gap-3 shadow-xs animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            {saveSuccess}
          </div>
        </div>
      )}

      {saveError && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-300 text-rose-800 text-xs sm:text-sm font-semibold flex items-start gap-3 shadow-xs animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div>{saveError}</div>
        </div>
      )}

      {/* Formulário Principal de Configuração do Cupom */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-xs p-6 sm:p-7 space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h3 className="text-base font-black text-slate-900 uppercase tracking-wide flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <span>Configurações do Cupom</span>
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Defina a porcentagem de desconto livremente. O novo percentual passa a valer para as próximas compras.
            </p>
          </div>

          <form onSubmit={handleSave} className="space-y-6">
            {/* 1. Código do Cupom */}
            <div className="space-y-2">
              <label className="block text-xs font-black uppercase tracking-wider text-slate-700">
                Código:
              </label>
              <div className="flex items-center gap-3">
                <div className="flex-1 bg-slate-50 border-2 border-slate-300 rounded-xl px-4 py-3.5 flex items-center justify-between">
                  <span className="font-mono text-xl sm:text-2xl font-black text-[#005c2d] tracking-wider">
                    {codigo}
                  </span>
                  <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-black rounded-md uppercase tracking-wider border border-emerald-300">
                    Cupom Principal
                  </span>
                </div>
              </div>
              <span className="text-[11px] text-slate-500 block">
                Código fixo que os clientes digitarão no checkout: <strong>CLUBE2026</strong>.
              </span>
            </div>

            {/* 2. Porcentagem de desconto */}
            <div className="space-y-2">
              <label className="block text-xs font-black uppercase tracking-wider text-slate-700">
                Porcentagem de desconto:
              </label>
              <div className="relative max-w-xs">
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.5"
                  required
                  disabled={isLoading || isSaving}
                  value={porcentagem}
                  onChange={(e) => setPorcentagem(e.target.value)}
                  placeholder="10"
                  className="w-full pl-4 pr-12 py-3.5 rounded-xl border-2 border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20 text-xl font-mono font-black text-slate-900 bg-white outline-none transition-all"
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-black text-lg pointer-events-none">
                  %
                </div>
              </div>

              {/* Botões rápidos de exemplo solicitados */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="text-[11px] font-bold text-slate-500 mr-1">Atalhos rápidos:</span>
                {[5, 10, 15, 20].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => setPorcentagem(String(pct))}
                    className={`px-3 py-1.5 rounded-lg text-xs font-black border transition-all cursor-pointer ${
                      Number(porcentagem) === pct
                        ? 'bg-[#005c2d] text-white border-[#005c2d] shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    {pct}% de desconto
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Status: Ativo / Desativado */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <label className="block text-xs font-black uppercase tracking-wider text-slate-700">
                Status:
              </label>
              <div className="grid grid-cols-2 gap-3 max-w-sm">
                <button
                  type="button"
                  onClick={() => setAtivo(true)}
                  className={`p-3.5 rounded-xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    ativo
                      ? 'bg-emerald-50 border-[#00a650] text-[#005c2d] shadow-xs'
                      : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                  }`}
                >
                  <Power className={`w-4 h-4 ${ativo ? 'text-[#00a650]' : 'text-slate-400'}`} />
                  <span>Ativo</span>
                </button>

                <button
                  type="button"
                  onClick={() => setAtivo(false)}
                  className={`p-3.5 rounded-xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    !ativo
                      ? 'bg-rose-50 border-rose-400 text-rose-800 shadow-xs'
                      : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                  }`}
                >
                  <Power className={`w-4 h-4 ${!ativo ? 'text-rose-600' : 'text-slate-400'}`} />
                  <span>Desativado</span>
                </button>
              </div>
              <span className="text-[11px] text-slate-500 block">
                {ativo 
                  ? 'O cupom está ATIVO e pronto para ser aplicado pelos clientes no carrinho/checkout.'
                  : 'O cupom está DESATIVADO. Clientes que tentarem aplicar receberão aviso que o cupom está inativo.'}
              </span>
            </div>

            {/* 4. Botão Salvar alterações */}
            <div className="pt-4 border-t border-slate-100">
              <button
                type="submit"
                id="btn-salvar-cupom"
                disabled={isSaving}
                className="w-full sm:w-auto px-8 py-4 bg-[#00a650] hover:bg-[#008f43] text-white font-black text-sm rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 uppercase tracking-wider cursor-pointer active:scale-[0.98] disabled:opacity-60"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Salvando alterações...' : 'Salvar alterações'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Card Lateral: Simulação em Tempo Real & Informações de Segurança */}
        <div className="space-y-5">
          {/* Card de Simulação */}
          <div className="bg-slate-900 text-white rounded-2xl p-6 space-y-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Percent className="w-4 h-4" />
                <span>Exemplo de Cálculo</span>
              </span>
              <span className={`text-[10px] font-black px-2 py-0.5 rounded ${ativo ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                {ativo ? `${numPct}% ATIVO` : 'DESATIVADO'}
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Produto:</span>
                <strong className="font-mono text-white">{formatCurrency(simProduto)}</strong>
              </div>

              <div className="flex justify-between text-amber-400 font-bold">
                <span>Cupom {codigo} ({numPct}%):</span>
                <strong className="font-mono">
                  {ativo ? `- ${formatCurrency(simDesconto)}` : 'R$ 0,00'}
                </strong>
              </div>

              <div className="flex justify-between text-slate-300">
                <span>Frete:</span>
                <strong className="font-mono text-white">{formatCurrency(simFrete)}</strong>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-between items-baseline">
                <span className="font-black text-sm text-emerald-400 uppercase">Total:</span>
                <span className="text-xl sm:text-2xl font-black font-mono text-emerald-400">
                  {formatCurrency(simTotal)}
                </span>
              </div>
            </div>

            <div className="p-3 bg-slate-800/80 rounded-xl text-[11px] text-slate-400 space-y-1">
              <span className="font-bold text-slate-300 block">Regra Oficial:</span>
              <p>O percentual é aplicado SOMENTE sobre o valor do produto. O frete NÃO recebe desconto.</p>
            </div>
          </div>

          {/* Card de Regras de Segurança */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
            <div className="flex items-center gap-2 text-slate-900 font-black text-xs uppercase tracking-wide">
              <ShieldCheck className="w-4 h-4 text-[#00a650]" />
              <span>Segurança e Histórico</span>
            </div>
            <ul className="text-xs text-slate-600 space-y-2 list-disc list-inside leading-relaxed">
              <li>A porcentagem é consultada no banco de dados e nunca é controlada pelo navegador do cliente.</li>
              <li>O valor do desconto e da porcentagem são gravados no pedido no ato da compra.</li>
              <li>Alterações futuras na porcentagem <strong>não modificam pedidos antigos</strong> já registrados.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
