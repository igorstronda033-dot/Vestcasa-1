import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Edit3, 
  Image as ImageIcon, 
  Upload, 
  Check, 
  Sparkles, 
  Bike,
  AlertCircle,
  RotateCcw,
  QrCode
} from 'lucide-react';
import { ScooterModel } from '../../types';
import { 
  getScooterModels, 
  addScooterModel, 
  updateScooterModel, 
  deleteScooterModel,
  resetToDefaultModels,
  DEFAULT_SCOOTER_MODELS 
} from '../../services/scooterService';
import pixOfficialQrCode from '../../assets/images/pix_official_qrcode.png';
import { OFFICIAL_UNIFIED_PIX_PAYLOAD } from '../../lib/pix';

interface ModelManagementModalProps {
  onClose: () => void;
  onUpdated: () => void;
}

export const ModelManagementModal: React.FC<ModelManagementModalProps> = ({ 
  onClose, 
  onUpdated 
}) => {
  const [models, setModels] = useState<ScooterModel[]>(() => getScooterModels());
  const [editingModel, setEditingModel] = useState<ScooterModel | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  // Form states
  const [name, setName] = useState('');
  const [power, setPower] = useState('350W');
  const [price, setPrice] = useState('1990.00');
  const [tag, setTag] = useState('NOVO MODELO');
  const [description, setDescription] = useState('');
  const [colorsText, setColorsText] = useState('Vermelho, Preto, Branco');
  const [imageUrl, setImageUrl] = useState('');
  const [pixQrCodeSemFrete, setPixQrCodeSemFrete] = useState('');
  const [pixCopiaColaSemFrete, setPixCopiaColaSemFrete] = useState('');
  const [pixQrCodeComFrete, setPixQrCodeComFrete] = useState('');
  const [pixCopiaColaComFrete, setPixCopiaColaComFrete] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const resetForm = () => {
    setName('');
    setPower('350W');
    setPrice('1990.00');
    setTag('NOVO MODELO');
    setDescription('');
    setColorsText('Vermelho, Preto, Branco');
    setImageUrl('');
    setPixQrCodeSemFrete('');
    setPixCopiaColaSemFrete('');
    setPixQrCodeComFrete('');
    setPixCopiaColaComFrete('');
    setFormError(null);
    setEditingModel(null);
    setIsCreating(false);
  };

  const startCreate = () => {
    resetForm();
    setPixQrCodeSemFrete(pixOfficialQrCode);
    setPixCopiaColaSemFrete(OFFICIAL_UNIFIED_PIX_PAYLOAD);
    setIsCreating(true);
  };

  const startEdit = (model: ScooterModel) => {
    setEditingModel(model);
    setIsCreating(false);
    setName(model.name);
    setPower(model.power);
    setPrice(model.price.toString());
    setTag(model.tag);
    setDescription(model.description);
    setColorsText(model.colors.join(', '));
    setImageUrl(model.image);
    setPixQrCodeSemFrete(model.pixQrCodeSemFrete || '');
    setPixCopiaColaSemFrete(model.pixCopiaColaSemFrete || '');
    setPixQrCodeComFrete(model.pixQrCodeComFrete || '');
    setPixCopiaColaComFrete(model.pixCopiaColaComFrete || '');
    setFormError(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFormError('Por favor, selecione um arquivo de imagem válido (PNG ou JPG).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setImageUrl(reader.result);
        setFormError(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleQrUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFormError('Por favor, selecione uma imagem válida para o QR Code (PNG ou JPG).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setter(reader.result);
        setFormError(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setFormError('Informe o nome do modelo (ex: MU09, V20, V20 Pro).');
      return;
    }

    if (!imageUrl.trim()) {
      setFormError('Adicione a imagem correspondente a este modelo (URL ou upload).');
      return;
    }

    const parsedPrice = parseFloat(price) || 0;
    const colorsArray = colorsText
      .split(',')
      .map((c) => c.trim())
      .filter((c) => c.length > 0);

    if (editingModel) {
      updateScooterModel(editingModel.id, {
        name: name.trim(),
        power: power.trim(),
        price: parsedPrice,
        tag: tag.trim(),
        description: description.trim(),
        colors: colorsArray.length > 0 ? colorsArray : ['Vermelho', 'Preto', 'Branco'],
        image: imageUrl.trim(),
        pixQrCodeSemFrete: pixQrCodeSemFrete.trim(),
        pixCopiaColaSemFrete: pixCopiaColaSemFrete.trim(),
        pixQrCodeComFrete: pixQrCodeComFrete.trim(),
        pixCopiaColaComFrete: pixCopiaColaComFrete.trim(),
      });
    } else {
      addScooterModel({
        name: name.trim(),
        power: power.trim(),
        price: parsedPrice,
        tag: tag.trim(),
        description: description.trim(),
        colors: colorsArray.length > 0 ? colorsArray : ['Vermelho', 'Preto', 'Branco'],
        image: imageUrl.trim(),
        pixQrCodeSemFrete: pixQrCodeSemFrete.trim(),
        pixCopiaColaSemFrete: pixCopiaColaSemFrete.trim(),
        pixQrCodeComFrete: pixQrCodeComFrete.trim(),
        pixCopiaColaComFrete: pixCopiaColaComFrete.trim(),
      });
    }

    setModels(getScooterModels());
    resetForm();
    onUpdated();
  };

  const handleDelete = (id: string, modelName: string) => {
    if (!window.confirm(`Deseja realmente remover o modelo "${modelName}" do catálogo?`)) {
      return;
    }
    deleteScooterModel(id);
    setModels(getScooterModels());
    onUpdated();
  };

  const handleResetDefaults = () => {
    if (!window.confirm('Deseja restaurar os 4 modelos originais (MU02, MU03, MU09 e MU04) com as imagens oficiais?')) {
      return;
    }
    const defs = resetToDefaultModels();
    setModels(defs);
    resetForm();
    onUpdated();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-[#005c2d] text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center">
              <Bike className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">
                Gerenciar Modelos & Imagens de Scooter
              </h3>
              <p className="text-xs text-emerald-200">
                Cada modelo cadastrado possui sua própria imagem correspondente
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* Top Actions */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
            <div>
              <h4 className="font-extrabold text-slate-900 text-sm sm:text-base">
                Modelos Ativos no Catálogo ({models.length})
              </h4>
              <p className="text-xs text-slate-500">
                A imagem configurada é exibida automaticamente no catálogo e nas consultas de pedidos.
              </p>
            </div>

            {!isCreating && !editingModel && (
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleResetDefaults}
                  className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-300 transition-all flex items-center gap-1.5 cursor-pointer"
                  title="Restaura os 4 modelos originais com suas fotos correspondentes"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restaurar 4 Modelos Oficiais</span>
                </button>
                <button
                  type="button"
                  onClick={startCreate}
                  className="px-4 py-2.5 bg-[#00a650] hover:bg-[#008f43] text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Cadastrar Novo Modelo</span>
                </button>
              </div>
            )}
          </div>

          {/* Create or Edit Form */}
          {(isCreating || editingModel) && (
            <form onSubmit={handleSave} className="bg-slate-50 border-2 border-emerald-500/40 rounded-2xl p-4 sm:p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <span className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#00a650]" />
                  {editingModel ? `Editar Modelo: ${editingModel.name}` : 'Cadastrar Novo Modelo com Imagem Própria'}
                </span>
                <button
                  type="button"
                  onClick={resetForm}
                  className="text-xs text-slate-500 hover:text-slate-800 font-bold"
                >
                  Cancelar
                </button>
              </div>

              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Nome do modelo */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Nome do Modelo *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: MU09, V20, V20 Pro"
                    className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 text-sm font-bold text-slate-900 focus:border-[#00a650] outline-none"
                  />
                </div>

                {/* Potência */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Potência (Watts)
                  </label>
                  <input
                    type="text"
                    value={power}
                    onChange={(e) => setPower(e.target.value)}
                    placeholder="Ex: 350W, 750W, 1000W"
                    className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 text-sm text-slate-900 focus:border-[#00a650] outline-none"
                  />
                </div>

                {/* Preço */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Preço (R$) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="Ex: 2190.00"
                    className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 text-sm font-bold text-[#008f43] focus:border-[#00a650] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Tag */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Tag / Destaque
                  </label>
                  <input
                    type="text"
                    value={tag}
                    onChange={(e) => setTag(e.target.value)}
                    placeholder="Ex: MAIS POPULAR, ALTA PERFORMANCE"
                    className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 text-sm text-slate-900 focus:border-[#00a650] outline-none"
                  />
                </div>

                {/* Cores */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Cores Disponíveis (separadas por vírgula)
                  </label>
                  <input
                    type="text"
                    value={colorsText}
                    onChange={(e) => setColorsText(e.target.value)}
                    placeholder="Ex: Vermelho, Preto, Branco"
                    className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 text-sm text-slate-900 focus:border-[#00a650] outline-none"
                  />
                </div>
              </div>

              {/* Descrição */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Descrição Curta
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Descreva as principais características deste modelo específico..."
                  className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 text-xs text-slate-900 focus:border-[#00a650] outline-none"
                />
              </div>

              {/* Imagem do Modelo (Field required by user) */}
              <div className="bg-white p-4 rounded-xl border border-slate-200">
                <label className="block text-xs font-black text-slate-800 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <ImageIcon className="w-4 h-4 text-[#00a650]" />
                  <span>IMAGEM ESPECÍFICA DO MODELO (PNG com fundo transparente / JPG limpo) *</span>
                </label>
                <p className="text-[11px] text-slate-500 mb-3">
                  Insira o link da imagem ou faça o upload direto de uma foto correspondente a esta scooter.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
                  <div className="sm:col-span-2 space-y-3">
                    <div>
                      <input
                        type="text"
                        value={imageUrl}
                        onChange={(e) => setImageUrl(e.target.value)}
                        placeholder="https://exemplo.com/scooter-modelo.png ou data:image..."
                        className="w-full px-3 py-2 bg-slate-50 rounded-xl border border-slate-300 text-xs text-slate-800 focus:border-[#00a650] outline-none"
                      />
                    </div>

                    <div className="flex items-center gap-3">
                      <label className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 cursor-pointer flex items-center gap-1.5 transition-colors">
                        <Upload className="w-3.5 h-3.5 text-[#00a650]" />
                        <span>Fazer Upload do Arquivo</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="hidden"
                        />
                      </label>
                      <span className="text-[11px] text-slate-400">PNG, WebP ou JPG</span>
                    </div>

                    {/* Quick preset selection from existing models */}
                    <div className="pt-2">
                      <span className="text-[11px] font-bold text-slate-600 block mb-1">
                        Ou usar como base uma foto de modelo pré-carregada:
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {DEFAULT_SCOOTER_MODELS.map((d) => (
                          <button
                            key={d.id}
                            type="button"
                            onClick={() => setImageUrl(d.image)}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 text-slate-700 text-[11px] font-bold rounded-lg border border-slate-200 transition-colors"
                          >
                            Foto da {d.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Image Preview Box */}
                  <div className="flex flex-col items-center justify-center p-3 bg-slate-50 border border-dashed border-slate-300 rounded-xl min-h-[140px]">
                    {imageUrl ? (
                      <div className="text-center space-y-1">
                        <div className="w-24 h-24 mx-auto rounded-lg overflow-hidden bg-white border border-slate-200 p-1 flex items-center justify-center">
                          <img
                            src={imageUrl}
                            alt="Prévia do modelo"
                            referrerPolicy="no-referrer"
                            className="max-h-full max-w-full object-contain"
                          />
                        </div>
                        <span className="text-[10px] text-emerald-700 font-bold block">
                          Imagem Carregada ✓
                        </span>
                      </div>
                    ) : (
                      <div className="text-center text-slate-400 space-y-1">
                        <ImageIcon className="w-8 h-8 mx-auto stroke-1 text-slate-300" />
                        <span className="text-[11px] block">Sem imagem</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Configurações de Pagamento PIX (Sem Frete e Com Frete) */}
              <div className="border-t border-slate-200 pt-4 space-y-3">
                <div className="flex items-center gap-2">
                  <QrCode className="w-4 h-4 text-[#00a650]" />
                  <span className="text-xs font-black uppercase tracking-wider text-slate-800">
                    Configurações de Pagamento Pix
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Sem Frete */}
                  <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span className="text-xs font-black uppercase tracking-wider text-slate-700">
                        Pix: Sem Frete
                      </span>
                      <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                        Padrão
                      </span>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                        QR Code SEM FRETE
                      </label>
                      <input
                        type="text"
                        value={pixQrCodeSemFrete}
                        onChange={(e) => setPixQrCodeSemFrete(e.target.value)}
                        placeholder="URL da imagem do QR Code ou upload abaixo"
                        className="w-full px-3 py-2 bg-slate-50 rounded-xl border border-slate-300 text-xs text-slate-800 focus:border-[#00a650] outline-none mb-2"
                      />
                      <div className="flex items-center gap-3">
                        <label className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg border border-slate-300 cursor-pointer flex items-center gap-1 transition-colors">
                          <Upload className="w-3.5 h-3.5 text-[#00a650]" />
                          <span>Upload QR Code</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleQrUpload(e, setPixQrCodeSemFrete)}
                            className="hidden"
                          />
                        </label>
                        {pixQrCodeSemFrete && (
                          <div className="flex items-center gap-1.5">
                            <div className="w-6 h-6 rounded border border-slate-200 overflow-hidden shrink-0 bg-white">
                              <img src={pixQrCodeSemFrete} alt="QR Code" className="w-full h-full object-contain" />
                            </div>
                            <span className="text-[10px] text-emerald-700 font-bold">QR Definido ✓</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                        Pix Copia e Cola SEM FRETE
                      </label>
                      <textarea
                        rows={3}
                        value={pixCopiaColaSemFrete}
                        onChange={(e) => setPixCopiaColaSemFrete(e.target.value)}
                        placeholder="Cole aqui o código Pix Copia e Cola sem frete..."
                        className="w-full px-3 py-2 bg-slate-50 rounded-xl border border-slate-300 text-xs text-slate-800 font-mono focus:border-[#00a650] outline-none"
                      />
                    </div>
                  </div>

                  {/* Com Frete */}
                  <div className="bg-emerald-50/20 p-4 rounded-xl border border-emerald-300/80 space-y-3">
                    <div className="flex items-center justify-between border-b border-emerald-100 pb-2">
                      <span className="text-xs font-black uppercase tracking-wider text-[#005c2d]">
                        Pix: Com Frete
                      </span>
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                        Com Frete
                      </span>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                        QR Code COM FRETE
                      </label>
                      <input
                        type="text"
                        value={pixQrCodeComFrete}
                        onChange={(e) => setPixQrCodeComFrete(e.target.value)}
                        placeholder="URL da imagem do QR Code ou upload abaixo"
                        className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 text-xs text-slate-800 focus:border-[#00a650] outline-none mb-2"
                      />
                      <div className="flex items-center gap-3">
                        <label className="px-2.5 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 text-xs font-bold rounded-lg border border-emerald-300 cursor-pointer flex items-center gap-1 transition-colors">
                          <Upload className="w-3.5 h-3.5 text-[#00a650]" />
                          <span>Upload QR Code</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleQrUpload(e, setPixQrCodeComFrete)}
                            className="hidden"
                          />
                        </label>
                        {pixQrCodeComFrete && (
                          <div className="flex items-center gap-1.5">
                            <div className="w-6 h-6 rounded border border-slate-200 overflow-hidden shrink-0 bg-white">
                              <img src={pixQrCodeComFrete} alt="QR Code" className="w-full h-full object-contain" />
                            </div>
                            <span className="text-[10px] text-emerald-700 font-bold">QR Definido ✓</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                        Pix Copia e Cola COM FRETE
                      </label>
                      <textarea
                        rows={3}
                        value={pixCopiaColaComFrete}
                        onChange={(e) => setPixCopiaColaComFrete(e.target.value)}
                        placeholder="Cole aqui o código Pix Copia e Cola com frete..."
                        className="w-full px-3 py-2 bg-white rounded-xl border border-slate-300 text-xs text-slate-800 font-mono focus:border-[#00a650] outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#00a650] hover:bg-[#008f43] text-white font-bold text-xs rounded-xl transition-colors shadow-xs flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingModel ? 'Atualizar Modelo' : 'Salvar Novo Modelo'}</span>
                </button>
              </div>
            </form>
          )}

          {/* Models Grid / List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {models.map((model) => (
              <div
                key={model.id}
                className="bg-white border border-slate-200 hover:border-slate-300 rounded-2xl p-4 shadow-xs flex gap-3.5 items-center justify-between transition-all"
              >
                {/* Model Image Thumbnail */}
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-slate-50 rounded-xl border border-slate-200 p-1.5 shrink-0 flex items-center justify-center overflow-hidden">
                  <img
                    src={model.image}
                    alt={model.name}
                    referrerPolicy="no-referrer"
                    className="max-h-full max-w-full object-contain"
                  />
                </div>

                {/* Model Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h5 className="text-base font-black text-slate-900 truncate">
                      {model.name}
                    </h5>
                    <span className="bg-[#ffd000] text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded">
                      {model.power}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-500 line-clamp-2 mb-1.5">
                    {model.description}
                  </p>

                  <div className="flex items-center justify-between">
                    <span className="text-sm font-black text-[#00a650]">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(model.price)}
                    </span>
                    <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                      {model.tag}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col gap-1 shrink-0 border-l border-slate-100 pl-2">
                  <button
                    type="button"
                    onClick={() => startEdit(model)}
                    title="Editar modelo e imagem"
                    className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(model.id, model.name)}
                    title="Remover modelo"
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
