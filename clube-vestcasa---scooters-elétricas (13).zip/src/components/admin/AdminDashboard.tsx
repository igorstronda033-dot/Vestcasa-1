import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Eye, 
  Edit3, 
  Trash2, 
  Check, 
  RefreshCw, 
  Database, 
  LogOut, 
  Bike, 
  DollarSign, 
  Layers, 
  Copy,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  AlertTriangle,
  Truck,
  Tag
} from 'lucide-react';
import { Pedido, PaymentStatus } from '../../types';
import { listAllOrders, updateOrderStatus, deleteOrder } from '../../services/orderService';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { OrderModal } from './OrderModal';
import { ModelManagementModal } from './ModelManagementModal';
import { ShippingRulesManagement } from './ShippingRulesManagement';
import { CouponManagement } from './CouponManagement';
import { getModelImage } from '../../services/scooterService';

interface AdminDashboardProps {
  onLogout: () => void;
  onViewClientArea: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  onLogout, 
  onViewClientArea 
}) => {
  const [pedidos, setPedidos] = useState<Pedido[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Filters
  const [searchFilter, setSearchFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('Todos');
  const [productFilter, setProductFilter] = useState<string>('Todos');
  const [colorFilter, setColorFilter] = useState<string>('Todas');

  // Modals
  const [modalMode, setModalMode] = useState<'create' | 'edit' | 'view' | null>(null);
  const [selectedPedido, setSelectedPedido] = useState<Pedido | null>(null);
  const [showModelsModal, setShowModelsModal] = useState(false);

  // Admin Active Tab
  const [activeTab, setActiveTab] = useState<'pedidos' | 'frete' | 'cupom'>('pedidos');

  // In-app confirmation dialogs (prevents iframe sandbox block)
  const [orderToDelete, setOrderToDelete] = useState<Pedido | null>(null);
  const [orderToConfirmPayment, setOrderToConfirmPayment] = useState<Pedido | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);

  // Feedback states
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const fetchOrders = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const { data, error } = await listAllOrders();
      if (error) {
        setErrorMsg(error);
      } else {
        setPedidos(data);
      }
    } catch (err: any) {
      setErrorMsg('Erro ao conectar ao Supabase.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();

    // Auto-poll every 15 seconds so admin sees customer payment reports live
    const interval = setInterval(() => {
      fetchOrders();
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const handleConfirmPaymentConfirmed = async () => {
    if (!orderToConfirmPayment) return;
    setIsConfirming(true);
    setActionError(null);
    try {
      const { success, error } = await updateOrderStatus(orderToConfirmPayment.id, 'Pago');
      if (success) {
        setActionSuccess(`Pagamento do pedido #${orderToConfirmPayment.codigo} (${orderToConfirmPayment.nome_cliente}) confirmado com sucesso!`);
        setOrderToConfirmPayment(null);
        fetchOrders();
        setTimeout(() => setActionSuccess(null), 4000);
      } else {
        setActionError(error || 'Erro ao confirmar pagamento.');
      }
    } catch (err: any) {
      setActionError(err.message || 'Falha ao confirmar pagamento.');
    } finally {
      setIsConfirming(false);
    }
  };

  const handleDeleteConfirmed = async () => {
    if (!orderToDelete) return;
    setIsDeleting(true);
    setActionError(null);
    try {
      const { success, error } = await deleteOrder(orderToDelete.id);
      if (success) {
        setActionSuccess(`Pedido #${orderToDelete.codigo} de ${orderToDelete.nome_cliente} excluído com sucesso.`);
        setOrderToDelete(null);
        fetchOrders();
        setTimeout(() => setActionSuccess(null), 4000);
      } else {
        setActionError(error || 'Erro ao excluir pedido.');
      }
    } catch (err: any) {
      setActionError(err.message || 'Falha ao excluir pedido.');
    } finally {
      setIsDeleting(false);
    }
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(val);
  };

  const formatDate = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoString;
    }
  };

  // Filtered orders list
  const filteredPedidos = pedidos.filter((item) => {
    const matchesSearch = 
      item.codigo.toLowerCase().includes(searchFilter.toLowerCase()) ||
      item.nome_cliente.toLowerCase().includes(searchFilter.toLowerCase()) ||
      item.produto.toLowerCase().includes(searchFilter.toLowerCase()) ||
      (item.cpf && item.cpf.includes(searchFilter));

    const matchesStatus = statusFilter === 'Todos' || item.status_pagamento === statusFilter;
    const matchesProduct = productFilter === 'Todos' || item.produto.includes(productFilter);
    const matchesColor = colorFilter === 'Todas' || (item.cor && item.cor.toLowerCase().includes(colorFilter.toLowerCase()));

    return matchesSearch && matchesStatus && matchesProduct && matchesColor;
  });

  // KPI Calculations
  const totalCount = pedidos.length;
  const pendingConfirmationCount = pedidos.filter((p) => p.status_pagamento === 'Cliente informou pagamento').length;
  const paidCount = pedidos.filter((p) => p.status_pagamento === 'Pago').length;
  const pendingCount = pedidos.filter((p) => p.status_pagamento === 'Pendente').length;
  const totalRevenue = pedidos
    .filter((p) => p.status_pagamento === 'Pago')
    .reduce((acc, p) => acc + (Number(p.valor) || 0), 0);

  const getStatusBadge = (status: PaymentStatus) => {
    switch (status) {
      case 'Pago':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Pago
          </span>
        );
      case 'Cliente informou pagamento':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-amber-100 text-amber-900 border border-amber-400 animate-pulse">
            <Clock className="w-3 h-3 text-amber-700" />
            Aguardando Confirmação
          </span>
        );
      case 'Cancelado':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300">
            <AlertCircle className="w-3 h-3 text-rose-600" />
            Cancelado
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-yellow-100 text-yellow-900 border border-yellow-300">
            <Clock className="w-3 h-3 text-yellow-700" />
            Pendente
          </span>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Bar / Admin Header */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-[#005c2d] text-white flex items-center justify-center shadow-md">
            <Bike className="w-6 h-6 text-yellow-300" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              PAINEL ADMINISTRATIVO
            </h1>
            <div className="flex flex-wrap items-center gap-2 mt-0.5">
              <p className="text-xs text-slate-500 font-medium">
                Gerenciamento de Pedidos • Scooters Elétricas Vestcasa
              </p>
              {isSupabaseConfigured() && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-emerald-50 border border-emerald-300 text-[#006e33]">
                  <span className="w-2 h-2 rounded-full bg-[#00a650] animate-pulse" />
                  Supabase Conectado
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <button
            onClick={onViewClientArea}
            className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-[#005c2d] border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Área do Cliente</span>
          </button>

          <button
            onClick={onLogout}
            className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sair</span>
          </button>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('pedidos')}
          className={`px-4 py-2.5 rounded-xl font-black text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'pedidos'
              ? 'bg-[#005c2d] text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Pedidos ({totalCount})</span>
        </button>

        <button
          onClick={() => setActiveTab('frete')}
          className={`px-4 py-2.5 rounded-xl font-black text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'frete'
              ? 'bg-[#005c2d] text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Truck className="w-4 h-4 text-yellow-300" />
          <span>Configuração de Frete</span>
        </button>

        <button
          onClick={() => setActiveTab('cupom')}
          className={`px-4 py-2.5 rounded-xl font-black text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'cupom'
              ? 'bg-[#005c2d] text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Tag className="w-4 h-4 text-yellow-300" />
          <span>Cupom de desconto</span>
        </button>
      </div>

      {activeTab === 'frete' ? (
        <ShippingRulesManagement onBackToOrders={() => setActiveTab('pedidos')} />
      ) : activeTab === 'cupom' ? (
        <CouponManagement onBackToOrders={() => setActiveTab('pedidos')} />
      ) : (
        <>
          {/* KPI Overview Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {/* Total Pedidos */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Total de Pedidos</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl sm:text-3xl font-black text-slate-900">{totalCount}</span>
                <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">Banco Real</span>
              </div>
            </div>

            {/* Aguardando Confirmação (Highlight) */}
            <div className="bg-amber-50/70 p-4 sm:p-5 rounded-2xl border-2 border-amber-300 shadow-xs relative overflow-hidden">
              {pendingConfirmationCount > 0 && (
                <span className="absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping" />
              )}
              <span className="text-[11px] font-extrabold text-amber-900 uppercase tracking-wider block">Aguardando Confirmação</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl sm:text-3xl font-black text-amber-900">{pendingConfirmationCount}</span>
                <span className="text-xs font-bold text-amber-800 bg-amber-200/80 px-2 py-0.5 rounded">Ação Necessária</span>
              </div>
            </div>

            {/* Pedidos Pagos */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Confirmados / Pagos</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-2xl sm:text-3xl font-black text-emerald-600">{paidCount}</span>
                <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">Concluídos</span>
              </div>
            </div>

            {/* Faturamento Total */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Faturamento Pago</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-xl sm:text-2xl font-black text-[#005c2d] truncate">
                  {formatCurrency(totalRevenue)}
                </span>
                <TrendingUp className="w-4 h-4 text-[#00a650] shrink-0" />
              </div>
            </div>
          </div>

      {/* Success Notification Banner */}
      {actionSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-800 text-xs sm:text-sm font-bold flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{actionSuccess}</span>
          </div>
          <button onClick={() => setActionSuccess(null)} className="text-xs text-emerald-700 hover:underline cursor-pointer">
            Fechar
          </button>
        </div>
      )}

      {/* Error Notification Banner */}
      {actionError && (
        <div className="p-3.5 bg-rose-50 border border-rose-300 rounded-xl text-rose-800 text-xs sm:text-sm font-bold flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{actionError}</span>
          </div>
          <button onClick={() => setActionError(null)} className="text-xs text-rose-700 hover:underline cursor-pointer">
            Fechar
          </button>
        </div>
      )}

      {/* Table & Controls Section */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Controls Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Buscar por código, cliente, CPF ou produto..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-emerald-500/20 text-xs sm:text-sm outline-none"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={fetchOrders}
                title="Recarregar do Supabase"
                className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>

              {/* Button: Modelos & Imagens */}
              <button
                onClick={() => setShowModelsModal(true)}
                className="px-3.5 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-[#005c2d] border border-emerald-300 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Gerenciar modelos e fotos específicas das scooters"
              >
                <Bike className="w-4 h-4 text-[#00a650]" />
                <span className="hidden sm:inline">Modelos & Fotos</span>
                <span className="sm:hidden">Modelos</span>
              </button>

              {/* Button: Configuração de Frete */}
              <button
                onClick={() => setActiveTab('frete')}
                className="px-3.5 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-[#005c2d] border border-emerald-300 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Configurar regras e valores de frete por CEP"
              >
                <Truck className="w-4 h-4 text-[#00a650]" />
                <span className="hidden sm:inline">Configurar Frete</span>
                <span className="sm:hidden">Frete</span>
              </button>

              {/* Button: Novo Pedido */}
              <button
                id="btn-admin-novo-pedido"
                onClick={() => { setSelectedPedido(null); setModalMode('create'); }}
                className="px-4 py-2.5 bg-gradient-to-r from-[#ffd000] to-[#fbc02d] text-slate-950 font-black text-xs sm:text-sm rounded-xl shadow-md hover:brightness-105 active:scale-95 transition-all flex items-center gap-2 uppercase tracking-wide cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>CRIAR PEDIDO</span>
              </button>
            </div>
          </div>

          {/* Filters Bar */}
          <div className="space-y-2 pt-1 text-xs">
            {/* Status Filter */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-slate-400 font-bold flex items-center gap-1 min-w-[65px]">
                <Filter className="w-3.5 h-3.5" />
                Status:
              </span>
              {['Todos', 'Pendente', 'Cliente informou pagamento', 'Pago', 'Cancelado'].map((status) => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    statusFilter === status
                      ? 'bg-[#005c2d] text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {status === 'Cliente informou pagamento' ? 'Aguardando Confirmação' : status}
                  {status === 'Cliente informou pagamento' && pendingConfirmationCount > 0 && (
                    <span className="ml-1.5 bg-amber-400 text-slate-900 px-1.5 py-0.2 rounded-full text-[10px] font-black">
                      {pendingConfirmationCount}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {/* Model Filter */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-slate-400 font-bold min-w-[65px]">
                Modelos:
              </span>
              {['Todos', 'MU02', 'MU03', 'MU09', 'MU04'].map((modelName) => (
                <button
                  key={modelName}
                  onClick={() => setProductFilter(modelName)}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    productFilter === modelName
                      ? 'bg-[#00a650] text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {modelName === 'Todos' ? 'Todos os Modelos' : `Scooter ${modelName}`}
                </button>
              ))}
            </div>

            {/* Color Filter */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-slate-400 font-bold min-w-[65px]">
                Cores:
              </span>
              {[
                { label: 'Todas', hex: null },
                { label: 'Vermelho', hex: '#dc2626' },
                { label: 'Preto', hex: '#0f172a' },
                { label: 'Branco', hex: '#ffffff' },
              ].map((c) => (
                <button
                  key={c.label}
                  onClick={() => setColorFilter(c.label)}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    colorFilter === c.label
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {c.hex && (
                    <span
                      className="w-2.5 h-2.5 rounded-full border border-slate-300"
                      style={{ backgroundColor: c.hex }}
                    />
                  )}
                  <span>{c.label === 'Todas' ? 'Todas as Cores' : c.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Orders Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Código</th>
                <th className="py-3 px-4">Cliente</th>
                <th className="py-3 px-4">Produto & Cor</th>
                <th className="py-3 px-4">Valor</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Data</th>
                <th className="py-3 px-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading && pedidos.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto text-[#00a650] mb-2" />
                    <span>Carregando pedidos do Supabase...</span>
                  </td>
                </tr>
              ) : filteredPedidos.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    <Bike className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    <p className="font-bold text-slate-700">Nenhum pedido encontrado</p>
                    <p className="text-xs text-slate-400 mt-1">
                      {searchFilter || statusFilter !== 'Todos'
                        ? 'Tente ajustar os filtros de busca.'
                        : 'Clique em "CRIAR PEDIDO" acima para cadastrar o primeiro cliente.'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredPedidos.map((pedido) => {
                  const isAwaitingConfirmation = pedido.status_pagamento === 'Cliente informou pagamento';
                  return (
                    <tr 
                      key={pedido.id} 
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isAwaitingConfirmation ? 'bg-amber-50/50' : ''
                      }`}
                    >
                      {/* Código */}
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        <span className="bg-slate-100 px-2 py-1 rounded text-[#005c2d]">
                          {pedido.codigo}
                        </span>
                      </td>

                      {/* Cliente */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{pedido.nome_cliente}</div>
                        {pedido.cpf && (
                          <div className="text-[11px] text-slate-400 font-mono">{pedido.cpf}</div>
                        )}
                      </td>

                      {/* Produto & Cor */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-10 h-10 bg-slate-50 rounded-lg border border-slate-200 p-0.5 shrink-0 flex items-center justify-center overflow-hidden">
                            <img
                              src={pedido.imagem_url || getModelImage(pedido.produto)}
                              alt={pedido.produto}
                              referrerPolicy="no-referrer"
                              className="max-h-full max-w-full object-contain"
                            />
                          </div>
                          <div>
                            <div className="font-medium text-slate-800">{pedido.produto}</div>
                            <div className="text-[11px] text-slate-500">{pedido.cor || 'Sem cor informada'}</div>
                          </div>
                        </div>
                      </td>

                      {/* Valor */}
                      <td className="py-3.5 px-4 font-extrabold text-slate-900">
                        <div>{formatCurrency(pedido.valor)}</div>
                        {pedido.cupom_codigo && (
                          <div className="text-[10px] text-amber-800 font-bold flex items-center gap-1 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200 mt-0.5 w-fit">
                            <Tag className="w-2.5 h-2.5 text-amber-600" />
                            <span>{pedido.cupom_codigo}</span>
                            {pedido.cupom_porcentagem ? <span>(-{pedido.cupom_porcentagem}%)</span> : null}
                          </div>
                        )}
                        {pedido.valor_frete !== undefined && pedido.valor_frete !== null && pedido.valor_frete > 0 ? (
                          <div className="text-[10px] text-slate-500 font-medium">
                            Frete: {formatCurrency(pedido.valor_frete)}
                          </div>
                        ) : pedido.tipo_entrega === 'retirada' || pedido.frete === 'sem_frete' ? (
                          <div className="text-[10px] text-emerald-700 font-medium">
                            Retirada na loja
                          </div>
                        ) : null}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        {getStatusBadge(pedido.status_pagamento)}
                      </td>

                      {/* Data */}
                      <td className="py-3.5 px-4 text-xs text-slate-500 whitespace-nowrap">
                        {formatDate(pedido.created_at)}
                      </td>

                      {/* Ações */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {/* Confirm Payment button if awaiting or pending */}
                          {pedido.status_pagamento !== 'Pago' && (
                            <button
                              onClick={() => setOrderToConfirmPayment(pedido)}
                              title="Confirmar Pagamento e marcar como PAGO"
                              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                                isAwaitingConfirmation
                                  ? 'bg-[#00a650] hover:bg-[#008f43] text-white shadow-xs'
                                  : 'bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800'
                              }`}
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">Confirmar</span>
                            </button>
                          )}

                          {/* Visualizar */}
                          <button
                            onClick={() => { setSelectedPedido(pedido); setModalMode('view'); }}
                            title="Visualizar pedido completo"
                            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Editar */}
                          <button
                            onClick={() => { setSelectedPedido(pedido); setModalMode('edit'); }}
                            title="Alterar dados do pedido"
                            className="p-1.5 rounded-lg text-slate-500 hover:text-[#005c2d] hover:bg-emerald-50 transition-colors cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          {/* Excluir */}
                          <button
                            onClick={() => setOrderToDelete(pedido)}
                            title="Excluir pedido"
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
      </>
      )}

      {/* Create / Edit / View Modal */}
      {modalMode && (
        <OrderModal
          mode={modalMode}
          pedido={selectedPedido}
          onClose={() => setModalMode(null)}
          onSaved={() => {
            setModalMode(null);
            fetchOrders();
            setActionSuccess('Pedido salvo com sucesso!');
            setTimeout(() => setActionSuccess(null), 4000);
          }}
          onDeleteOrder={(orderId) => {
            const p = pedidos.find((x) => x.id === orderId);
            if (p) {
              setModalMode(null);
              setOrderToDelete(p);
            }
          }}
        />
      )}

      {/* In-App Confirmation Modal: Delete Order */}
      {orderToDelete && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="p-6 text-center">
              <div className="w-14 h-14 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-4 border border-rose-200">
                <Trash2 className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-black text-slate-900">
                Excluir Pedido #{orderToDelete.codigo}?
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-2">
                Tem certeza que deseja excluir permanentemente o pedido de{' '}
                <strong className="text-slate-900">{orderToDelete.nome_cliente}</strong>{' '}
                ({orderToDelete.produto}) no valor de{' '}
                <strong className="text-slate-900">{formatCurrency(orderToDelete.valor)}</strong>?
              </p>
              <p className="text-[11px] font-bold text-rose-600 bg-rose-50 border border-rose-200 rounded-lg p-2.5 mt-3 text-left flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>Esta operação não pode ser desfeita. O pedido será removido do banco de dados.</span>
              </p>
            </div>
            <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-end gap-2.5">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setOrderToDelete(null)}
                className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleDeleteConfirmed}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl shadow-md transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
              >
                {isDeleting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Excluindo...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>CONFIRMAR EXCLUSÃO</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-App Confirmation Modal: Confirm Payment */}
      {orderToConfirmPayment && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="p-6 text-center">
              <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-[#00a650] flex items-center justify-center mx-auto mb-4 border border-emerald-200">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-black text-slate-900">
                Confirmar Pagamento?
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-2">
                Deseja marcar o pedido <strong>#{orderToConfirmPayment.codigo}</strong> de{' '}
                <strong className="text-slate-900">{orderToConfirmPayment.nome_cliente}</strong> como{' '}
                <strong className="text-emerald-700">PAGO</strong>?
              </p>
              <div className="mt-3 p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-semibold text-emerald-900 flex justify-between items-center">
                <span>Valor a confirmar:</span>
                <span className="font-black text-sm">{formatCurrency(orderToConfirmPayment.valor)}</span>
              </div>
            </div>
            <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-end gap-2.5">
              <button
                type="button"
                disabled={isConfirming}
                onClick={() => setOrderToConfirmPayment(null)}
                className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={isConfirming}
                onClick={handleConfirmPaymentConfirmed}
                className="px-5 py-2 bg-[#00a650] hover:bg-[#008f43] text-white text-xs font-black rounded-xl shadow-md transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
              >
                {isConfirming ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Confirmando...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>MARCAR COMO PAGO</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Scooter Models & Custom Images Modal */}
      {showModelsModal && (
        <ModelManagementModal
          onClose={() => setShowModelsModal(false)}
          onUpdated={() => {
            fetchOrders();
          }}
        />
      )}
    </div>
  );
};
