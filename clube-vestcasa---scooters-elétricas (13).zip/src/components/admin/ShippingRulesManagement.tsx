import React, { useState, useEffect } from 'react';
import { 
  Truck, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  MapPin, 
  RefreshCw, 
  Check, 
  X, 
  Filter, 
  DollarSign, 
  Bike,
  HelpCircle,
  Calculator
} from 'lucide-react';
import { ShippingRule } from '../../types';
import { 
  listShippingRules, 
  createShippingRule, 
  updateShippingRule, 
  deleteShippingRule, 
  toggleShippingRuleActive,
  calculateShippingForCep
} from '../../services/shippingService';
import { getScooterModels } from '../../services/scooterService';
import { maskCep } from '../CheckoutModal';

interface ShippingRulesManagementProps {
  onBackToOrders?: () => void;
}

export const ShippingRulesManagement: React.FC<ShippingRulesManagementProps> = ({ onBackToOrders }) => {
  const [rules, setRules] = useState<ShippingRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEstado, setSelectedEstado] = useState<string>('Todos');

  // Modal de Criação / Edição
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<ShippingRule | null>(null);

  // Campos do Formulário
  const [nomeRegiao, setNomeRegiao] = useState('');
  const [estado, setEstado] = useState('SP');
  const [cidade, setCidade] = useState('');
  const [cepInicio, setCepInicio] = useState('');
  const [cepFim, setCepFim] = useState('');
  const [valorFrete, setValorFrete] = useState<string>('150');
  const [prazoEstimado, setPrazoEstimado] = useState('3 a 5 dias úteis');
  const [isFreteGratis, setIsFreteGratis] = useState(false);
  const [isAtivo, setIsAtivo] = useState(true);
  const [selectedModels, setSelectedModels] = useState<string[]>([]);
  const [restrictToModels, setRestrictToModels] = useState(false);

  // Diálogo de confirmação de exclusão
  const [ruleToDelete, setRuleToDelete] = useState<ShippingRule | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Mensagens de Feedback
  const [feedbackSuccess, setFeedbackSuccess] = useState<string | null>(null);
  const [feedbackError, setFeedbackError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Teste de CEP em tempo real (Simulador Admin)
  const [testCep, setTestCep] = useState('');
  const [testResult, setTestResult] = useState<any | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  const scooterCatalog = getScooterModels();

  const loadRules = async () => {
    setLoading(true);
    try {
      const { data, error } = await listShippingRules();
      if (error) {
        setFeedbackError(error);
      } else {
        setRules(data);
      }
    } catch (err: any) {
      setFeedbackError('Erro ao carregar regras de frete.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRules();
  }, []);

  const openCreateModal = () => {
    setEditingRule(null);
    setNomeRegiao('');
    setEstado('SP');
    setCidade('');
    setCepInicio('');
    setCepFim('');
    setValorFrete('150');
    setPrazoEstimado('3 a 6 dias úteis');
    setIsFreteGratis(false);
    setIsAtivo(true);
    setSelectedModels([]);
    setRestrictToModels(false);
    setIsModalOpen(true);
  };

  const openEditModal = (rule: ShippingRule) => {
    setEditingRule(rule);
    setNomeRegiao(rule.nome_regiao);
    setEstado(rule.estado);
    setCidade(rule.cidade || '');
    setCepInicio(maskCep(rule.cep_inicio));
    setCepFim(maskCep(rule.cep_fim));
    setValorFrete(String(rule.valor_frete));
    setPrazoEstimado(rule.prazo_estimado || '3 a 5 dias úteis');
    setIsFreteGratis(rule.frete_gratis || false);
    setIsAtivo(rule.ativo);
    if (rule.modelos_especificos && rule.modelos_especificos.length > 0) {
      setRestrictToModels(true);
      setSelectedModels(rule.modelos_especificos);
    } else {
      setRestrictToModels(false);
      setSelectedModels([]);
    }
    setIsModalOpen(true);
  };

  const handleSaveRule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nomeRegiao.trim()) {
      setFeedbackError('Informe o nome da região.');
      return;
    }
    const cleanCepIni = cepInicio.replace(/\D/g, '');
    const cleanCepFim = cepFim.replace(/\D/g, '');
    if (cleanCepIni.length !== 8 || cleanCepFim.length !== 8) {
      setFeedbackError('Os CEPs inicial e final devem conter 8 dígitos.');
      return;
    }
    if (parseInt(cleanCepIni, 10) > parseInt(cleanCepFim, 10)) {
      setFeedbackError('O CEP inicial não pode ser maior que o CEP final.');
      return;
    }

    setIsSaving(true);
    setFeedbackError(null);

    const payload = {
      nome_regiao: nomeRegiao.trim(),
      estado: estado.trim().toUpperCase(),
      cidade: cidade.trim() ? cidade.trim() : null,
      cep_inicio: maskCep(cleanCepIni),
      cep_fim: maskCep(cleanCepFim),
      valor_frete: isFreteGratis ? 0 : Math.max(0, Number(valorFrete) || 0),
      prazo_estimado: prazoEstimado.trim() || '3 a 5 dias úteis',
      ativo: isAtivo,
      frete_gratis: isFreteGratis,
      modelos_especificos: restrictToModels && selectedModels.length > 0 ? selectedModels : null
    };

    try {
      if (editingRule) {
        const { success, error } = await updateShippingRule(editingRule.id, payload);
        if (success) {
          setFeedbackSuccess(`Regra "${nomeRegiao}" atualizada com sucesso!`);
          setIsModalOpen(false);
          loadRules();
        } else {
          setFeedbackError(error || 'Falha ao atualizar regra.');
        }
      } else {
        const { data, error } = await createShippingRule(payload);
        if (data) {
          setFeedbackSuccess(`Nova regra de frete "${nomeRegiao}" cadastrada com sucesso!`);
          setIsModalOpen(false);
          loadRules();
        } else {
          setFeedbackError(error || 'Falha ao cadastrar regra.');
        }
      }
    } catch (err: any) {
      setFeedbackError(err.message || 'Erro inesperado.');
    } finally {
      setIsSaving(false);
      setTimeout(() => setFeedbackSuccess(null), 4000);
    }
  };

  const handleToggleActive = async (rule: ShippingRule) => {
    const newStatus = !rule.ativo;
    try {
      await toggleShippingRuleActive(rule.id, newStatus);
      setRules((prev) =>
        prev.map((r) => (r.id === rule.id ? { ...r, ativo: newStatus } : r))
      );
      setFeedbackSuccess(`Regra "${rule.nome_regiao}" ${newStatus ? 'ativada' : 'desativada'}.`);
      setTimeout(() => setFeedbackSuccess(null), 3000);
    } catch (err: any) {
      setFeedbackError('Falha ao alternar status da regra.');
    }
  };

  const handleDeleteRuleConfirmed = async () => {
    if (!ruleToDelete) return;
    setIsDeleting(true);
    try {
      const { success, error } = await deleteShippingRule(ruleToDelete.id);
      if (success) {
        setFeedbackSuccess(`Regra de frete "${ruleToDelete.nome_regiao}" excluída.`);
        setRuleToDelete(null);
        loadRules();
      } else {
        setFeedbackError(error || 'Falha ao excluir regra.');
      }
    } catch (err: any) {
      setFeedbackError('Erro ao excluir regra.');
    } finally {
      setIsDeleting(false);
      setTimeout(() => setFeedbackSuccess(null), 3000);
    }
  };

  const handleTestCep = async () => {
    const clean = testCep.replace(/\D/g, '');
    if (clean.length !== 8) {
      setTestResult({
        matched: false,
        message: 'Digite um CEP completo com 8 dígitos para testar.'
      });
      return;
    }
    setIsTesting(true);
    try {
      const result = await calculateShippingForCep(clean);
      setTestResult(result);
    } catch (e) {
      setTestResult({ matched: false, message: 'Erro ao calcular frete no teste.' });
    } finally {
      setIsTesting(false);
    }
  };

  // Filtros
  const uniqueEstados = Array.from(new Set(rules.map((r) => r.estado))).filter(Boolean).sort();

  const filteredRules = rules.filter((r) => {
    const matchSearch =
      r.nome_regiao.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.estado.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.cidade && r.cidade.toLowerCase().includes(searchTerm.toLowerCase())) ||
      r.cep_inicio.includes(searchTerm) ||
      r.cep_fim.includes(searchTerm);

    const matchEstado = selectedEstado === 'Todos' || r.estado === selectedEstado;

    return matchSearch && matchEstado;
  });

  const formatBRL = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  return (
    <div className="space-y-6">
      {/* Header da Seção de Frete */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-[#008f43] text-white flex items-center justify-center shadow-md">
            <Truck className="w-6 h-6 text-yellow-300" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              CONFIGURAÇÃO DE FRETE
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Gerencie regras de frete por faixas de CEP, cidades, estados, prazos e valores
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onBackToOrders && (
            <button
              onClick={onBackToOrders}
              className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs sm:text-sm font-bold transition-colors cursor-pointer"
            >
              ← Voltar aos Pedidos
            </button>
          )}

          <button
            onClick={openCreateModal}
            className="px-4 py-2.5 bg-gradient-to-r from-[#00a650] to-[#008f43] hover:from-[#008f43] hover:to-[#007335] text-white rounded-xl text-xs sm:text-sm font-black flex items-center gap-2 shadow-sm transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 text-yellow-300" />
            <span>NOVA REGRA DE FRETE</span>
          </button>
        </div>
      </div>

      {/* Alertas e Notificações */}
      {feedbackSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-800 text-xs sm:text-sm font-bold flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{feedbackSuccess}</span>
          </div>
          <button onClick={() => setFeedbackSuccess(null)} className="text-xs text-emerald-700 hover:underline">
            ✕
          </button>
        </div>
      )}

      {feedbackError && (
        <div className="p-3.5 bg-rose-50 border border-rose-300 rounded-xl text-rose-800 text-xs sm:text-sm font-bold flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{feedbackError}</span>
          </div>
          <button onClick={() => setFeedbackError(null)} className="text-xs text-rose-700 hover:underline">
            ✕
          </button>
        </div>
      )}

      {/* Simulador de Teste de CEP do Administrador */}
      <div className="bg-gradient-to-r from-emerald-50/80 to-stone-50 p-4 sm:p-5 rounded-2xl border border-emerald-200/80 shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calculator className="w-4 h-4 text-[#008f43]" />
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
              Simulador de Teste de Frete
            </h3>
          </div>
          <span className="text-[11px] text-slate-500 font-medium hidden sm:inline">
            Teste qualquer CEP para validar suas regras ativas
          </span>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
          <div className="relative flex-1 max-w-xs">
            <input
              type="text"
              value={testCep}
              onChange={(e) => setTestCep(maskCep(e.target.value))}
              placeholder="Digite um CEP (ex: 01310-100)"
              maxLength={9}
              className="w-full pl-3.5 pr-4 py-2 bg-white rounded-xl border border-slate-300 font-mono text-xs sm:text-sm outline-hidden focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20"
            />
          </div>

          <button
            type="button"
            onClick={handleTestCep}
            disabled={isTesting}
            className="px-4 py-2 bg-[#008f43] hover:bg-[#007335] text-white rounded-xl text-xs font-black transition-colors cursor-pointer"
          >
            {isTesting ? 'Calculando...' : 'Testar Frete'}
          </button>

          {testResult && (
            <div className={`flex-1 p-2.5 rounded-xl border text-xs flex items-center justify-between gap-3 ${
              testResult.matched 
                ? 'bg-emerald-100/70 border-emerald-300 text-emerald-900' 
                : 'bg-amber-100/70 border-amber-300 text-amber-900'
            }`}>
              {testResult.matched ? (
                <div>
                  <strong className="block font-black">
                    {testResult.nome_regiao}: {testResult.isFree ? 'Frete Grátis' : formatBRL(testResult.valor_frete)}
                  </strong>
                  <span className="text-[11px] text-emerald-800">
                    Prazo estimado: {testResult.prazo_estimado}
                  </span>
                </div>
              ) : (
                <div>
                  <strong className="block font-black">Sem regra para este CEP</strong>
                  <span className="text-[11px] text-amber-800">
                    {testResult.message || 'Precisamos consultar o frete para o seu endereço.'}
                  </span>
                </div>
              )}
              <button 
                onClick={() => setTestResult(null)} 
                className="text-xs font-bold opacity-60 hover:opacity-100"
              >
                ✕
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Barra de Filtros e Controles */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Campo de Busca */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por região, cidade, estado ou CEP..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-emerald-500/20 text-xs sm:text-sm outline-hidden"
            />
          </div>

          <div className="flex items-center gap-2">
            {/* Filtro de Estado */}
            <div className="flex items-center gap-1.5 text-xs text-slate-600 bg-slate-50 px-2.5 py-1.5 rounded-xl border border-slate-200">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-bold">UF:</span>
              <select
                value={selectedEstado}
                onChange={(e) => setSelectedEstado(e.target.value)}
                className="bg-transparent font-bold text-slate-800 outline-hidden cursor-pointer"
              >
                <option value="Todos">Todos</option>
                {uniqueEstados.map((uf) => (
                  <option key={uf} value={uf}>
                    {uf}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={loadRules}
              title="Recarregar regras"
              className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Lista de Regras Cadastradas */}
        {loading ? (
          <div className="py-12 text-center text-slate-500 space-y-2">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto text-[#00a650]" />
            <p className="text-xs font-bold">Carregando regras de frete...</p>
          </div>
        ) : filteredRules.length === 0 ? (
          <div className="py-12 text-center text-slate-500 space-y-3 bg-stone-50 rounded-xl border border-dashed border-slate-300">
            <Truck className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-sm font-bold text-slate-700">Nenhuma regra de frete encontrada.</p>
            <p className="text-xs text-slate-400">Clique em "Nova Regra de Frete" para cadastrar faixas de CEP e valores.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-stone-50 text-slate-600 font-extrabold uppercase text-[11px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3">Região / Local</th>
                  <th className="py-3 px-3">Faixa de CEP</th>
                  <th className="py-3 px-3">Valor do Frete</th>
                  <th className="py-3 px-3">Prazo Estimado</th>
                  <th className="py-3 px-3">Modelos</th>
                  <th className="py-3 px-3 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredRules.map((rule) => {
                  const isFree = rule.frete_gratis || Number(rule.valor_frete) === 0;

                  return (
                    <tr key={rule.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* Ativo / Inativo Toggle */}
                      <td className="py-3 px-3">
                        <button
                          type="button"
                          onClick={() => handleToggleActive(rule)}
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black cursor-pointer transition-colors ${
                            rule.ativo 
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border border-emerald-300' 
                              : 'bg-slate-200 text-slate-600 hover:bg-slate-300 border border-slate-300'
                          }`}
                          title={rule.ativo ? 'Clique para desativar' : 'Clique para ativar'}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${rule.ativo ? 'bg-emerald-600' : 'bg-slate-400'}`} />
                          <span>{rule.ativo ? 'Ativo' : 'Inativo'}</span>
                        </button>
                      </td>

                      {/* Região e Cidade */}
                      <td className="py-3 px-3">
                        <strong className="text-slate-900 block font-bold text-sm">
                          {rule.nome_regiao}
                        </strong>
                        <div className="flex items-center gap-1.5 text-slate-500 text-[11px] mt-0.5">
                          <span className="font-bold text-slate-700 bg-slate-100 px-1.5 py-0.2 rounded border border-slate-200">
                            {rule.estado}
                          </span>
                          {rule.cidade && <span>• {rule.cidade}</span>}
                        </div>
                      </td>

                      {/* Faixa de CEP */}
                      <td className="py-3 px-3 font-mono text-xs">
                        <div className="text-slate-800 font-semibold">
                          {rule.cep_inicio} <span className="text-slate-400">até</span> {rule.cep_fim}
                        </div>
                      </td>

                      {/* Valor do Frete */}
                      <td className="py-3 px-3">
                        {isFree ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-black bg-emerald-50 text-emerald-700 border border-emerald-200">
                            Grátis
                          </span>
                        ) : (
                          <span className="text-sm font-black text-[#008f43]">
                            {formatBRL(rule.valor_frete)}
                          </span>
                        )}
                      </td>

                      {/* Prazo */}
                      <td className="py-3 px-3 text-xs text-slate-600 font-medium">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>{rule.prazo_estimado || '3 a 5 dias úteis'}</span>
                        </div>
                      </td>

                      {/* Modelos Específicos */}
                      <td className="py-3 px-3 text-xs text-slate-500">
                        {rule.modelos_especificos && rule.modelos_especificos.length > 0 ? (
                          <span className="bg-amber-50 text-amber-900 px-2 py-0.5 rounded text-[11px] font-bold border border-amber-200">
                            {rule.modelos_especificos.length} modelo(s)
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px]">Todos os modelos</span>
                        )}
                      </td>

                      {/* Ações */}
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => openEditModal(rule)}
                            className="p-1.5 text-slate-500 hover:text-[#008f43] hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                            title="Editar Regra"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            onClick={() => setRuleToDelete(rule)}
                            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Excluir Regra"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* MODAL DE CRIAÇÃO / EDIÇÃO DE REGRA DE FRETE */}
      {/* ========================================================================= */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-xl w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-[#008f43] flex items-center justify-center font-black">
                  <Truck className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-black text-slate-900">
                  {editingRule ? 'Editar Regra de Frete' : 'Cadastrar Nova Regra de Frete'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveRule} className="space-y-4 text-xs sm:text-sm">
              {/* Nome da Região */}
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Nome da Região / Identificação *</label>
                <input
                  type="text"
                  required
                  value={nomeRegiao}
                  onChange={(e) => setNomeRegiao(e.target.value)}
                  placeholder="Ex: São Paulo - Capital ou Interior de SP"
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-medium outline-hidden focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20"
                />
              </div>

              {/* Estado e Cidade */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Estado (UF) *</label>
                  <input
                    type="text"
                    required
                    maxLength={2}
                    value={estado}
                    onChange={(e) => setEstado(e.target.value.toUpperCase().slice(0, 2))}
                    placeholder="SP"
                    className="w-full p-2.5 rounded-xl border border-slate-300 uppercase font-mono font-medium outline-hidden focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20"
                  />
                </div>

                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-slate-700">Cidade (opcional)</label>
                  <input
                    type="text"
                    value={cidade}
                    onChange={(e) => setCidade(e.target.value)}
                    placeholder="Deixe em branco para todo o estado"
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-medium outline-hidden focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20"
                  />
                </div>
              </div>

              {/* Faixa de CEP (Inicial e Final) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">CEP Inicial *</label>
                  <input
                    type="text"
                    required
                    maxLength={9}
                    value={cepInicio}
                    onChange={(e) => setCepInicio(maskCep(e.target.value))}
                    placeholder="01000-000"
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-medium outline-hidden focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">CEP Final *</label>
                  <input
                    type="text"
                    required
                    maxLength={9}
                    value={cepFim}
                    onChange={(e) => setCepFim(maskCep(e.target.value))}
                    placeholder="05999-999"
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-medium outline-hidden focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20"
                  />
                </div>
              </div>

              {/* Valor do Frete e Opção de Frete Grátis */}
              <div className="p-3.5 bg-stone-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800">Valor e Modalidade:</label>
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={isFreteGratis}
                      onChange={(e) => setIsFreteGratis(e.target.checked)}
                      className="w-4 h-4 text-[#00a650] rounded border-slate-300 focus:ring-[#00a650]"
                    />
                    <span className="text-xs font-black text-emerald-800 bg-emerald-100/80 px-2 py-0.5 rounded">
                      Frete Grátis
                    </span>
                  </label>
                </div>

                {!isFreteGratis ? (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-600">Valor do Frete (R$)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-bold">R$</span>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        required={!isFreteGratis}
                        value={valorFrete}
                        onChange={(e) => setValorFrete(e.target.value)}
                        placeholder="180.00"
                        className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-300 font-mono font-bold text-slate-900 outline-hidden focus:border-[#00a650]"
                      />
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-emerald-700 font-medium">
                    ✓ Esta regra concederá frete 100% gratuito para pedidos dentro desta faixa de CEP.
                  </p>
                )}
              </div>

              {/* Prazo Estimado */}
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Prazo Estimado de Entrega *</label>
                <input
                  type="text"
                  required
                  value={prazoEstimado}
                  onChange={(e) => setPrazoEstimado(e.target.value)}
                  placeholder="Ex: 3 a 5 dias úteis"
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-medium outline-hidden focus:border-[#00a650]"
                />
              </div>

              {/* Opção de Frete por Modelo de Scooter */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800 text-xs">Restringir a Modelos de Scooter?</label>
                  <label className="flex items-center gap-1.5 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={restrictToModels}
                      onChange={(e) => setRestrictToModels(e.target.checked)}
                      className="w-4 h-4 text-[#00a650] rounded border-slate-300 focus:ring-[#00a650]"
                    />
                    <span className="text-xs text-slate-600 font-medium">Sim, escolher modelos</span>
                  </label>
                </div>

                {restrictToModels && (
                  <div className="pt-2 border-t border-slate-200/80 space-y-1.5">
                    <span className="text-[11px] text-slate-500 block">
                      Selecione quais scooters recebem esta regra:
                    </span>
                    <div className="grid grid-cols-2 gap-1.5">
                      {scooterCatalog.map((m) => {
                        const isChecked = selectedModels.includes(m.id);
                        return (
                          <label 
                            key={m.id}
                            className={`p-2 rounded-lg border text-xs flex items-center gap-2 cursor-pointer transition-colors ${
                              isChecked ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold' : 'bg-white border-slate-200 text-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedModels([...selectedModels, m.id]);
                                } else {
                                  setSelectedModels(selectedModels.filter((id) => id !== m.id));
                                }
                              }}
                              className="w-3.5 h-3.5 text-[#00a650] rounded"
                            />
                            <span className="truncate">{m.name} ({m.power})</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Regra Ativa ou Inativa */}
              <div className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-xl">
                <div>
                  <span className="font-bold text-slate-900 block text-xs">Regra Ativa</span>
                  <span className="text-[11px] text-slate-500">Se desativada, não será aplicada no checkout</span>
                </div>
                <input
                  type="checkbox"
                  checked={isAtivo}
                  onChange={(e) => setIsAtivo(e.target.checked)}
                  className="w-5 h-5 text-[#00a650] rounded border-slate-300 focus:ring-[#00a650] cursor-pointer"
                />
              </div>

              {/* Botões do Modal */}
              <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="py-2.5 px-5 bg-gradient-to-r from-[#00a650] to-[#008f43] hover:from-[#008f43] hover:to-[#007335] text-white font-black rounded-xl text-xs transition-all shadow-sm cursor-pointer disabled:opacity-50"
                >
                  {isSaving ? 'Salvando...' : editingRule ? 'Salvar Alterações' : 'Cadastrar Regra'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DIÁLOGO DE CONFIRMAÇÃO DE EXCLUSÃO */}
      {/* ========================================================================= */}
      {ruleToDelete && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 sm:p-6 border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-xl bg-rose-100 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-black text-slate-900">Excluir Regra de Frete?</h4>
                <p className="text-xs text-slate-500">Esta ação removerá a regra do sistema.</p>
              </div>
            </div>

            <div className="p-3 bg-stone-50 rounded-xl border border-slate-200 text-xs text-slate-700 space-y-1">
              <div><strong>Região:</strong> {ruleToDelete.nome_regiao}</div>
              <div><strong>Faixa de CEP:</strong> {ruleToDelete.cep_inicio} até {ruleToDelete.cep_fim}</div>
              <div><strong>Valor:</strong> {ruleToDelete.frete_gratis ? 'Grátis' : formatBRL(ruleToDelete.valor_frete)}</div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setRuleToDelete(null)}
                className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleDeleteRuleConfirmed}
                disabled={isDeleting}
                className="py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white font-black rounded-xl text-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? 'Excluindo...' : 'Confirmar Exclusão'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
