import React, { useState } from 'react';
import { 
  X, 
  Check, 
  ShoppingBag, 
  ShieldCheck, 
  Truck, 
  Zap, 
  BatteryCharging, 
  Gauge, 
  Clock, 
  Scale, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { ScooterModel } from '../types';
import { useCart } from '../context/CartContext';
import { RainbowBar } from './RainbowBar';

interface ProductDetailModalProps {
  model: ScooterModel | null;
  allModels: ScooterModel[];
  onClose: () => void;
  onSelectModel: (model: ScooterModel) => void;
  onBuyNow?: (model: ScooterModel, color: string, quantity: number) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  model,
  allModels,
  onClose,
  onSelectModel,
  onBuyNow,
}) => {
  if (!model) return null;

  const { addToCart, setIsCartOpen } = useCart();
  const [selectedColor, setSelectedColor] = useState<string>(model.colors[0] || 'Vermelho');
  const [quantity, setQuantity] = useState<number>(1);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [addedToast, setAddedToast] = useState(false);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(val);
  };

  const installmentPrice = model.price / 12;

  const handleAddToCart = () => {
    if (onBuyNow) {
      onClose();
      onBuyNow(model, selectedColor, quantity);
      return;
    }

    const res = addToCart({
      id: model.id,
      name: model.name,
      price: model.price,
      power: model.power,
      image: model.image,
      color: selectedColor,
      estoque: model.estoque,
    }, quantity);

    if (res.success) {
      setAddedToast(true);
      setTimeout(() => {
        setAddedToast(false);
        onClose();
        setIsCartOpen(true);
      }, 700);
    }
  };

  const productFaqs = [
    {
      q: 'Preciso de CNH ou emplacamento para este modelo?',
      a: 'De acordo com a Resolução CONTRAN nº 996/2023, bicicletas elétricas com pedal assistido e potência de até 350W/500W com velocidade limitada a 32 km/h não exigem CNH ou emplacamento na grande maioria das vias urbanas e ciclovias.',
    },
    {
      q: 'Como é feita a recarga da bateria?',
      a: 'Basta plugar o carregador inteligente bivolt (110V/220V) diretamente em qualquer tomada comum residencial ou de trabalho. O carregador desliga automaticamente quando a bateria atinge 100%.',
    },
    {
      q: 'Qual é o custo aproximado de energia por recarga?',
      a: 'Uma recarga completa consome em média menos de 1 kWh, o que custa aproximadamente entre R$ 0,60 e R$ 0,90 na conta de luz, gerando um custo por quilômetro rodado inferior a R$ 0,03.',
    },
    {
      q: 'As peças e manutenção são fáceis de encontrar?',
      a: 'Sim! Por ser a rede oficial Vestcasa, você tem garantia de fábrica, disponibilidade de componentes de reposição (pastilhas, pneus, baterias) e suporte técnico especializado.',
    },
  ];

  const relatedModels = allModels.filter((m) => m.id !== model.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[95vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <RainbowBar height="h-[4px]" />

        {/* Header Modal */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-stone-50/70">
          <div className="flex items-center gap-2">
            <span className="bg-[#00a650] text-white text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full">
              {model.power}
            </span>
            {model.badge && (
              <span className="bg-amber-100 text-amber-900 border border-amber-200 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full">
                {model.badge}
              </span>
            )}
            <span className="text-xs font-bold text-slate-500 hidden sm:inline">
              Mobilidade Oficial Vestcasa
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-4 sm:p-8 space-y-8 flex-1">
          {/* Top Section: Gallery & Purchase Box */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 items-start">
            {/* Gallery Column */}
            <div className="space-y-4">
              <div className="relative aspect-4/3 bg-gradient-to-b from-stone-50 via-slate-100/40 to-white rounded-2xl border border-slate-200/80 p-6 flex items-center justify-center overflow-hidden">
                <img
                  src={model.image}
                  alt={model.name}
                  loading="lazy"
                  className="max-h-64 sm:max-h-72 w-auto object-contain drop-shadow-lg transition-transform duration-300 hover:scale-105"
                />
                <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-xs text-[10px] font-black text-slate-700 px-2.5 py-1 rounded-full border border-slate-200 shadow-2xs">
                  Foto Oficial • Cor selecionada: {selectedColor}
                </div>
              </div>

              {/* Color selector pills */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-2">
                  Escolha a Cor:
                </label>
                <div className="flex flex-wrap gap-2">
                  {model.colors.map((c) => {
                    const isSelected = selectedColor === c;
                    return (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setSelectedColor(c)}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-50 border-[#00a650] text-[#005c2d] shadow-2xs font-black'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span
                          className="w-3.5 h-3.5 rounded-full border border-slate-300"
                          style={{
                            backgroundColor:
                              c === 'Vermelho'
                                ? '#dc2626'
                                : c === 'Preto'
                                ? '#0f172a'
                                : '#ffffff',
                          }}
                        />
                        <span>{c}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#00a650]" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Quick Specs Icons */}
              <div className="grid grid-cols-3 gap-2 pt-2">
                <div className="bg-slate-50 p-3 rounded-xl text-center border border-slate-100">
                  <BatteryCharging className="w-4 h-4 text-[#00a650] mx-auto mb-1" />
                  <span className="text-[10px] text-slate-400 block font-medium">Autonomia</span>
                  <span className="text-xs font-bold text-slate-800">{model.autonomia || 'Até 40 km'}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl text-center border border-slate-100">
                  <Gauge className="w-4 h-4 text-[#00a650] mx-auto mb-1" />
                  <span className="text-[10px] text-slate-400 block font-medium">Velocidade</span>
                  <span className="text-xs font-bold text-slate-800">{model.velocidadeMaxima || 'Até 32 km/h'}</span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl text-center border border-slate-100">
                  <Clock className="w-4 h-4 text-[#00a650] mx-auto mb-1" />
                  <span className="text-[10px] text-slate-400 block font-medium">Recarga</span>
                  <span className="text-xs font-bold text-slate-800">{model.tempoCarga || '4 a 6 horas'}</span>
                </div>
              </div>
            </div>

            {/* Product Details & Purchase Controls */}
            <div className="space-y-5">
              <div>
                <span className="text-xs font-bold text-[#008f43] uppercase tracking-wider">
                  Scooter Elétrica • Linha Oficial
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-0.5">
                  Scooter Elétrica Vestcasa {model.name} {model.power}
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  {model.description}
                </p>
              </div>

              {/* Pricing Block */}
              <div className="p-4 bg-gradient-to-br from-emerald-50/80 to-stone-50 rounded-2xl border border-emerald-100/90 space-y-1">
                {model.oldPrice && (
                  <span className="text-xs text-slate-400 line-through block font-medium">
                    De {formatCurrency(model.oldPrice)}
                  </span>
                )}
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl sm:text-3xl font-black text-[#005c2d]">
                    {formatCurrency(model.price)}
                  </span>
                  <span className="text-xs font-black text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md">
                    À VISTA NO PIX
                  </span>
                </div>
                <p className="text-xs text-slate-600 font-medium pt-1">
                  ou em até <strong>12x de {formatCurrency(installmentPrice)}</strong> nos cartões sob consulta.
                </p>
              </div>

              {/* Key Features Bullets */}
              {model.features && model.features.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wide block">
                    Destaques do Modelo:
                  </span>
                  <ul className="space-y-1.5 text-xs text-slate-600">
                    {model.features.map((feat, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-[#00a650] shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Quantity selector & Add to Cart button */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-slate-700">Quantidade:</span>
                  <div className="flex items-center border border-slate-300 rounded-xl bg-white overflow-hidden shadow-2xs">
                    <button
                      type="button"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 font-bold transition-colors cursor-pointer"
                    >
                      -
                    </button>
                    <span className="px-3 py-1.5 text-xs font-black text-slate-900 min-w-8 text-center">
                      {quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 font-bold transition-colors cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Main High-Visibility Buy Button */}
                <button
                  type="button"
                  id="btn-modal-comprar-scooter"
                  onClick={handleAddToCart}
                  className="w-full py-4 px-6 bg-gradient-to-r from-[#00a650] to-[#008f43] hover:from-[#008f43] hover:to-[#007335] text-white font-black text-sm sm:text-base rounded-2xl shadow-lg hover:shadow-xl active:scale-[0.98] transition-all flex items-center justify-center gap-2.5 uppercase tracking-wide cursor-pointer"
                >
                  <ShoppingBag className="w-5 h-5 text-yellow-300" />
                  <span>
                    {addedToast
                      ? 'ADICIONADO AO CARRINHO!'
                      : `COMPRAR AGORA • ${formatCurrency(model.price * quantity)}`}
                  </span>
                </button>

                {/* Trust guarantees badge */}
                <div className="flex items-center justify-center gap-4 text-[11px] text-slate-500 pt-1">
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#00a650]" />
                    Garantia Oficial
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-[#00a650]" />
                    Retirada Imediata ou Envio
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Technical Specifications Table */}
          {model.specs && (
            <div className="pt-4 border-t border-slate-200/80">
              <h3 className="text-base font-black text-slate-900 uppercase tracking-wide mb-3 flex items-center gap-2">
                <Zap className="w-4 h-4 text-[#00a650]" />
                <span>Especificações Técnicas</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {Object.entries(model.specs).map(([key, value], idx) => (
                  <div
                    key={idx}
                    className="flex justify-between items-center p-3 bg-stone-50 rounded-xl border border-slate-100"
                  >
                    <span className="text-slate-500 font-medium">{key}:</span>
                    <span className="font-bold text-slate-800 text-right">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Product Specific FAQ */}
          <div className="pt-4 border-t border-slate-200/80 space-y-3">
            <h3 className="text-base font-black text-slate-900 uppercase tracking-wide flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-[#00a650]" />
              <span>Dúvidas Frequentes sobre a {model.name}</span>
            </h3>
            <div className="space-y-2">
              {productFaqs.map((faq, i) => {
                const isOpen = activeFaq === i;
                return (
                  <div
                    key={i}
                    className="border border-slate-200 rounded-xl overflow-hidden transition-colors"
                  >
                    <button
                      type="button"
                      onClick={() => setActiveFaq(isOpen ? null : i)}
                      className="w-full p-3.5 text-left text-xs sm:text-sm font-bold text-slate-800 flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer"
                    >
                      <span>{faq.q}</span>
                      {isOpen ? (
                        <ChevronUp className="w-4 h-4 text-[#00a650] shrink-0" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                    </button>
                    {isOpen && (
                      <div className="p-3.5 pt-0 text-xs text-slate-600 bg-white leading-relaxed animate-in fade-in">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Related Models */}
          <div className="pt-4 border-t border-slate-200/80">
            <h3 className="text-base font-black text-slate-900 uppercase tracking-wide mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Outros Modelos Disponíveis</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {relatedModels.map((rel) => (
                <div
                  key={rel.id}
                  onClick={() => onSelectModel(rel)}
                  className="p-3 bg-stone-50 hover:bg-white rounded-xl border border-slate-200 hover:border-[#00a650] transition-all cursor-pointer flex items-center gap-3 group"
                >
                  <img
                    src={rel.image}
                    alt={rel.name}
                    className="w-16 h-16 object-contain shrink-0 group-hover:scale-105 transition-transform"
                  />
                  <div className="overflow-hidden">
                    <span className="text-xs font-black text-slate-900 block truncate">
                      {rel.name} ({rel.power})
                    </span>
                    <span className="text-xs font-black text-[#008f43] block">
                      {formatCurrency(rel.price)}
                    </span>
                    <span className="text-[10px] text-slate-400 block">Ver Detalhes →</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
