import React, { useState, useEffect } from 'react';
import { 
  X, 
  ArrowRight, 
  ArrowLeft, 
  Check, 
  Copy, 
  ShieldCheck, 
  Lock, 
  User, 
  MapPin, 
  FileText, 
  QrCode, 
  CreditCard, 
  CheckCircle2, 
  AlertCircle, 
  Bike,
  Sparkles,
  MessageCircle,
  Truck,
  Store,
  Clock,
  Trash2,
  Plus,
  Minus,
  ShoppingCart,
  ShoppingBag,
  Tag,
  Percent,
  Banknote
} from 'lucide-react';
import { ScooterModel, Pedido, CartItem } from '../types';
import { RainbowBar } from './RainbowBar';
import { createOrder, reportPaymentDone } from '../services/orderService';
import { getScooterModels } from '../services/scooterService';
import { calculateShippingForCep, ShippingCalculationResult } from '../services/shippingService';
import { validateAndApplyCoupon, DEFAULT_COUPON_CODE } from '../services/couponService';

export interface CheckoutOrderItem {
  id: string;
  modelId: string;
  name: string;
  power: string;
  color: string;
  image: string;
  unitPrice: number;
  quantity: number;
  colors: string[];
  description?: string;
  estoque?: number;
}

export interface CheckoutScooterSelection {
  model: ScooterModel;
  color?: string;
  quantity?: number;
  price?: number;
  items?: CartItem[];
}

interface CheckoutModalProps {
  selection: CheckoutScooterSelection;
  onClose: () => void;
  onOrderCreated?: (order: Pedido) => void;
}

// Helpers de formatação e máscaras
export function formatCurrency(val: number): string {
  return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export function maskDocument(value: string): string {
  const digits = value.replace(/\D/g, '').slice(0, 14);
  if (digits.length <= 11) {
    return digits
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  } else {
    return digits
      .replace(/^(\d{2})(\d)/, '$1.$2')
      .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
      .replace(/\.(\d{3})(\d)/, '.$1/$2')
      .replace(/(\d{4})(\d)/, '$1-$2');
  }
}

export function maskCep(value: string): string {
  const digits = value.replace(/\D/g, '').slice(0, 8);
  return digits.replace(/(\d{5})(\d)/, '$1-$2');
}

export function maskPhone(value: string): string {
  const digits = value.replace(/\D/g, '').slice(0, 11);
  if (digits.length <= 10) {
    return digits
      .replace(/(\d{2})(\d)/, '($1) $2')
      .replace(/(\d{4})(\d)/, '$1-$2');
  }
  return digits
    .replace(/(\d{2})(\d)/, '($1) $2')
    .replace(/(\d{5})(\d)/, '$1-$2');
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  selection,
  onClose,
  onOrderCreated
}) => {
  // Passos: 1 = Escolha da Scooter, 2 = Dados do Cliente, 3 = Resumo do Pedido, 4 = Pagamento
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // STEP 1: Itens do Pedido com suporte a múltiplos itens, adicionar e remover
  const [orderItems, setOrderItems] = useState<CheckoutOrderItem[]>(() => {
    if (selection.items && selection.items.length > 0) {
      return selection.items.map((it, idx) => ({
        id: it.id || `item-${Date.now()}-${idx}`,
        modelId: it.id_produto,
        name: it.nome_produto,
        power: it.potencia || '1000W',
        color: it.cor || 'Vermelho',
        image: it.imagem || selection.model.image,
        unitPrice: it.preco_unitario,
        quantity: it.quantidade || 1,
        colors: selection.model.colors || ['Vermelho', 'Preto', 'Branco'],
        description: it.nome_produto,
        estoque: it.estoque
      }));
    }
    return [
      {
        id: `item-${Date.now()}-0`,
        modelId: selection.model.id,
        name: selection.model.name,
        power: selection.model.power,
        color: selection.color || selection.model.colors[0] || 'Vermelho',
        image: selection.model.image,
        unitPrice: selection.price || selection.model.price,
        quantity: selection.quantity || 1,
        colors: selection.model.colors || ['Vermelho', 'Preto', 'Branco'],
        description: selection.model.description,
        estoque: selection.model.estoque
      }
    ];
  });

  // Catálogo completo de scooters disponíveis para adicionar
  const catalogModels = getScooterModels();
  const [showAddCatalog, setShowAddCatalog] = useState(false);
  const [selectedAddColors, setSelectedAddColors] = useState<Record<string, string>>({});
  const [itemAddedToast, setItemAddedToast] = useState<string | null>(null);

  const tipoRecebimento = 'entrega';
  const [cepConsultado, setCepConsultado] = useState(false);

  // STEP 2: Dados do Cliente
  const [nome, setNome] = useState('');
  const [cpfCnpj, setCpfCnpj] = useState('');
  const [cep, setCep] = useState('');
  const [endereco, setEndereco] = useState('');
  const [numero, setNumero] = useState('');
  const [complemento, setComplemento] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [estado, setEstado] = useState('');
  const [telefone, setTelefone] = useState('');
  const [confirmChecked, setConfirmChecked] = useState(false);

  // Estados de CEP e validação
  const [isSearchingCep, setIsSearchingCep] = useState(false);
  const [cepFeedback, setCepFeedback] = useState<string | null>(null);
  const [step2Errors, setStep2Errors] = useState<Record<string, string>>({});
  const [attemptedStep2, setAttemptedStep2] = useState(false);

  // Estados de Cálculo de Frete
  const [shippingResult, setShippingResult] = useState<ShippingCalculationResult | null>(null);
  const [isCalculatingShipping, setIsCalculatingShipping] = useState(false);

  // Estados de Cupom de Desconto
  const [cupomInput, setCupomInput] = useState('');
  const [cupomAplicado, setCupomAplicado] = useState<{
    codigo: string;
    porcentagem: number;
    valorDesconto: number;
  } | null>(null);
  const [isApplyingCupom, setIsApplyingCupom] = useState(false);
  const [cupomFeedback, setCupomFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  // STEP 3 & 4: Pedido Criado
  const [createdOrder, setCreatedOrder] = useState<Pedido | null>(null);
  const [isCreatingOrder, setIsCreatingOrder] = useState(false);

  // STEP 4: Pagamento
  const [paymentTab, setPaymentTab] = useState<'pix' | 'cartao'>('pix');
  const [isReportingPayment, setIsReportingPayment] = useState(false);
  const [reportedPaymentSuccess, setReportedPaymentSuccess] = useState(false);

  // Manipulação de itens: Adicionar, Quantidade, Remover e Cor
  const handleAddItem = (model: ScooterModel) => {
    const chosenColor = selectedAddColors[model.id] || model.colors[0] || 'Vermelho';

    const existingIndex = orderItems.findIndex(
      (item) => item.modelId === model.id && item.color.toLowerCase() === chosenColor.toLowerCase()
    );

    if (existingIndex >= 0) {
      setOrderItems((prev) =>
        prev.map((item, idx) =>
          idx === existingIndex ? { ...item, quantity: item.quantity + 1 } : item
        )
      );
    } else {
      const newItem: CheckoutOrderItem = {
        id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        modelId: model.id,
        name: model.name,
        power: model.power,
        color: chosenColor,
        image: model.image,
        unitPrice: model.price,
        quantity: 1,
        colors: model.colors || ['Vermelho', 'Preto', 'Branco'],
        description: model.description,
        estoque: model.estoque
      };
      setOrderItems((prev) => [...prev, newItem]);
    }

    setItemAddedToast(`Scooter ${model.name} (${chosenColor}) adicionada com sucesso!`);
    setTimeout(() => setItemAddedToast(null), 3500);
  };

  const handleUpdateItemQuantity = (id: string, delta: number) => {
    setOrderItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CheckoutOrderItem[]
    );
  };

  const handleRemoveItem = (id: string) => {
    setOrderItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleItemColorChange = (id: string, newColor: string) => {
    setOrderItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, color: newColor } : item))
    );
  };

  // Valor total dos produtos e quantidade total calculados em tempo real
  const totalAmount = orderItems.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
  const totalQuantity = orderItems.reduce((acc, item) => acc + item.quantity, 0);

  // Função central de cálculo de frete por CEP
  const calculateShipping = async (cleanCepTarget: string, targetCidade?: string, targetEstado?: string) => {
    if (cleanCepTarget.length !== 8) {
      setShippingResult(null);
      return;
    }
    setIsCalculatingShipping(true);
    try {
      const res = await calculateShippingForCep(cleanCepTarget, {
        modelIds: orderItems.map((it) => it.modelId),
        cidade: targetCidade || cidade,
        estado: targetEstado || estado
      });
      setShippingResult(res);
    } catch (err) {
      console.warn('Erro ao calcular frete:', err);
    } finally {
      setIsCalculatingShipping(false);
    }
  };

  // Recalcula frete se itens ou modalidade mudarem
  useEffect(() => {
    const clean = cep.replace(/\D/g, '');
    if (clean.length === 8) {
      calculateShipping(clean, cidade, estado);
    }
  }, [totalQuantity, tipoRecebimento, orderItems]);

  // Autoconsulta de CEP ao digitar 8 dígitos e cálculo imediato de frete e disponibilidade
  const handleCepChange = async (val: string) => {
    const masked = maskCep(val);
    setCep(masked);
    const clean = masked.replace(/\D/g, '');

    if (clean.length === 8) {
      setIsSearchingCep(true);
      setCepFeedback(null);
      let foundCidade = cidade;
      let foundEstado = estado;

      try {
        const res = await fetch(`https://viacep.com.br/ws/${clean}/json/`);
        const data = await res.json();
        if (data.erro) {
          setCepFeedback('CEP não encontrado na base dos Correios. Digite o endereço manualmente.');
          setCepConsultado(true);
        } else {
          setEndereco(data.logradouro || '');
          setBairro(data.bairro || '');
          setCidade(data.localidade || '');
          setEstado(data.uf || '');
          foundCidade = data.localidade || '';
          foundEstado = data.uf || '';
          setCepFeedback('Endereço preenchido automaticamente!');
          setCepConsultado(true);
          setTimeout(() => setCepFeedback(null), 4000);
        }
      } catch (err) {
        setCepFeedback('Não foi possível buscar o CEP automaticamente. Digite o endereço manualmente.');
        setCepConsultado(true);
      } finally {
        setIsSearchingCep(false);
        // Sempre calcula o frete com os dados identificados para qualquer CEP consultado
        calculateShipping(clean, foundCidade, foundEstado);
      }
    } else {
      setCepConsultado(false);
      setShippingResult(null);
    }
  };

  // Valor de frete calculado
  const valorFreteCalculado = shippingResult?.matched
    ? (shippingResult.isFree ? 0 : shippingResult.valor_frete)
    : 0;

  // Valor do desconto recalculado dinamicamente SOMENTE sobre o subtotal dos produtos (scooters)
  const valorDesconto = cupomAplicado
    ? Math.round((totalAmount * (cupomAplicado.porcentagem / 100)) * 100) / 100
    : 0;
  const totalProdutosComDesconto = Math.max(0, totalAmount - valorDesconto);

  // Fórmula solicitada: Total = (Valor do Produto - Desconto do Cupom) + Frete
  const finalOrderTotal = totalProdutosComDesconto + valorFreteCalculado;

  const WHATSAPP_AVISTA_URL = 'https://wa.me/5511971583047?text=Olá%21%20Estou%20finalizando%20meu%20pedido%20pelo%20site%20Vestcasa%20Scooters%20e%20gostaria%20de%20informar%20que%20vou%20realizar%20o%20pagamento%20à%20vista.';

  const handleInformarPagamentoWhatsApp = async () => {
    if (createdOrder) {
      try {
        await reportPaymentDone(createdOrder.id, {
          method: 'PIX à Vista',
          detailsText: 'Cliente informou pagamento à vista via WhatsApp'
        });
        setReportedPaymentSuccess(true);
      } catch (err) {
        setReportedPaymentSuccess(true);
      }
    }
  };

  // 💳 CARTÃO DE CRÉDITO — SIMULAÇÃO DE PARCELAS (1x até 12x sem juros)
  const [selectedInstallments, setSelectedInstallments] = useState<number>(12);
  const valorParcelaSimulada = Math.round((finalOrderTotal / (selectedInstallments || 1)) * 100) / 100;

  const handleRequestCreditCardLink = () => {
    const codigoPedido = createdOrder?.codigo || (createdOrder as any)?.id || 'PENDENTE';
    const msg = `Olá! Quero finalizar meu pedido no cartão de crédito.

Código do pedido: ${codigoPedido}
Valor total: ${formatCurrency(finalOrderTotal)}
Parcelamento escolhido: ${selectedInstallments}x de ${formatCurrency(valorParcelaSimulada)}

Gostaria de receber o link de pagamento.`;
    const whatsappUrl = `https://wa.me/5511971583047?text=${encodeURIComponent(msg)}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  // Atualiza dinamicamente o valor do desconto se a quantidade de produtos mudar
  useEffect(() => {
    if (cupomAplicado) {
      const recalculatedDiscount = Math.round((totalAmount * (cupomAplicado.porcentagem / 100)) * 100) / 100;
      setCupomAplicado(prev => prev ? { ...prev, valorDesconto: recalculatedDiscount } : null);
    }
  }, [totalAmount]);

  // Função para validar e aplicar o cupom
  const handleApplyCoupon = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanCode = cupomInput.trim();
    if (!cleanCode) {
      setCupomFeedback({
        type: 'error',
        message: 'Por favor, digite seu código de cupom.'
      });
      return;
    }

    setIsApplyingCupom(true);
    setCupomFeedback(null);

    try {
      // Validação segura com a regra do ADM (banco de dados/service)
      const res = await validateAndApplyCoupon(cleanCode, totalAmount);
      if (res.valid && res.codigo && res.porcentagem !== undefined) {
        setCupomAplicado({
          codigo: res.codigo,
          porcentagem: res.porcentagem,
          valorDesconto: res.valorDesconto
        });
        setCupomFeedback({
          type: 'success',
          message: `Cupom ${res.codigo} aplicado! ${res.porcentagem}% de desconto sobre as scooters.`
        });
      } else {
        setCupomFeedback({
          type: 'error',
          message: res.message || 'Cupom inválido ou inativo.'
        });
      }
    } catch (err) {
      setCupomFeedback({
        type: 'error',
        message: 'Erro ao validar cupom. Tente novamente.'
      });
    } finally {
      setIsApplyingCupom(false);
    }
  };

  const handleRemoveCoupon = () => {
    setCupomAplicado(null);
    setCupomInput('');
    setCupomFeedback(null);
  };

  // Validação do Step 2
  const validateStep2 = (): boolean => {
    const errors: Record<string, string> = {};
    const cleanDoc = cpfCnpj.replace(/\D/g, '');
    const cleanCep = cep.replace(/\D/g, '');

    if (!nome.trim() || nome.trim().length < 3) {
      errors.nome = 'Informe seu nome completo';
    }
    if (!cleanDoc || (cleanDoc.length !== 11 && cleanDoc.length !== 14)) {
      errors.cpfCnpj = 'Informe um CPF (11 dígitos) ou CNPJ (14 dígitos) válido';
    }
    if (!cleanCep || cleanCep.length !== 8) {
      errors.cep = 'Informe um CEP válido com 8 dígitos';
    }
    if (!endereco.trim()) {
      errors.endereco = 'Informe o logradouro / endereço';
    }
    if (!numero.trim()) {
      errors.numero = 'Informe o número';
    }
    if (!bairro.trim()) {
      errors.bairro = 'Informe o bairro';
    }
    if (!cidade.trim()) {
      errors.cidade = 'Informe a cidade';
    }
    if (!estado.trim()) {
      errors.estado = 'Informe o estado (UF)';
    }
    if (!confirmChecked) {
      errors.confirm = 'Você precisa confirmar que os dados informados estão corretos.';
    }

    setStep2Errors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleGoToStep3 = () => {
    setAttemptedStep2(true);
    if (validateStep2()) {
      setStep(3);
    }
  };

  // Ao clicar em "IR PARA PAGAMENTO", registra o pedido e avança para Step 4
  const handleProceedToPayment = async () => {
    if (orderItems.length === 0) {
      setStep(1);
      return;
    }
    setIsCreatingOrder(true);
    try {
      const randomCode = Math.floor(1000 + Math.random() * 9000);
      const firstItem = orderItems[0];
      const codigoGerado = `VEST-${firstItem.modelId.toUpperCase().slice(0, 4)}-${randomCode}`;

      const enderecoCompleto = `${endereco}, Nº ${numero}${complemento ? ` (${complemento})` : ''} - ${bairro}, ${cidade}/${estado} - CEP: ${cep}`;
      
      const produtoDescricao = orderItems.length === 1
        ? `${orderItems[0].name} (${orderItems[0].power}) - Cor: ${orderItems[0].color}${orderItems[0].quantity > 1 ? ` x${orderItems[0].quantity}` : ''}`
        : orderItems.map((it) => `${it.name} (${it.power}, ${it.color}) x${it.quantity}`).join(' + ');

      const itensPayload: CartItem[] = orderItems.map((item) => ({
        id: item.id,
        id_produto: item.modelId,
        nome_produto: item.name,
        preco_unitario: item.unitPrice,
        quantidade: item.quantity,
        subtotal: item.unitPrice * item.quantity,
        cor: item.color,
        potencia: item.power,
        imagem: item.image,
        estoque: item.estoque
      }));

      const res = await createOrder({
        codigo: codigoGerado,
        nome_cliente: nome.trim(),
        cpf: cpfCnpj.trim(),
        produto: produtoDescricao,
        cor: orderItems.map((it) => it.color).join(', '),
        valor: finalOrderTotal,
        status_pagamento: 'Pendente',
        imagem_url: firstItem.image,
        observacao: `Cliente: ${nome.trim()} | Doc: ${cpfCnpj.trim()} | Entrega: Entrega em Domicílio | Endereço: ${enderecoCompleto}${telefone ? ` | Tel: ${telefone}` : ''} | Frete: ${valorFreteCalculado > 0 ? formatCurrency(valorFreteCalculado) : 'Grátis'}${shippingResult?.nome_regiao ? ` (${shippingResult.nome_regiao})` : ''}${cupomAplicado ? ` | Cupom: ${cupomAplicado.codigo} (-${cupomAplicado.porcentagem}% = -${formatCurrency(valorDesconto)})` : ''} | Itens: ${produtoDescricao}`,
        frete: valorFreteCalculado === 0 ? 'sem_frete' : 'com_frete',
        itens: itensPayload,
        telefone: telefone.trim() || undefined,
        cep: cep.trim(),
        endereco: endereco.trim(),
        numero: numero.trim(),
        complemento: complemento.trim() || undefined,
        bairro: bairro.trim(),
        cidade: cidade.trim(),
        estado: estado.trim().toUpperCase(),
        valor_produto: totalAmount,
        valor_desconto: valorDesconto,
        valor_frete: valorFreteCalculado,
        valor_total: finalOrderTotal,
        cupom_codigo: cupomAplicado ? cupomAplicado.codigo : undefined,
        cupom_porcentagem: cupomAplicado ? cupomAplicado.porcentagem : undefined,
        forma_pagamento: paymentTab === 'pix' ? 'PIX' : 'Cartão',
        prazo_frete: shippingResult?.prazo_estimado,
        nome_regiao_frete: shippingResult?.nome_regiao,
        tipo_entrega: 'entrega'
      });

      if (res.data) {
        setCreatedOrder(res.data);
        if (onOrderCreated) onOrderCreated(res.data);
      } else {
        // Fallback local caso haja falha
        const fallbackOrder: Pedido = {
          id: `local-${Date.now()}`,
          codigo: codigoGerado,
          nome_cliente: nome.trim(),
          cpf: cpfCnpj.trim(),
          produto: produtoDescricao,
          cor: orderItems.map((it) => it.color).join(', '),
          valor: finalOrderTotal,
          valor_produto: totalAmount,
          valor_desconto: valorDesconto,
          valor_frete: valorFreteCalculado,
          valor_total: finalOrderTotal,
          cupom_codigo: cupomAplicado ? cupomAplicado.codigo : undefined,
          cupom_porcentagem: cupomAplicado ? cupomAplicado.porcentagem : undefined,
          telefone: telefone.trim(),
          cep: cep.trim(),
          endereco: endereco.trim(),
          numero: numero.trim(),
          bairro: bairro.trim(),
          cidade: cidade.trim(),
          estado: estado.trim(),
          status_pagamento: 'Pendente',
          imagem_url: firstItem.image,
          observacao: enderecoCompleto,
          created_at: new Date().toISOString()
        };
        setCreatedOrder(fallbackOrder);
      }
      setStep(4);
    } catch (e) {
      setStep(4);
    } finally {
      setIsCreatingOrder(false);
    }
  };

  const handleNotifyPayment = async () => {
    if (!createdOrder) return;
    setIsReportingPayment(true);
    try {
      await reportPaymentDone(createdOrder.id, {
        method: paymentTab === 'pix' ? 'PIX à Vista' : 'Cartão de Crédito',
        detailsText: 'Cliente informou pagamento no checkout'
      });
      setReportedPaymentSuccess(true);
    } catch (err) {
      setReportedPaymentSuccess(true);
    } finally {
      setIsReportingPayment(false);
    }
  };

  const handleFinalizeWhatsApp = async () => {
    const orderCode = createdOrder?.codigo || `VEST-${Math.floor(1000 + Math.random() * 9000)}`;
    const formaPagamentoTexto = paymentTab === 'pix' 
      ? 'PIX à Vista' 
      : `Cartão de Crédito (${selectedInstallments}x de ${formatCurrency(valorParcelaSimulada)} sem juros)`;
    const tipoRecebimentoTexto = 'Entrega em Domicílio';

    let msg = `🛵 *NOVO PEDIDO VESTCASA - PAGAMENTO REALIZADO*\n`;
    msg += `Olá, equipe Vestcasa! Acabei de realizar o pagamento do meu pedido e quero finalizar a confirmação.\n\n`;

    msg += `📋 *CÓDIGO DO PEDIDO:* ${orderCode}\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `👤 *CLIENTE:* ${nome.trim()}\n`;
    msg += `📄 *CPF/CNPJ:* ${cpfCnpj.trim()}\n`;
    if (telefone.trim()) {
      msg += `📱 *Telefone/WhatsApp:* ${telefone.trim()}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━━\n`;

    if (orderItems.length > 1) {
      msg += `🛒 *ITENS DO PEDIDO (${totalQuantity} UNIDADES):*\n`;
      orderItems.forEach((item, idx) => {
        msg += `   ${idx + 1}. *${item.name}* (${item.power}) - Cor: ${item.color} - ${item.quantity}x de ${formatCurrency(item.unitPrice)} = ${formatCurrency(item.unitPrice * item.quantity)}\n`;
      });
    } else if (orderItems.length === 1) {
      const single = orderItems[0];
      msg += `🛵 *PRODUTO:* ${single.name} (${single.power})\n`;
      msg += `🎨 *Cor Escolhida:* ${single.color}\n`;
      msg += `📦 *Quantidade:* ${single.quantity} unidade(s)\n`;
      msg += `💵 *Valor Unitário:* ${formatCurrency(single.unitPrice)}\n`;
    }

    msg += `🛵 *SUBTOTAL SCOOTER(S):* ${formatCurrency(totalAmount)}\n`;
    msg += `🚚 *VALOR DO FRETE:* ${valorFreteCalculado > 0 ? formatCurrency(valorFreteCalculado) : 'Grátis'}${shippingResult?.nome_regiao ? ` (${shippingResult.nome_regiao})` : ''}\n`;
    if (shippingResult?.prazo_estimado) {
      msg += `⏱️ *Prazo Estimado:* ${shippingResult.prazo_estimado}\n`;
    }
    msg += `💰 *VALOR TOTAL DO PEDIDO:* ${formatCurrency(finalOrderTotal)}\n`;
    msg += `💳 *FORMA DE PAGAMENTO:* ${formaPagamentoTexto}\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `📍 *Modalidade:* ${tipoRecebimentoTexto}\n`;
    msg += `🏠 *Endereço de Entrega:*\n`;
    msg += `   ${endereco.trim()}, Nº ${numero.trim()}${complemento.trim() ? ` (${complemento.trim()})` : ''}\n`;
    msg += `   Bairro: ${bairro.trim()}\n`;
    msg += `   Cidade: ${cidade.trim()} - ${estado.trim().toUpperCase()}\n`;
    msg += `   CEP: ${cep.trim()}\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `Envio o comprovante para conferência e liberação. Aguardo a confirmação!`;

    // Atualiza status no banco/localStorage
    if (createdOrder) {
      try {
        await reportPaymentDone(createdOrder.id, {
          method: formaPagamentoTexto,
          detailsText: 'Cliente finalizou pelo WhatsApp com comprovante'
        });
        setReportedPaymentSuccess(true);
      } catch (err) {
        setReportedPaymentSuccess(true);
      }
    }

    const encoded = encodeURIComponent(msg);
    const whatsappUrl = `https://wa.me/5511971583047?text=${encoded}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Barra superior de identidade Vestcasa */}
        <RainbowBar height="h-[4px]" />

        {/* Header do Checkout com Passos */}
        <div className="p-4 sm:p-5 border-b border-slate-100 bg-stone-50/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#005c2d] text-[#ffd000] flex items-center justify-center shadow-xs">
              <Bike className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-900 uppercase tracking-tight">
                  Checkout Seguro
                </h2>
                <span className="bg-[#00a650] text-white text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-2xs">
                  Passo {step} de 4
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {step === 1 && '1. Escolha da Scooter'}
                {step === 2 && '2. Dados do Cliente e Endereço'}
                {step === 3 && '3. Resumo do Pedido'}
                {step === 4 && '4. Pagamento Seguro'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-xl transition-colors cursor-pointer"
            title="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Indicador Visual dos Passos */}
        <div className="px-5 py-2.5 bg-slate-100/70 border-b border-slate-200/60 flex items-center justify-between text-xs font-bold text-slate-600">
          <div className={`flex items-center gap-1.5 ${step >= 1 ? 'text-[#008f43] font-black' : 'text-slate-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step >= 1 ? 'bg-[#008f43] text-white' : 'bg-slate-300 text-slate-600'}`}>
              1
            </span>
            <span className="hidden sm:inline">Scooter</span>
          </div>
          <div className="w-6 sm:w-10 h-0.5 bg-slate-200" />
          <div className={`flex items-center gap-1.5 ${step >= 2 ? 'text-[#008f43] font-black' : 'text-slate-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step >= 2 ? 'bg-[#008f43] text-white' : 'bg-slate-300 text-slate-600'}`}>
              2
            </span>
            <span className="hidden sm:inline">Dados</span>
          </div>
          <div className="w-6 sm:w-10 h-0.5 bg-slate-200" />
          <div className={`flex items-center gap-1.5 ${step >= 3 ? 'text-[#008f43] font-black' : 'text-slate-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step >= 3 ? 'bg-[#008f43] text-white' : 'bg-slate-300 text-slate-600'}`}>
              3
            </span>
            <span className="hidden sm:inline">Resumo</span>
          </div>
          <div className="w-6 sm:w-10 h-0.5 bg-slate-200" />
          <div className={`flex items-center gap-1.5 ${step >= 4 ? 'text-[#008f43] font-black' : 'text-slate-400'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step >= 4 ? 'bg-[#008f43] text-white' : 'bg-slate-300 text-slate-600'}`}>
              4
            </span>
            <span className="hidden sm:inline">Pagamento</span>
          </div>
        </div>

        {/* Conteúdo rolável de cada passo */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          
          {/* ========================================================================= */}
          {/* PASSO 1: ESCOLHA DA SCOOTER E ITENS DO PEDIDO */}
          {/* ========================================================================= */}
          {step === 1 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              {/* Feedback toast de item adicionado */}
              {itemAddedToast && (
                <div className="p-3 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center justify-between shadow-md animate-in slide-in-from-top duration-200">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-yellow-300 shrink-0" />
                    <span>{itemAddedToast}</span>
                  </div>
                  <button 
                    type="button" 
                    onClick={() => setItemAddedToast(null)}
                    className="text-white/80 hover:text-white text-xs font-bold"
                  >
                    ✕
                  </button>
                </div>
              )}

              {/* Cabeçalho da Lista de Itens */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-extrabold uppercase text-[#008f43] tracking-wider block">
                    Itens Selecionados
                  </span>
                  <h3 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                    {orderItems.length === 1 ? 'Sua Scooter Selecionada' : `Scooters no Pedido (${totalQuantity} unid)`}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAddCatalog(!showAddCatalog)}
                  className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-[#005c2d] border border-emerald-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{showAddCatalog ? 'Fechar Catálogo' : '+ Adicionar Mais'}</span>
                </button>
              </div>

              {/* Lista de Itens no Pedido */}
              {orderItems.length === 0 ? (
                <div className="p-6 bg-stone-50 border-2 border-dashed border-slate-300 rounded-2xl text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-slate-200 text-slate-500 flex items-center justify-center mx-auto">
                    <ShoppingCart className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-slate-800 text-sm">Seu pedido está vazio</h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Você removeu os itens. Escolha pelo menos um modelo de scooter no catálogo abaixo para continuar:
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {orderItems.map((item, index) => {
                    const availableColors = item.colors && item.colors.length > 0 
                      ? item.colors 
                      : ['Vermelho', 'Preto', 'Branco'];

                    return (
                      <div 
                        key={item.id}
                        className="bg-stone-50 rounded-2xl p-4 border border-slate-200 space-y-3 shadow-2xs transition-all hover:border-emerald-300"
                      >
                        <div className="flex flex-col sm:flex-row items-center gap-4">
                          {/* Imagem */}
                          <div className="w-24 h-24 sm:w-28 sm:h-28 bg-white rounded-xl border border-slate-200 p-2 flex items-center justify-center shrink-0">
                            <img
                              src={item.image}
                              alt={item.name}
                              referrerPolicy="no-referrer"
                              className="max-h-full max-w-full object-contain filter drop-shadow-xs"
                            />
                          </div>

                          {/* Dados do item */}
                          <div className="flex-1 text-center sm:text-left space-y-1 w-full">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                              <div>
                                <span className="text-[10px] font-extrabold uppercase text-[#008f43] tracking-wider">
                                  Item #{index + 1}
                                </span>
                                <h4 className="text-base sm:text-lg font-black text-slate-900">
                                  {item.name} {item.power}
                                </h4>
                              </div>
                              <div className="text-center sm:text-right">
                                <span className="text-xs text-slate-500 block">Subtotal</span>
                                <span className="text-base sm:text-lg font-black text-[#008f43]">
                                  {formatCurrency(item.unitPrice * item.quantity)}
                                </span>
                              </div>
                            </div>

                            <p className="text-[11px] text-slate-500">
                              Unitário: {formatCurrency(item.unitPrice)} à vista
                            </p>

                            {/* Seletor de Cores deste item */}
                            <div className="pt-2 flex flex-wrap items-center justify-center sm:justify-start gap-1.5">
                              <span className="text-[11px] font-bold text-slate-600 mr-1">Cor:</span>
                              {availableColors.map((color) => {
                                const isSelected = item.color.toLowerCase() === color.toLowerCase();
                                return (
                                  <button
                                    key={color}
                                    type="button"
                                    onClick={() => handleItemColorChange(item.id, color)}
                                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                                      isSelected
                                        ? 'bg-[#005c2d] text-white shadow-2xs ring-1 ring-[#00a650]'
                                        : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
                                    }`}
                                  >
                                    <span 
                                      className="w-2.5 h-2.5 rounded-full border border-white/60"
                                      style={{
                                        backgroundColor: 
                                          color.toLowerCase().includes('verm') ? '#dc2626' :
                                          color.toLowerCase().includes('pret') ? '#1e293b' :
                                          color.toLowerCase().includes('bran') ? '#f8fafc' :
                                          color.toLowerCase().includes('azul') ? '#2563eb' :
                                          color.toLowerCase().includes('amare') ? '#eab308' :
                                          color.toLowerCase().includes('cinz') || color.toLowerCase().includes('graf') ? '#64748b' : '#10b981'
                                      }}
                                    />
                                    <span>{color}</span>
                                    {isSelected && <Check className="w-3 h-3 text-[#ffd000]" />}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>

                        {/* Barra inferior do item: Controle de Quantidade e Exclusão */}
                        <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="text-xs font-bold text-rose-600 hover:text-rose-800 hover:bg-rose-50 px-2.5 py-1.5 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Remover item</span>
                          </button>

                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-600">Qtd:</span>
                            <div className="flex items-center border border-slate-300 rounded-xl overflow-hidden bg-white shadow-2xs">
                              <button
                                type="button"
                                onClick={() => handleUpdateItemQuantity(item.id, -1)}
                                className="px-2.5 py-1 text-slate-600 hover:bg-slate-100 font-bold transition-colors cursor-pointer text-sm"
                                title="Diminuir quantidade"
                              >
                                -
                              </button>
                              <span className="px-3 py-1 text-xs font-black text-slate-900 min-w-7 text-center">
                                {item.quantity}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleUpdateItemQuantity(item.id, 1)}
                                className="px-2.5 py-1 text-slate-600 hover:bg-slate-100 font-bold transition-colors cursor-pointer text-sm"
                                title="Aumentar quantidade"
                              >
                                +
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Botão para Expandir Catálogo de Scooters adicionais */}
              <button
                type="button"
                onClick={() => setShowAddCatalog(!showAddCatalog)}
                className="w-full py-3 px-4 bg-emerald-50 hover:bg-emerald-100/80 border-2 border-dashed border-[#00a650] text-[#005c2d] rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 text-[#00a650]" />
                <span>{showAddCatalog ? 'FECHAR CATÁLOGO DE SCOOTERS' : '+ ADICIONAR MAIS ITENS / OUTRA SCOOTER AO PEDIDO'}</span>
              </button>

              {/* Seção do Catálogo para Adicionar Modelos */}
              {(showAddCatalog || orderItems.length === 0) && (
                <div className="p-4 sm:p-5 bg-gradient-to-b from-slate-50 to-white rounded-2xl border border-emerald-200 space-y-4 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-2">
                        <ShoppingBag className="w-4 h-4 text-[#008f43]" />
                        Adicionar Modelos Vestcasa ao Pedido
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Escolha o modelo e a cor desejada para somar ao seu pedido:
                      </p>
                    </div>
                    {orderItems.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setShowAddCatalog(false)}
                        className="text-xs font-bold text-slate-500 hover:text-slate-800"
                      >
                        ✕ Fechar
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {catalogModels.map((model) => {
                      const modelColors = model.colors && model.colors.length > 0 
                        ? model.colors 
                        : ['Vermelho', 'Preto', 'Branco'];
                      const chosenColor = selectedAddColors[model.id] || modelColors[0];

                      return (
                        <div 
                          key={model.id}
                          className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between space-y-3 hover:border-emerald-300 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-16 h-16 bg-stone-50 rounded-lg border border-slate-200 p-1 flex items-center justify-center shrink-0">
                              <img
                                src={model.image}
                                alt={model.name}
                                referrerPolicy="no-referrer"
                                className="max-h-full max-w-full object-contain"
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <span className="text-[10px] font-black uppercase text-[#008f43] bg-emerald-50 px-1.5 py-0.5 rounded">
                                {model.power}
                              </span>
                              <h5 className="text-xs sm:text-sm font-black text-slate-900 truncate">
                                {model.name}
                              </h5>
                              <p className="text-xs font-black text-[#008f43]">
                                {formatCurrency(model.price)}
                              </p>
                            </div>
                          </div>

                          {/* Cores do modelo */}
                          <div className="space-y-1">
                            <span className="text-[10px] font-bold text-slate-500 block">Cor:</span>
                            <div className="flex flex-wrap gap-1">
                              {modelColors.map((color) => {
                                const isPicked = chosenColor.toLowerCase() === color.toLowerCase();
                                return (
                                  <button
                                    key={color}
                                    type="button"
                                    onClick={() => setSelectedAddColors({ ...selectedAddColors, [model.id]: color })}
                                    className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer ${
                                      isPicked 
                                        ? 'bg-[#005c2d] text-white shadow-2xs' 
                                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                                    }`}
                                  >
                                    <span 
                                      className="w-2 h-2 rounded-full border border-white/60"
                                      style={{
                                        backgroundColor: 
                                          color.toLowerCase().includes('verm') ? '#dc2626' :
                                          color.toLowerCase().includes('pret') ? '#1e293b' :
                                          color.toLowerCase().includes('bran') ? '#f8fafc' :
                                          color.toLowerCase().includes('azul') ? '#2563eb' :
                                          color.toLowerCase().includes('amare') ? '#eab308' :
                                          color.toLowerCase().includes('cinz') || color.toLowerCase().includes('graf') ? '#64748b' : '#10b981'
                                      }}
                                    />
                                    <span>{color}</span>
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* Botão de Adicionar */}
                          <button
                            type="button"
                            onClick={() => handleAddItem(model)}
                            className="w-full py-2 px-3 bg-gradient-to-r from-[#00a650] to-[#008f43] hover:from-[#008f43] hover:to-[#007335] text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-2xs active:scale-[0.99] transition-all cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5 text-yellow-300" />
                            <span>Adicionar ao Pedido</span>
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Informação sobre Consulta Obrigatória do CEP */}
              <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200 space-y-1.5 text-xs">
                <div className="flex items-center gap-2 font-black text-emerald-950">
                  <MapPin className="w-4 h-4 text-[#008f43] shrink-0" />
                  <span>Consulta de Disponibilidade e Entrega</span>
                </div>
                <p className="text-emerald-900 leading-relaxed font-medium">
                  A disponibilidade e as condições de entrega no seu endereço serão calculadas no próximo passo através da <strong>consulta do seu CEP</strong>.
                </p>
              </div>

              {/* Seção de Cupom de Desconto Solicitada */}
              <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-2.5 shadow-2xs">
                <div className="flex items-center justify-between">
                  <label htmlFor="input-cupom-passo1" className="text-xs font-black uppercase text-slate-800 flex items-center gap-1.5">
                    <Tag className="w-4 h-4 text-[#00a650]" />
                    <span>Possui cupom de desconto?</span>
                  </label>
                  {cupomAplicado && (
                    <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                      Cupom Ativo
                    </span>
                  )}
                </div>

                {!cupomAplicado ? (
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <input
                        id="input-cupom-passo1"
                        type="text"
                        value={cupomInput}
                        onChange={(e) => {
                          setCupomInput(e.target.value.toUpperCase());
                          if (cupomFeedback) setCupomFeedback(null);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleApplyCoupon();
                          }
                        }}
                        placeholder="Digite seu cupom"
                        disabled={isApplyingCupom}
                        className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-emerald-500/20 text-xs sm:text-sm font-mono font-bold uppercase placeholder:normal-case placeholder:font-normal placeholder:text-slate-400 outline-none transition-all"
                      />
                      <button
                        type="button"
                        id="btn-aplicar-cupom-passo1"
                        onClick={() => handleApplyCoupon()}
                        disabled={isApplyingCupom || !cupomInput.trim()}
                        className="px-4 py-2.5 bg-gradient-to-r from-[#00a650] to-[#008f43] hover:from-[#008f43] hover:to-[#007335] text-white text-xs sm:text-sm font-black rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer shadow-2xs active:scale-[0.98] shrink-0 flex items-center gap-1.5"
                      >
                        {isApplyingCupom ? 'Validando...' : 'Aplicar cupom'}
                      </button>
                    </div>

                    {cupomFeedback && (
                      <div
                        className={`p-2.5 rounded-xl text-xs font-bold flex items-start gap-2 ${
                          cupomFeedback.type === 'success'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {cupomFeedback.type === 'success' ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                        )}
                        <span>{cupomFeedback.message}</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-black shrink-0">
                        <Tag className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-black text-xs sm:text-sm text-emerald-950">
                            {cupomAplicado.codigo}
                          </span>
                          <span className="text-[11px] font-bold text-emerald-700">
                            (-{cupomAplicado.porcentagem}%)
                          </span>
                        </div>
                        <span className="text-[11px] text-emerald-800 font-medium block">
                          Desconto de {formatCurrency(valorDesconto)} aplicado sobre a scooter!
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleRemoveCoupon}
                      className="text-xs font-bold text-rose-600 hover:text-rose-800 hover:bg-rose-100/60 px-2 py-1 rounded-lg transition-colors cursor-pointer shrink-0"
                    >
                      Remover
                    </button>
                  </div>
                )}
              </div>

              {/* Resumo do Pedido do Passo 1 */}
              <div className="p-4 bg-emerald-50/70 border border-emerald-200/80 rounded-2xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold uppercase text-emerald-950 tracking-wide">
                    Resumo do Pedido:
                  </span>
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-100/90 px-2 py-0.5 rounded-md">
                    {totalQuantity} {totalQuantity === 1 ? 'item' : 'itens'}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-700">
                  {orderItems.map((it) => (
                    <div key={it.id} className="flex justify-between items-center text-slate-800">
                      <span className="truncate max-w-[240px]">
                        {it.quantity}x {it.name} ({it.color})
                      </span>
                      <strong className="text-slate-900 shrink-0">
                        {formatCurrency(it.unitPrice * it.quantity)}
                      </strong>
                    </div>
                  ))}

                  {cupomAplicado && valorDesconto > 0 && (
                    <div className="flex justify-between items-center text-emerald-900 font-bold bg-emerald-100/80 -mx-2 px-2 py-1 rounded border border-emerald-300">
                      <span className="flex items-center gap-1">
                        <Tag className="w-3 h-3 text-emerald-700" />
                        <span>Desconto Cupom {cupomAplicado.codigo} (-{cupomAplicado.porcentagem}%):</span>
                      </span>
                      <strong className="font-mono text-emerald-950">- {formatCurrency(valorDesconto)}</strong>
                    </div>
                  )}

                  <div className="flex justify-between pt-1 border-t border-emerald-200/50">
                    <span>Recebimento:</span>
                    <strong className="text-slate-900">
                      Definido após consulta do CEP (Passo 2)
                    </strong>
                  </div>

                  <div className="flex justify-between pt-2 border-t border-emerald-200/70 text-sm">
                    <span className="font-bold text-slate-900">Valor Total do Pedido:</span>
                    <span className="text-base sm:text-lg font-black text-[#005c2d]">
                      {formatCurrency(totalProdutosComDesconto)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Botão para Avançar para o Passo 2 */}
              <button
                type="button"
                id="btn-continuar-para-dados"
                onClick={() => setStep(2)}
                disabled={orderItems.length === 0}
                className={`w-full py-4 px-6 font-black text-sm sm:text-base rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 uppercase tracking-wide cursor-pointer ${
                  orderItems.length > 0
                    ? 'bg-gradient-to-r from-[#00a650] to-[#008f43] hover:from-[#008f43] hover:to-[#007335] text-white hover:shadow-lg active:scale-[0.99]'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <span>CONTINUAR PARA DADOS DO PEDIDO</span>
                <ArrowRight className="w-5 h-5 text-yellow-300" />
              </button>
            </div>
          )}

          {/* ========================================================================= */}
          {/* PASSO 2: DADOS DO CLIENTE */}
          {/* ========================================================================= */}
          {step === 2 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className="space-y-1">
                <h3 className="text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <User className="w-5 h-5 text-[#00a650]" />
                  <span>Dados do Cliente & Endereço</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Preencha seus dados para emissão do pedido e nota fiscal.
                </p>
              </div>

              {/* Formulário Profissional */}
              <div className="space-y-4 bg-stone-50/60 p-4 sm:p-5 rounded-2xl border border-slate-200">
                {/* Nome Completo */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                    <span>Nome Completo *</span>
                    {step2Errors.nome && <span className="text-red-500 text-[11px] font-semibold">{step2Errors.nome}</span>}
                  </label>
                  <input
                    type="text"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Ex: João da Silva Santos"
                    className={`w-full p-3.5 rounded-xl border text-sm font-medium bg-white transition-all outline-hidden ${
                      step2Errors.nome ? 'border-red-400 bg-red-50/30' : 'border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20'
                    }`}
                  />
                </div>

                {/* CPF ou CNPJ */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                    <span>CPF ou CNPJ *</span>
                    {step2Errors.cpfCnpj && <span className="text-red-500 text-[11px] font-semibold">{step2Errors.cpfCnpj}</span>}
                  </label>
                  <input
                    type="text"
                    value={cpfCnpj}
                    onChange={(e) => setCpfCnpj(maskDocument(e.target.value))}
                    placeholder="000.000.000-00 ou 00.000.000/0000-00"
                    maxLength={18}
                    className={`w-full p-3.5 rounded-xl border text-sm font-mono font-medium bg-white transition-all outline-hidden ${
                      step2Errors.cpfCnpj ? 'border-red-400 bg-red-50/30' : 'border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20'
                    }`}
                  />
                  <span className="text-[11px] text-slate-400">
                    Aplica máscara automática para CPF (11 dígitos) ou CNPJ (14 dígitos).
                  </span>
                </div>

                {/* Telefone / WhatsApp */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">
                    <span>Telefone / WhatsApp (para contato)</span>
                  </label>
                  <input
                    type="text"
                    value={telefone}
                    onChange={(e) => setTelefone(maskPhone(e.target.value))}
                    placeholder="(11) 99999-9999"
                    maxLength={15}
                    className="w-full p-3.5 rounded-xl border border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20 text-sm font-mono font-medium bg-white transition-all outline-hidden"
                  />
                </div>

                {/* ========================================================= */}
                {/* 1. CONSULTA OBRIGATÓRIA DO CEP (Regras 1, 2, 8 e 9) */}
                {/* ========================================================= */}
                <div className="pt-3 border-t border-slate-200 space-y-3">
                  <div className="space-y-1">
                    <label className="text-xs font-black uppercase text-slate-800 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <MapPin className="w-4 h-4 text-[#008f43]" />
                        <span>Consulta Obrigatória do CEP *</span>
                      </span>
                      {step2Errors.cep && <span className="text-red-500 text-[11px] font-semibold">{step2Errors.cep}</span>}
                    </label>
                    <p className="text-[11px] text-slate-500">
                      Informe o CEP para consultar endereço, frete e opções de entrega ou retirada.
                    </p>
                  </div>

                  <div className="relative">
                    <input
                      type="text"
                      id="input-cep-checkout"
                      value={cep}
                      onChange={(e) => handleCepChange(e.target.value)}
                      placeholder="00000-000"
                      maxLength={9}
                      className={`w-full p-3.5 pr-24 rounded-xl border text-sm font-mono font-bold bg-white transition-all outline-hidden ${
                        step2Errors.cep ? 'border-red-400 bg-red-50/30' : 'border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20'
                      }`}
                    />
                    <div className="absolute right-3 top-3 flex items-center gap-1.5">
                      {isSearchingCep ? (
                        <div className="text-xs text-[#00a650] font-bold animate-pulse">
                          Consultando...
                        </div>
                      ) : isCalculatingShipping ? (
                        <div className="text-xs text-[#008f43] font-bold animate-pulse">
                          Frete...
                        </div>
                      ) : cep.replace(/\D/g, '').length === 8 ? (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold text-[11px]">
                          ✓ Consultado
                        </span>
                      ) : null}
                    </div>
                  </div>

                  {cepFeedback && (
                    <div className="text-[11px] font-semibold text-[#008f43] flex items-center gap-1">
                      <Check className="w-3.5 h-3.5 text-[#008f43]" />
                      <span>{cepFeedback}</span>
                    </div>
                  )}

                  {/* Banner de aviso antes de digitar CEP */}
                  {cep.replace(/\D/g, '').length < 8 && (
                    <div className="p-3.5 bg-stone-100/90 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                      <span>
                        O cliente deve obrigatoriamente informar o CEP antes de escolher entre entrega ou retirada.
                      </span>
                    </div>
                  )}

                  {/* APÓS CONSULTA DE QUALQUER CEP: EXIBIÇÃO OBRIGATÓRIA (Regra 1, 8 e 9) */}
                  {cep.replace(/\D/g, '').length === 8 && (
                    <div className="space-y-3.5 pt-2 animate-in fade-in duration-200">
                      {/* Banner Solicitado Exato */}
                      <div className="p-4 rounded-2xl bg-amber-50/90 border-2 border-amber-300 space-y-2 shadow-2xs">
                        <div className="flex items-center gap-2 text-amber-950 font-black text-sm">
                          <MapPin className="w-4 h-4 text-amber-700 shrink-0" />
                          <span>📍 Disponibilidade para o seu CEP</span>
                        </div>
                        <div className="space-y-1 text-xs text-amber-950 leading-relaxed font-semibold">
                          <p className="flex items-start gap-1.5 font-black text-amber-900">
                            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                            <span>⚠️ Não possui modelos disponíveis para retirada imediata.</span>
                          </p>
                          <p className="text-amber-800 pl-5.5">
                            Disponível para entrega no endereço informado ou retirada mediante reserva.
                          </p>
                        </div>
                      </div>

                      {/* Status Visuais Claros Solicitados (Regra 8) */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] sm:text-xs font-bold">
                        <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 flex items-center gap-1.5">
                          <Truck className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>🚚 Entrega: <strong className="font-black text-emerald-700">DISPONÍVEL</strong></span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-300 text-rose-900 flex items-center gap-1.5">
                          <X className="w-4 h-4 text-rose-600 shrink-0" />
                          <span>🏪 Retirada imediata: <strong className="font-black text-rose-700">INDISPONÍVEL</strong></span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-300 text-blue-900 flex items-center gap-1.5">
                          <Store className="w-4 h-4 text-blue-600 shrink-0" />
                          <span>📋 Retirada mediante reserva de 40%: <strong className="font-black text-blue-700">DISPONÍVEL</strong></span>
                        </div>
                      </div>

                      {/* OPÇÕES APÓS CONSULTAR O CEP (Regra 2) */}
                      <div className="space-y-3 pt-1">
                        <span className="text-xs font-black uppercase text-slate-800 tracking-wider block">
                          Selecione como deseja receber a sua scooter:
                        </span>

                        {step2Errors.tipoRecebimento && (
                          <div className="p-3 bg-rose-50 border border-rose-300 text-rose-700 rounded-xl text-xs font-bold flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                            <span>{step2Errors.tipoRecebimento}</span>
                          </div>
                        )}

                        <div className="grid grid-cols-1 gap-3">
                          {/* 🚚 ENTREGA (Regra 2) */}
                          <div
                            className={`p-4 rounded-2xl border-2 transition-all cursor-pointer ${
                              tipoRecebimento === 'entrega'
                                ? 'border-[#00a650] bg-emerald-50/70 shadow-md ring-2 ring-emerald-500/20'
                                : 'border-slate-200 bg-white hover:border-slate-300'
                            }`}
                            onClick={() => setTipoRecebimento('entrega')}
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              <div className="space-y-1.5 flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="text-base font-black text-slate-900 flex items-center gap-1.5">
                                    <Truck className="w-5 h-5 text-[#00a650]" />
                                    <span>🚚 ENTREGA</span>
                                  </span>
                                  <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full border border-emerald-300 uppercase">
                                    Disponível para entrega
                                  </span>
                                </div>

                                <div className="text-xs text-slate-600 space-y-0.5">
                                  <div>
                                    Endereço: <strong className="text-slate-900">{endereco ? `${endereco}${numero ? `, Nº ${numero}` : ''} - ${bairro}, ${cidade}/${estado}` : `${cidade ? `${cidade}/${estado}` : 'Endereço informado abaixo'}`}</strong>
                                  </div>
                                  <div className="flex flex-wrap items-center gap-2.5 pt-0.5">
                                    <span>Frete: <strong className="text-slate-900 font-mono">{valorFreteCalculado === 0 ? 'Frete Grátis' : formatCurrency(valorFreteCalculado)}</strong></span>
                                    <span>•</span>
                                    <span>Prazo estimado: <strong className="text-slate-900">{shippingResult?.prazo_estimado || '3 a 7 dias úteis'}</strong></span>
                                    <span>•</span>
                                    <span>Valor total: <strong className="text-[#005c2d] font-mono text-sm">{formatCurrency(finalOrderTotal)}</strong></span>
                                  </div>
                                </div>
                              </div>

                              <button
                                type="button"
                                id="btn-receber-no-meu-endereco"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setTipoRecebimento('entrega');
                                }}
                                className={`py-3 px-5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0 ${
                                  tipoRecebimento === 'entrega'
                                    ? 'bg-[#00a650] hover:bg-[#008f43] text-white shadow-sm ring-1 ring-[#008f43]'
                                    : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                                }`}
                              >
                                {tipoRecebimento === 'entrega' && <Check className="w-4 h-4 text-yellow-300 stroke-[3]" />}
                                <span>Receber no meu endereço</span>
                              </button>
                            </div>
                          </div>

                          {/* 🏪 RETIRADA NA LOJA (Regra 2 e 3) */}
                          <div
                            className={`p-4 rounded-2xl border-2 transition-all cursor-pointer ${
                              tipoRecebimento === 'retirada'
                                ? 'border-blue-600 bg-blue-50/70 shadow-md ring-2 ring-blue-500/20'
                                : 'border-slate-200 bg-white hover:border-slate-300'
                            }`}
                            onClick={() => setTipoRecebimento('retirada')}
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              <div className="space-y-1.5 flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="text-base font-black text-slate-900 flex items-center gap-1.5">
                                    <Store className="w-5 h-5 text-blue-600" />
                                    <span>🏪 RETIRADA NA LOJA</span>
                                  </span>
                                  <span className="bg-rose-100 text-rose-800 text-[10px] font-black px-2 py-0.5 rounded-full border border-rose-300 uppercase">
                                    ⚠️ Indisponível para retirada imediata
                                  </span>
                                </div>

                                <p className="text-xs text-slate-700 font-semibold leading-relaxed">
                                  Disponível apenas mediante reserva com entrada de 40% do valor do produto.
                                </p>

                                {/* Demonstração automática em tempo real dos 40% e 60% (Regra 3) */}
                                <div className="p-2.5 bg-white/95 rounded-xl border border-blue-200 text-xs space-y-1">
                                  <div className="flex justify-between text-slate-600">
                                    <span>Valor do produto:</span>
                                    <span className="font-mono font-bold text-slate-800">{formatCurrency(totalProdutosComDesconto)}</span>
                                  </div>
                                  <div className="flex justify-between text-blue-900 font-bold">
                                    <span>Entrada de 40%:</span>
                                    <span className="font-mono text-blue-700">{formatCurrency(valorEntrada40)}</span>
                                  </div>
                                  <div className="flex justify-between text-slate-600">
                                    <span>Saldo restante (60% na retirada):</span>
                                    <span className="font-mono font-bold text-slate-800">{formatCurrency(saldoRestante60)}</span>
                                  </div>
                                </div>
                              </div>

                              <button
                                type="button"
                                id="btn-reservar-para-retirada"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setTipoRecebimento('retirada');
                                }}
                                className={`py-3 px-5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0 ${
                                  tipoRecebimento === 'retirada'
                                    ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-sm ring-1 ring-blue-700'
                                    : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                                }`}
                              >
                                {tipoRecebimento === 'retirada' && <Check className="w-4 h-4 text-yellow-300 stroke-[3]" />}
                                <span>Reservar para retirada com 40% de entrada</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Campos de Endereço quando Entrega for selecionada */}
                      {tipoRecebimento === 'entrega' && (
                        <div className="space-y-3 pt-3 border-t border-slate-200 animate-in fade-in duration-150">
                          <span className="text-xs font-black uppercase text-slate-800 block">
                            Complete o Endereço de Entrega:
                          </span>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div className="sm:col-span-2 space-y-1.5">
                              <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                                <span>Endereço (Rua / Avenida) *</span>
                                {step2Errors.endereco && <span className="text-red-500 text-[11px] font-semibold">Obrigatório</span>}
                              </label>
                              <input
                                type="text"
                                value={endereco}
                                onChange={(e) => setEndereco(e.target.value)}
                                placeholder="Ex: Av. Paulista"
                                className={`w-full p-3.5 rounded-xl border text-sm font-medium bg-white transition-all outline-hidden ${
                                  step2Errors.endereco ? 'border-red-400 bg-red-50/30' : 'border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20'
                                }`}
                              />
                            </div>

                            <div className="space-y-1.5">
                              <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                                <span>Número *</span>
                                {step2Errors.numero && <span className="text-red-500 text-[11px] font-semibold">Obrigatório</span>}
                              </label>
                              <input
                                type="text"
                                value={numero}
                                onChange={(e) => setNumero(e.target.value)}
                                placeholder="Ex: 1500"
                                className={`w-full p-3.5 rounded-xl border text-sm font-medium bg-white transition-all outline-hidden ${
                                  step2Errors.numero ? 'border-red-400 bg-red-50/30' : 'border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20'
                                }`}
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div className="space-y-1.5">
                              <label className="text-xs font-bold text-slate-700">
                                <span>Complemento (opcional)</span>
                              </label>
                              <input
                                type="text"
                                value={complemento}
                                onChange={(e) => setComplemento(e.target.value)}
                                placeholder="Ex: Apto 42, Bloco B"
                                className="w-full p-3.5 rounded-xl border border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20 text-sm font-medium bg-white transition-all outline-hidden"
                              />
                            </div>

                            <div className="space-y-1.5">
                              <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                                <span>Bairro *</span>
                                {step2Errors.bairro && <span className="text-red-500 text-[11px] font-semibold">Obrigatório</span>}
                              </label>
                              <input
                                type="text"
                                value={bairro}
                                onChange={(e) => setBairro(e.target.value)}
                                placeholder="Ex: Bela Vista"
                                className={`w-full p-3.5 rounded-xl border text-sm font-medium bg-white transition-all outline-hidden ${
                                  step2Errors.bairro ? 'border-red-400 bg-red-50/30' : 'border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20'
                                }`}
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div className="sm:col-span-2 space-y-1.5">
                              <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                                <span>Cidade *</span>
                                {step2Errors.cidade && <span className="text-red-500 text-[11px] font-semibold">Obrigatório</span>}
                              </label>
                              <input
                                type="text"
                                value={cidade}
                                onChange={(e) => setCidade(e.target.value)}
                                placeholder="Ex: São Paulo"
                                className={`w-full p-3.5 rounded-xl border text-sm font-medium bg-white transition-all outline-hidden ${
                                  step2Errors.cidade ? 'border-red-400 bg-red-50/30' : 'border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20'
                                }`}
                              />
                            </div>

                            <div className="space-y-1.5">
                              <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                                <span>Estado (UF) *</span>
                                {step2Errors.estado && <span className="text-red-500 text-[11px] font-semibold">Obrigatório</span>}
                              </label>
                              <input
                                type="text"
                                value={estado}
                                onChange={(e) => setEstado(e.target.value.toUpperCase().slice(0, 2))}
                                placeholder="SP"
                                maxLength={2}
                                className={`w-full p-3.5 rounded-xl border text-sm font-mono uppercase font-medium bg-white transition-all outline-hidden ${
                                  step2Errors.estado ? 'border-red-400 bg-red-50/30' : 'border-slate-300 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20'
                                }`}
                              />
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Mensagem e Confirmação quando Retirada na Loja for selecionada */}
                      {tipoRecebimento === 'retirada' && (
                        <div className="p-4 bg-blue-50/80 rounded-xl border border-blue-200 text-xs text-blue-950 space-y-1.5 animate-in fade-in duration-150">
                          <strong className="block font-black text-sm text-blue-950 flex items-center gap-1.5">
                            <Store className="w-4 h-4 text-blue-600" />
                            <span>Retirada Oficial na Loja / Centro de Distribuição Vestcasa</span>
                          </strong>
                          <p className="leading-relaxed">
                            Região de referência: <strong>{cidade ? `${cidade}/${estado}` : 'Sua cidade'} (CEP {cep})</strong>.
                            Ao efetuar o pagamento da entrada de 40% ({formatCurrency(valorEntrada40)}), sua scooter é reservada e garantida. O saldo restante de 60% ({formatCurrency(saldoRestante60)}) será quitado presencialmente no momento da retirada.
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Caixa Obrigatória de Confirmação */}
                <div className="pt-2 border-t border-slate-200">
                  <label className="flex items-start gap-3 p-3.5 rounded-xl bg-white border border-slate-200 hover:border-emerald-500 transition-colors cursor-pointer">
                    <input
                      type="checkbox"
                      id="checkbox-confirmacao-dados"
                      checked={confirmChecked}
                      onChange={(e) => setConfirmChecked(e.target.checked)}
                      className="mt-0.5 w-5 h-5 text-[#00a650] rounded-md border-slate-300 focus:ring-[#00a650] cursor-pointer"
                    />
                    <div className="text-xs text-slate-700 select-none">
                      <strong className="text-slate-900 block font-black">
                        Confirmo que os dados informados estão corretos.
                      </strong>
                      <span className="text-slate-500">
                        Declaro que o nome, documento e endereço correspondem ao comprador oficial.
                      </span>
                    </div>
                  </label>
                  {step2Errors.confirm && (
                    <p className="text-red-500 text-xs font-bold mt-1.5 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{step2Errors.confirm}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Botões de Ação do Passo 2 */}
              <div className="flex flex-col sm:flex-row gap-2.5">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="py-3.5 px-5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer order-2 sm:order-1"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>VOLTAR PARA A SCOOTER</span>
                </button>

                <button
                  type="button"
                  id="btn-continuar-para-pagamento"
                  onClick={handleGoToStep3}
                  disabled={attemptedStep2 && !confirmChecked}
                  className={`flex-1 py-4 px-6 font-black text-sm sm:text-base rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 uppercase tracking-wide cursor-pointer order-1 sm:order-2 ${
                    confirmChecked
                      ? 'bg-gradient-to-r from-[#00a650] to-[#008f43] hover:from-[#008f43] hover:to-[#007335] text-white hover:shadow-lg active:scale-[0.99]'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <span>CONTINUAR PARA PAGAMENTO</span>
                  <ArrowRight className="w-5 h-5 text-yellow-300" />
                </button>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* PASSO 3: RESUMO DO PEDIDO */}
          {/* ========================================================================= */}
          {step === 3 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className="space-y-1 text-center sm:text-left">
                <span className="text-xs font-extrabold text-[#008f43] uppercase tracking-wider block">
                  Confirmação Final
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                  PEDIDO
                </h3>
                <p className="text-xs text-slate-500">
                  Revise as informações antes de prosseguir para a etapa de pagamento.
                </p>
              </div>

              {/* Card Estruturado do Pedido */}
              <div className="bg-stone-50 rounded-2xl p-5 sm:p-6 border border-slate-200 space-y-4 shadow-xs">
                {/* Seção dos Itens no Pedido com opção de alterar ou remover */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase text-slate-700 tracking-wider">
                      Itens do Pedido ({totalQuantity}):
                    </span>
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="text-xs font-bold text-[#008f43] hover:text-[#005c2d] flex items-center gap-1 cursor-pointer hover:underline"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Adicionar mais itens</span>
                    </button>
                  </div>

                  {orderItems.length === 0 ? (
                    <div className="p-4 bg-white rounded-xl border border-dashed border-red-300 text-center text-xs text-red-600 font-bold">
                      Você removeu todos os itens. Clique em "Adicionar mais itens" para incluir uma scooter.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {orderItems.map((it) => (
                        <div
                          key={it.id}
                          className="p-3 bg-white rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-14 h-14 bg-stone-50 rounded-lg border border-slate-200 p-1 flex items-center justify-center shrink-0">
                              <img
                                src={it.image}
                                alt={it.name}
                                referrerPolicy="no-referrer"
                                className="max-h-full max-w-full object-contain"
                              />
                            </div>
                            <div>
                              <strong className="text-sm font-black text-slate-900 block">
                                {it.name} ({it.power})
                              </strong>
                              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                                <span className="bg-emerald-50 text-[#008f43] font-bold px-1.5 py-0.5 rounded text-[11px] border border-emerald-200">
                                  Cor: {it.color}
                                </span>
                                <span>• {formatCurrency(it.unitPrice)} un</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                            {/* Stepper no Resumo */}
                            <div className="flex items-center border border-slate-300 rounded-lg overflow-hidden bg-white">
                              <button
                                type="button"
                                onClick={() => handleUpdateItemQuantity(it.id, -1)}
                                className="px-2 py-0.5 text-slate-600 hover:bg-slate-100 font-bold transition-colors cursor-pointer text-xs"
                                title="Diminuir"
                              >
                                -
                              </button>
                              <span className="px-2.5 py-0.5 text-xs font-black text-slate-900 min-w-6 text-center">
                                {it.quantity}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleUpdateItemQuantity(it.id, 1)}
                                className="px-2 py-0.5 text-slate-600 hover:bg-slate-100 font-bold transition-colors cursor-pointer text-xs"
                                title="Aumentar"
                              >
                                +
                              </button>
                            </div>

                            {/* Subtotal do item */}
                            <span className="text-sm font-black text-[#008f43] min-w-20 text-right">
                              {formatCurrency(it.unitPrice * it.quantity)}
                            </span>

                            {/* Botão de Remover */}
                            <button
                              type="button"
                              onClick={() => handleRemoveItem(it.id)}
                              className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="Remover este item"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-3 divide-y divide-slate-200 text-sm pt-2">
                  {/* Cliente */}
                  <div className="flex flex-col sm:flex-row sm:justify-between py-1.5 gap-1">
                    <span className="text-xs font-extrabold uppercase text-slate-500">Cliente:</span>
                    <strong className="text-slate-900 text-base">{nome}</strong>
                  </div>

                  {/* CPF/CNPJ */}
                  <div className="flex flex-col sm:flex-row sm:justify-between pt-2.5 gap-1">
                    <span className="text-xs font-extrabold uppercase text-slate-500">CPF/CNPJ:</span>
                    <span className="font-mono font-bold text-slate-900">{cpfCnpj}</span>
                  </div>

                  {/* Endereço / Local de Recebimento */}
                  <div className="flex flex-col sm:flex-row sm:justify-between pt-2.5 gap-1">
                    <span className="text-xs font-extrabold uppercase text-slate-500 shrink-0">
                      {tipoRecebimento === 'retirada' ? 'Local de Retirada:' : 'Endereço:'}
                    </span>
                    <span className="text-slate-700 text-xs sm:text-right max-w-sm font-medium">
                      {tipoRecebimento === 'retirada'
                        ? `Loja Oficial Vestcasa / Centro de Distribuição • Região: ${cidade ? `${cidade}/${estado}` : 'Consultada'} (CEP ${cep})`
                        : `${endereco ? `${endereco}, Nº ${numero}${complemento ? `, ${complemento}` : ''} - ${bairro}, ${cidade}/${estado} • CEP ${cep}` : `CEP ${cep} - ${cidade}/${estado}`}`}
                    </span>
                  </div>

                  {/* Modalidade */}
                  <div className="flex flex-col sm:flex-row sm:justify-between pt-2.5 gap-1">
                    <span className="text-xs font-extrabold uppercase text-slate-500">Modalidade:</span>
                    <span className="font-bold text-slate-900">
                      {tipoRecebimento === 'retirada' 
                        ? 'Reserva para Retirada na Loja (Entrada de 40%)' 
                        : `Envio em Domicílio${shippingResult?.nome_regiao ? ` • ${shippingResult.nome_regiao}` : ''}`}
                    </span>
                  </div>

                  {/* Seção de Cupom no Passo 3 */}
                  <div className="p-3.5 bg-white rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label htmlFor="input-cupom-passo3" className="text-xs font-black uppercase text-slate-800 flex items-center gap-1.5">
                        <Tag className="w-3.5 h-3.5 text-[#00a650]" />
                        <span>Cupom de desconto:</span>
                      </label>
                      {cupomAplicado && (
                        <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                          {cupomAplicado.codigo} (-{cupomAplicado.porcentagem}%)
                        </span>
                      )}
                    </div>

                    {!cupomAplicado ? (
                      <div className="space-y-1.5">
                        <div className="flex gap-2">
                          <input
                            id="input-cupom-passo3"
                            type="text"
                            value={cupomInput}
                            onChange={(e) => {
                              setCupomInput(e.target.value.toUpperCase());
                              if (cupomFeedback) setCupomFeedback(null);
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                handleApplyCoupon();
                              }
                            }}
                            placeholder="Digite seu cupom"
                            disabled={isApplyingCupom}
                            className="flex-1 px-3 py-2 rounded-xl border border-slate-300 focus:border-[#00a650] text-xs font-mono font-bold uppercase placeholder:normal-case placeholder:font-normal placeholder:text-slate-400 outline-none"
                          />
                          <button
                            type="button"
                            id="btn-aplicar-cupom-passo3"
                            onClick={() => handleApplyCoupon()}
                            disabled={isApplyingCupom || !cupomInput.trim()}
                            className="px-3.5 py-2 bg-[#00a650] hover:bg-[#008f43] text-white text-xs font-black rounded-xl transition-all disabled:opacity-50 cursor-pointer shrink-0"
                          >
                            {isApplyingCupom ? 'Aplicando...' : 'Aplicar cupom'}
                          </button>
                        </div>
                        {cupomFeedback && (
                          <p className={`text-xs font-bold ${cupomFeedback.type === 'success' ? 'text-emerald-700' : 'text-rose-600'}`}>
                            {cupomFeedback.message}
                          </p>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-xs text-emerald-800 font-bold">
                          Desconto de {formatCurrency(valorDesconto)} aplicado nas scooters
                        </span>
                        <button
                          type="button"
                          onClick={handleRemoveCoupon}
                          className="text-xs font-bold text-rose-600 hover:text-rose-800 underline cursor-pointer"
                        >
                          Remover
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Demonstração Clara Solicitada: Produto - Desconto + Frete = TOTAL */}
                  <div className="p-3.5 bg-white rounded-xl border border-slate-200 space-y-2 text-xs">
                    <div className="flex items-center justify-between text-slate-700">
                      <span className="font-medium">
                        {orderItems.length === 1 ? `Scooter ${orderItems[0].name}` : 'Subtotal Scooter(s)'}:
                      </span>
                      <strong className="font-mono text-slate-900 text-sm">{formatCurrency(totalAmount)}</strong>
                    </div>

                    {cupomAplicado && valorDesconto > 0 && (
                      <>
                        <div className="flex items-center justify-between text-emerald-800 font-bold bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
                          <span className="flex items-center gap-1.5">
                            <Tag className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Cupom {cupomAplicado.codigo} ({cupomAplicado.porcentagem}%):</span>
                          </span>
                          <span className="font-mono text-emerald-800 text-sm">- {formatCurrency(valorDesconto)}</span>
                        </div>
                        <div className="flex items-center justify-between text-slate-600">
                          <span>Valor da Scooter com desconto:</span>
                          <strong className="font-mono text-slate-800 text-xs">{formatCurrency(totalProdutosComDesconto)}</strong>
                        </div>
                      </>
                    )}

                    <div className="flex items-center justify-between text-slate-700">
                      <span className="font-medium">
                        Frete {tipoRecebimento === 'retirada' ? '(Retirada Oficial)' : (shippingResult?.nome_regiao ? `(${shippingResult.nome_regiao})` : '')}:
                      </span>
                      <strong className={`font-mono text-sm ${valorFreteCalculado === 0 ? 'text-[#008f43]' : 'text-slate-900'}`}>
                        {tipoRecebimento === 'retirada' 
                          ? 'R$ 0,00 (Grátis)' 
                          : (valorFreteCalculado === 0 ? 'R$ 0,00 (Frete Grátis)' : formatCurrency(valorFreteCalculado))}
                      </strong>
                    </div>
                    {tipoRecebimento === 'entrega' && shippingResult?.prazo_estimado && (
                      <div className="flex items-center justify-between text-slate-500 text-[11px] pt-1 border-t border-dashed border-slate-100">
                        <span>Prazo de entrega estimado:</span>
                        <span className="font-semibold text-slate-700">{shippingResult.prazo_estimado}</span>
                      </div>
                    )}
                  </div>

                  {/* 4. RESUMO DA RESERVA (Regra 4 do Checkout) */}
                  {tipoRecebimento === 'retirada' && (
                    <div className="p-4 sm:p-5 rounded-2xl bg-blue-50/90 border-2 border-blue-300 space-y-3 shadow-2xs">
                      <div className="flex items-center gap-2 text-blue-950 font-black text-sm sm:text-base">
                        <Store className="w-5 h-5 text-blue-600 shrink-0" />
                        <span>🏪 Reserva para retirada na loja</span>
                      </div>

                      <div className="space-y-2 text-xs text-slate-700 bg-white/95 p-3.5 rounded-xl border border-blue-200">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-slate-600">Valor total do pedido:</span>
                          <strong className="font-mono text-slate-900 text-sm">{formatCurrency(finalOrderTotal)}</strong>
                        </div>
                        <div className="flex justify-between items-center text-blue-950 font-bold bg-blue-100/70 p-2.5 rounded-lg border border-blue-300">
                          <span>Entrada obrigatória para reserva (40%):</span>
                          <strong className="font-mono text-blue-700 text-base">{formatCurrency(valorEntrada40)}</strong>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-slate-600">Saldo restante (60%):</span>
                          <strong className="font-mono text-slate-900 text-sm">{formatCurrency(saldoRestante60)}</strong>
                        </div>
                      </div>

                      <p className="text-xs text-blue-900 font-bold leading-relaxed">
                        Para reservar este produto para retirada na loja, é necessário realizar o pagamento da entrada de 40%.
                      </p>
                    </div>
                  )}

                  {/* Valor Total ou Entrada do Pedido */}
                  {tipoRecebimento === 'retirada' ? (
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-baseline pt-3 gap-1 bg-blue-50/70 -mx-5 sm:-mx-6 -mb-5 sm:-mb-6 p-4 sm:p-5 rounded-b-2xl border-t border-blue-200">
                      <div>
                        <span className="text-xs font-black uppercase text-blue-900 block tracking-wide">
                          ENTRADA OBRIGATÓRIA (40%):
                        </span>
                        <span className="text-[11px] text-slate-600 font-medium">
                          Total do pedido: {formatCurrency(finalOrderTotal)} • Saldo de 60% ({formatCurrency(saldoRestante60)}) pago na retirada
                        </span>
                      </div>
                      <span className="text-2xl sm:text-3xl font-black text-blue-700 tracking-tight">
                        {formatCurrency(valorEntrada40)}
                      </span>
                    </div>
                  ) : (
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-baseline pt-3 gap-1 bg-emerald-50/60 -mx-5 sm:-mx-6 -mb-5 sm:-mb-6 p-4 sm:p-5 rounded-b-2xl border-t border-emerald-200">
                      <div>
                        <span className="text-xs font-black uppercase text-[#005c2d] block tracking-wide">
                          TOTAL:
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {totalQuantity} {totalQuantity === 1 ? 'item incluso' : 'itens inclusos'} • {valorFreteCalculado > 0 ? 'Com frete incluso' : 'Frete grátis'}
                        </span>
                      </div>
                      <span className="text-2xl sm:text-3xl font-black text-[#005c2d] tracking-tight">
                        {formatCurrency(finalOrderTotal)}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Botões de Ação do Passo 3 */}
              <div className="flex flex-col sm:flex-row gap-2.5">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="py-3.5 px-5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer order-2 sm:order-1"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>EDITAR DADOS</span>
                </button>

                <button
                  type="button"
                  id="btn-ir-para-pagamento"
                  onClick={handleProceedToPayment}
                  disabled={isCreatingOrder || orderItems.length === 0}
                  className={`flex-1 py-4 px-6 font-black text-sm sm:text-base rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 uppercase tracking-wide cursor-pointer order-1 sm:order-2 ${
                    orderItems.length > 0 && !isCreatingOrder
                      ? 'bg-gradient-to-r from-[#00a650] to-[#008f43] hover:from-[#008f43] hover:to-[#007335] text-white hover:shadow-xl active:scale-[0.99]'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <span>
                    {isCreatingOrder 
                      ? 'REGISTRANDO PEDIDO...' 
                      : (tipoRecebimento === 'retirada' ? 'IR PARA PAGAMENTO DA ENTRADA (40%)' : 'IR PARA PAGAMENTO')}
                  </span>
                  <ArrowRight className="w-5 h-5 text-yellow-300" />
                </button>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* PASSO 4: PAGAMENTO (ABAS PIX E CARTÃO DE CRÉDITO) */}
          {/* ========================================================================= */}
          {step === 4 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              {/* Notificação de Pedido Gerado */}
              {createdOrder && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="text-slate-700 font-medium">
                      Código do Pedido: <strong className="font-mono text-slate-900">{createdOrder.codigo}</strong>
                    </span>
                  </div>
                  <span className="bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                    Aguardando Pagamento
                  </span>
                </div>
              )}

              {/* Abas de Pagamento Solicitadas */}
              <div className="grid grid-cols-2 p-1.5 bg-slate-100 rounded-2xl gap-1.5">
                <button
                  type="button"
                  id="tab-pagamento-pix"
                  onClick={() => setPaymentTab('pix')}
                  className={`py-3 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-1.5 sm:gap-2 cursor-pointer ${
                    paymentTab === 'pix'
                      ? 'bg-white text-[#005c2d] shadow-sm ring-1 ring-slate-200/80'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                  }`}
                >
                  <Banknote className="w-4 h-4" />
                  <span>{tipoRecebimento === 'retirada' ? '💳 ENTRADA (40%) À VISTA' : '💳 PAGAMENTO À VISTA'}</span>
                </button>

                <button
                  type="button"
                  id="tab-pagamento-cartao"
                  onClick={() => setPaymentTab('cartao')}
                  className={`py-3 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-1.5 sm:gap-2 cursor-pointer ${
                    paymentTab === 'cartao'
                      ? 'bg-white text-[#005c2d] shadow-sm ring-1 ring-slate-200/80'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>{tipoRecebimento === 'retirada' ? '💳 PAGAMENTO PARCELADO' : '💳 CARTÃO DE CRÉDITO'}</span>
                </button>
              </div>

              {/* =================================================================== */}
              {/* ABA 1: DADOS PARA PAGAMENTO À VISTA */}
              {/* =================================================================== */}
              {paymentTab === 'pix' && (
                <div className="space-y-4 animate-in fade-in duration-150">
                  {tipoRecebimento === 'retirada' ? (
                    <>
                      <div className="text-center space-y-1">
                        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 text-blue-900 text-xs font-black uppercase tracking-wider">
                          <Store className="w-3.5 h-3.5 text-blue-700" />
                          <span>Reserva para Retirada na Loja</span>
                        </div>
                        <h4 className="text-lg font-black text-slate-900 uppercase tracking-tight">
                          Entrada para Reserva (Retirada)
                        </h4>
                      </div>

                      {/* Destaque Obrigatório: Valor da entrada: R$ X */}
                      <div className="p-4 sm:p-5 rounded-2xl bg-blue-50/90 border-2 border-blue-300 text-center space-y-1 shadow-2xs">
                        <span className="text-xs font-black uppercase text-blue-900 block tracking-wider">
                          Valor da entrada (40%):
                        </span>
                        <span className="text-3xl sm:text-4xl font-black text-blue-700 font-mono tracking-tight block">
                          {formatCurrency(valorEntrada40)}
                        </span>
                        <span className="text-xs text-slate-600 font-medium block pt-1">
                          Saldo restante (60%): <strong className="text-slate-900 font-mono">{formatCurrency(saldoRestante60)}</strong> a pagar na retirada da scooter.
                        </span>
                      </div>

                      {/* Resumo da Reserva e Valores */}
                      <div className="p-3.5 bg-stone-50 rounded-xl border border-slate-200 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between text-slate-600">
                          <span>Valor total do pedido:</span>
                          <span className="font-semibold text-slate-900 font-mono">{formatCurrency(finalOrderTotal)}</span>
                        </div>
                        <div className="flex items-center justify-between text-blue-900 font-bold bg-blue-100/70 px-2.5 py-1.5 rounded-lg border border-blue-300">
                          <span>Entrada obrigatória para reserva (40%):</span>
                          <span className="font-mono text-blue-700 text-sm">{formatCurrency(valorEntrada40)}</span>
                        </div>
                        <div className="flex items-center justify-between text-slate-600">
                          <span>Saldo restante (60%):</span>
                          <span className="font-semibold text-slate-900 font-mono">{formatCurrency(saldoRestante60)}</span>
                        </div>
                      </div>
                    </>
                  ) : (
                    /* FLUXO NORMAL DE ENTREGA */
                    <>
                      <div className="p-3.5 bg-stone-50 rounded-xl border border-slate-200 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between text-slate-600">
                          <span>Subtotal Scooter(s):</span>
                          <span className="font-semibold text-slate-800">{formatCurrency(totalAmount)}</span>
                        </div>
                        {cupomAplicado && valorDesconto > 0 && (
                          <div className="flex items-center justify-between text-emerald-800 font-bold bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
                            <span className="flex items-center gap-1">
                              <Tag className="w-3 h-3 text-emerald-600" />
                              <span>Cupom {cupomAplicado.codigo} ({cupomAplicado.porcentagem}%):</span>
                            </span>
                            <span className="font-mono text-emerald-800 font-black">- {formatCurrency(valorDesconto)}</span>
                          </div>
                        )}
                        <div className="flex items-center justify-between text-slate-600">
                          <span>Frete ({shippingResult?.nome_regiao || 'Entrega'}):</span>
                          <span className="font-semibold text-slate-800">
                            {valorFreteCalculado === 0 ? 'R$ 0,00 (Grátis)' : formatCurrency(valorFreteCalculado)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between pt-1 border-t border-slate-200">
                          <span className="text-slate-900 font-extrabold uppercase">Valor Total do Pedido:</span>
                          <span className="text-base sm:text-lg font-black text-[#005c2d]">
                            {formatCurrency(finalOrderTotal)}
                          </span>
                        </div>
                      </div>
                    </>
                  )}

                  {/* 2. NOVA ÁREA DE PAGAMENTO */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-5 text-slate-800 space-y-3.5 shadow-2xs">
                    <div className="text-center space-y-1 pb-1 border-b border-slate-200">
                      <h4 className="text-base sm:text-lg font-black text-slate-900 tracking-tight flex items-center justify-center gap-1.5 uppercase">
                        💳 DADOS PARA PAGAMENTO À VISTA
                      </h4>
                    </div>

                    <p className="text-xs text-slate-700 leading-relaxed">
                      Para valores inferiores a R$ 30.000,00, os recebimentos são direcionados à conta do sócio majoritário responsável pelo setor financeiro, conforme os dados abaixo:
                    </p>

                    <div className="bg-white border-2 border-emerald-500/40 rounded-xl p-3.5 sm:p-4 space-y-2.5 shadow-xs">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 border-b border-slate-100">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Chave Pix (CNPJ):</span>
                        <span className="text-sm font-black font-mono text-emerald-800 select-all">
                          61.873.556/0001-87
                        </span>
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2 border-b border-slate-100">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Instituição:</span>
                        <span className="text-xs sm:text-sm font-bold text-slate-800">
                          NU PAGAMENTOS – IP
                        </span>
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Responsável financeiro:</span>
                        <span className="text-xs sm:text-sm font-bold text-slate-800">
                          Maria Eduarda Silva
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      Para valores acima de R$ 30.000,00, são utilizados os dados bancários do CNPJ da empresa Vestcasa.
                    </p>

                    <p className="text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg p-2.5">
                      Após a transferência, encaminhe o comprovante para conferência.
                    </p>
                  </div>

                  {/* 3. BOTÃO PARA WHATSAPP */}
                  <div className="pt-1">
                    <a
                      id="btn-informar-pagamento-whatsapp-checkout"
                      href={WHATSAPP_AVISTA_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={handleInformarPagamentoWhatsApp}
                      className="w-full py-4 px-4 bg-[#25D366] hover:bg-[#20ba59] active:scale-[0.99] text-white font-black text-xs sm:text-sm rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wider text-center group"
                    >
                      <span>🟢 INFORMAR PAGAMENTO PELO WHATSAPP</span>
                    </a>
                  </div>
                </div>
              )}

              {/* =================================================================== */}
              {/* ABA 2: CARTÃO DE CRÉDITO OU PAGAMENTO PARCELADO */}
              {/* =================================================================== */}
              {paymentTab === 'cartao' && (
                <div className="space-y-4 animate-in fade-in duration-150">
                  {tipoRecebimento === 'retirada' ? (
                    /* 6. PAGAMENTO PARCELADO DA ENTRADA (Regra 6 do Checkout) */
                    <div className="bg-stone-50 rounded-2xl p-5 sm:p-6 border-2 border-blue-200 space-y-4 text-center">
                      <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto shadow-md">
                        <CreditCard className="w-7 h-7" />
                      </div>

                      <div className="space-y-1.5 max-w-md mx-auto">
                        <h4 className="text-lg sm:text-xl font-black text-slate-900 uppercase tracking-tight">
                          Pagamento parcelado
                        </h4>
                        <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-semibold">
                          Para realizar o pagamento parcelado da entrada, peça o link de pagamento para o seu atendente.
                        </p>
                      </div>

                      {/* Resumo dinâmico da reserva com valores recalculados */}
                      <div className="p-4 bg-white rounded-xl border border-blue-200 text-xs space-y-2 max-w-md mx-auto text-left shadow-2xs">
                        <div className="flex justify-between items-center text-slate-600">
                          <span>Valor total do pedido:</span>
                          <strong className="font-mono text-slate-900 text-sm">{formatCurrency(finalOrderTotal)}</strong>
                        </div>
                        <div className="flex justify-between items-center text-blue-950 font-bold bg-blue-100/70 p-2 rounded-lg border border-blue-300">
                          <span>Entrada de 40% a parcelar:</span>
                          <strong className="font-mono text-blue-700 text-base">{formatCurrency(valorEntrada40)}</strong>
                        </div>
                        <div className="flex justify-between items-center text-slate-600">
                          <span>Saldo restante (60% na retirada):</span>
                          <strong className="font-mono text-slate-900 text-sm">{formatCurrency(saldoRestante60)}</strong>
                        </div>
                      </div>

                      {/* Botão Solicitado Exato: “Pedir link para o meu atendente” */}
                      <button
                        type="button"
                        id="btn-pedir-link-atendente"
                        onClick={handleRequestInstallmentLink}
                        className="w-full sm:w-auto px-6 py-4 bg-[#25D366] hover:bg-[#20ba59] active:scale-[0.99] text-white font-black text-sm rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2.5 mx-auto uppercase tracking-wider cursor-pointer"
                      >
                        <MessageCircle className="w-5 h-5 fill-white stroke-none" />
                        <span>Pedir link para o meu atendente</span>
                      </button>

                      <p className="text-[11px] text-slate-500 max-w-sm mx-auto leading-relaxed">
                        Ao clicar, abriremos seu WhatsApp com a solicitação pronta para o atendente da Vestcasa enviar seu link de pagamento da entrada parcelada.
                      </p>
                    </div>
                  ) : (
                    /* PAGAMENTO COM CARTÃO DE CRÉDITO */
                    <div className="space-y-4 animate-in fade-in duration-150">
                      <div className="text-center space-y-1">
                        <h4 className="text-lg sm:text-xl font-black text-slate-900 uppercase tracking-tight">
                          PAGAMENTO COM CARTÃO DE CRÉDITO
                        </h4>
                        <p className="text-xs sm:text-sm text-slate-600 font-semibold">
                          Simule seu parcelamento no cartão
                        </p>
                      </div>

                      {/* Exibição Solicitada: Valor total da compra */}
                      <div className="p-4 sm:p-5 rounded-2xl bg-stone-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs">
                        <div>
                          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                            Valor total do pedido:
                          </span>
                          <span className="text-[11px] text-slate-400">
                            Valor atualizado com {totalQuantity} {totalQuantity === 1 ? 'item incluso' : 'itens inclusos'}{valorFreteCalculado > 0 ? ` + frete (${formatCurrency(valorFreteCalculado)})` : ' com frete grátis'}
                          </span>
                        </div>
                        <span className="text-2xl sm:text-3xl font-black text-[#005c2d] font-mono tracking-tight">
                          {formatCurrency(finalOrderTotal)}
                        </span>
                      </div>

                      {/* Seletor visual de parcelas de 1x a 12x */}
                      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-3 shadow-xs">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-black uppercase text-slate-800 tracking-wide block">
                            Escolha as parcelas (1x até 12x):
                          </label>
                          <span className="text-xs font-bold text-[#00a650] font-mono">
                            {selectedInstallments}x selecionado
                          </span>
                        </div>

                        {/* Grade interativa de seleção de 1x a 12x */}
                        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((num) => {
                            const valParcela = Math.round((finalOrderTotal / num) * 100) / 100;
                            const isSelected = selectedInstallments === num;

                            return (
                              <button
                                key={num}
                                type="button"
                                onClick={() => setSelectedInstallments(num)}
                                className={`p-2 sm:p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                                  isSelected
                                    ? 'bg-[#00a650] text-white border-[#008f43] shadow-sm font-black ring-2 ring-emerald-500/20 scale-[1.02]'
                                    : 'bg-stone-50 hover:bg-slate-100 text-slate-700 border-slate-200 font-bold'
                                }`}
                              >
                                <span className="text-xs sm:text-sm font-black block">{num}x</span>
                                <span className={`text-[10px] block truncate ${isSelected ? 'text-yellow-200 font-bold' : 'text-slate-500 font-medium'}`}>
                                  {formatCurrency(valParcela)}
                                </span>
                              </button>
                            );
                          })}
                        </div>

                        {/* Menu suspenso complementar para seleção rápida */}
                        <div className="pt-2 border-t border-slate-100">
                          <label htmlFor="select-parcelas-cartao" className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
                            Ou selecione pela lista completa de parcelas:
                          </label>
                          <select
                            id="select-parcelas-cartao"
                            value={selectedInstallments}
                            onChange={(e) => setSelectedInstallments(Number(e.target.value))}
                            className="w-full p-3 rounded-xl border border-slate-300 bg-stone-50 focus:bg-white text-xs sm:text-sm font-bold text-slate-800 focus:border-[#00a650] focus:ring-2 focus:ring-[#00a650]/20 outline-none cursor-pointer"
                          >
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((num) => {
                              const valParcela = Math.round((finalOrderTotal / num) * 100) / 100;
                              return (
                                <option key={num} value={num}>
                                  {num}x de {formatCurrency(valParcela)}
                                </option>
                              );
                            })}
                          </select>
                        </div>
                      </div>

                      {/* Quando o cliente selecionar uma parcela, mostrar:
                          Valor do pedido: R$ X.XXX,XX
                          Parcelamento escolhido: 12x de R$ XXX,XX
                          Total: R$ X.XXX,XX
                      */}
                      <div className="p-4 sm:p-5 bg-stone-50 rounded-2xl border border-slate-200 space-y-2.5 text-xs sm:text-sm shadow-2xs">
                        <div className="flex items-center justify-between text-slate-600">
                          <span className="font-semibold text-slate-600">Valor do pedido:</span>
                          <strong className="font-mono text-slate-900 text-sm sm:text-base">
                            {formatCurrency(finalOrderTotal)}
                          </strong>
                        </div>

                        <div className="flex items-center justify-between text-emerald-950 font-bold bg-emerald-100/70 p-3 rounded-xl border border-emerald-300">
                          <span>Parcelamento escolhido:</span>
                          <strong className="font-mono text-emerald-800 text-sm sm:text-base">
                            {selectedInstallments}x de {formatCurrency(valorParcelaSimulada)}
                          </strong>
                        </div>

                        <div className="flex items-center justify-between pt-1 border-t border-slate-200">
                          <span className="text-slate-900 font-extrabold uppercase">Total:</span>
                          <span className="text-base sm:text-lg font-black text-[#005c2d] font-mono">
                            {formatCurrency(finalOrderTotal)}
                          </span>
                        </div>
                      </div>

                      {/* Botão verde grande: SOLICITAR LINK DE PAGAMENTO */}
                      <button
                        type="button"
                        id="btn-solicitar-link-pagamento"
                        onClick={handleRequestCreditCardLink}
                        className="w-full py-4 px-6 bg-[#25D366] hover:bg-[#20ba59] active:scale-[0.99] text-white font-black text-sm sm:text-base rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2.5 uppercase tracking-wider cursor-pointer"
                      >
                        <MessageCircle className="w-5 h-5 fill-white stroke-none shrink-0" />
                        <span>SOLICITAR LINK DE PAGAMENTO</span>
                      </button>

                      <p className="text-[11px] text-slate-500 text-center leading-relaxed">
                        Ao clicar, você será direcionado para o WhatsApp oficial (+55 11 97158-3047) com a mensagem solicitando o link de pagamento.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Seção de Segurança e UX */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex items-start gap-2.5 text-xs text-slate-600">
                <ShieldCheck className="w-5 h-5 text-[#00a650] shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <strong className="text-slate-900 block font-bold">
                    Ambiente 100% Seguro & Protegido
                  </strong>
                  <p className="text-[11px] leading-relaxed">
                    {tipoRecebimento === 'retirada'
                      ? 'Sua reserva fica garantida com a entrada de 40%. O saldo de 60% só é pago presencialmente na retirada da sua scooter.'
                      : 'O site não solicita número do cartão, validade ou CVV. O cartão não é processado diretamente pelo site: você simula as parcelas e solicita o link de pagamento seguro pelo WhatsApp.'}
                  </p>
                </div>
              </div>

              {/* Ações Finais: Finalizar no WhatsApp (quando não estiver na aba à vista) */}
              {paymentTab !== 'pix' && (
                <div className="space-y-3 pt-3 border-t border-slate-200">
                  <div className="p-3.5 bg-emerald-50/90 border border-emerald-200/90 rounded-2xl flex items-start gap-3 shadow-2xs">
                    <div className="w-10 h-10 rounded-xl bg-[#25D366] text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
                      <MessageCircle className="w-5 h-5 fill-white stroke-none" />
                    </div>
                    <div className="text-xs text-slate-700 leading-relaxed">
                      <strong className="text-emerald-950 font-black block text-sm">
                        {tipoRecebimento === 'retirada' ? 'Finalize a sua Reserva pelo WhatsApp' : 'Finalize seu Pedido pelo WhatsApp'}
                      </strong>
                      {tipoRecebimento === 'retirada'
                        ? 'Após efetuar o Pix da entrada de 40% (ou solicitar o link parcelado), clique no botão abaixo para nos enviar o comprovante com o código da sua reserva e garantir a sua scooter.'
                        : 'Após efetuar o Pix ou pagamento no seu banco, clique no botão abaixo para nos enviar o comprovante com o código do seu pedido e agilizar a liberação imediata da sua scooter.'}
                    </div>
                  </div>

                  {/* BOTÃO PRINCIPAL SOLICITADO */}
                  <button
                    type="button"
                    id="btn-finalizar-whatsapp-checkout"
                    onClick={handleFinalizeWhatsApp}
                    className="w-full py-4 px-5 bg-[#25D366] hover:bg-[#20ba59] active:scale-[0.99] text-white font-black text-sm sm:text-base rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-3 cursor-pointer uppercase tracking-wider group"
                  >
                    <MessageCircle className="w-6 h-6 fill-white stroke-none shrink-0 group-hover:scale-110 transition-transform" />
                    <span>
                      {tipoRecebimento === 'retirada'
                        ? 'JÁ PAGUEI A ENTRADA - FINALIZAR NO WHATSAPP'
                        : 'JÁ FIZ O PAGAMENTO - FINALIZAR NO WHATSAPP'}
                    </span>
                  </button>
                </div>
              )}

              <div className="space-y-3 pt-2">
                {reportedPaymentSuccess && (
                  <div className="p-3 bg-emerald-100/80 border border-emerald-300 text-emerald-900 text-xs font-bold rounded-xl flex items-center gap-2 animate-in fade-in">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>Pedido e comprovante direcionados para o WhatsApp da Vestcasa!</span>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleNotifyPayment}
                    disabled={isReportingPayment}
                    className="text-xs text-slate-500 hover:text-slate-800 font-medium underline underline-offset-2 py-1 cursor-pointer disabled:opacity-50"
                  >
                    {isReportingPayment ? 'Notificando sistema...' : 'Avisar pagamento no sistema sem abrir WhatsApp'}
                  </button>

                  <button
                    type="button"
                    onClick={onClose}
                    className="w-full sm:w-auto py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
                  >
                    CONCLUIR E FECHAR
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
