import React, { useState } from 'react';
import { MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';

export const FloatingWhatsApp: React.FC = () => {
  const [isHovered, setIsHovered] = useState(false);
  const whatsappNumber = '5511971583047';
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=Ol%C3%A1!%20Estou%20no%20site%20da%20Vestcasa%20e%20gostaria%20de%20informa%C3%A7%C3%B5es%20sobre%20as%20scooters%20el%C3%A9tricas.`;

  return (
    <div className="fixed bottom-5 right-4 sm:bottom-6 sm:right-6 z-40 flex items-center gap-2 select-none">
      {/* Tooltip on hover (desktop & touch-safe) */}
      <div
        className={`hidden sm:flex items-center bg-slate-900 text-white text-xs font-bold px-3 py-2 rounded-xl shadow-lg transition-all duration-200 pointer-events-none whitespace-nowrap ${
          isHovered
            ? 'opacity-100 translate-x-0'
            : 'opacity-0 translate-x-2'
        }`}
      >
        <span>Fale com nossa equipe</span>
        <div className="w-2 h-2 bg-slate-900 rotate-45 -mr-1 ml-2" />
      </div>

      {/* Floating Action Button with Entrance Animation */}
      <motion.a
        id="btn-whatsapp-flutuante"
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        initial={{ scale: 0, opacity: 0, y: 24 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{
          type: 'spring',
          stiffness: 260,
          damping: 18,
          delay: 0.4,
          duration: 0.6,
        }}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.94 }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className="w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-[#25D366] hover:bg-[#20ba59] text-white flex items-center justify-center shadow-[0_8px_20px_-4px_rgba(37,211,102,0.5)] hover:shadow-[0_12px_28px_-4px_rgba(37,211,102,0.6)] transition-shadow cursor-pointer relative group"
        aria-label="Fale com nossa equipe no WhatsApp"
        title="Fale com nossa equipe"
      >
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-red-500 rounded-full border-2 border-white animate-pulse" />
        <MessageCircle className="w-7 h-7 fill-white stroke-none group-hover:scale-110 transition-transform" />
      </motion.a>
    </div>
  );
};
