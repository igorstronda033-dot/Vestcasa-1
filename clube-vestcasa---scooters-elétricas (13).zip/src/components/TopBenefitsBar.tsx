import React from 'react';
import { ShieldCheck, Headphones, CreditCard, Truck, Award, Sparkles } from 'lucide-react';

export const TopBenefitsBar: React.FC = () => {
  const benefits = [
    { icon: ShieldCheck, text: 'Compra 100% Segura' },
    { icon: CreditCard, text: 'Pagamento Protegido via PIX Oficial' },
    { icon: Headphones, text: 'Atendimento Especializado' },
    { icon: Truck, text: 'Retirada em Loja ou Entrega Garantida' },
    { icon: Award, text: 'Garantia e Peças Originais' },
    { icon: Sparkles, text: 'Direto de Fábrica Vestcasa' },
  ];

  return (
    <div className="bg-[#0f1713] text-white border-b border-emerald-950/40 text-[11px] sm:text-xs overflow-hidden select-none">
      {/* Desktop view: Centered, clean items with subtle separator dots */}
      <div className="hidden lg:flex max-w-7xl mx-auto px-4 py-2 items-center justify-between text-slate-200">
        {benefits.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div key={idx} className="flex items-center gap-1.5 transition-colors hover:text-white">
              <Icon className="w-3.5 h-3.5 text-[#00c853] shrink-0" />
              <span className="font-medium tracking-tight">{item.text}</span>
            </div>
          );
        })}
      </div>

      {/* Mobile view: Smooth auto-scrolling ticker/marquee */}
      <div className="lg:hidden relative py-2 overflow-hidden flex whitespace-nowrap">
        <div className="flex animate-[marquee_25s_linear_infinite] gap-8 items-center text-slate-200 px-4">
          {[...benefits, ...benefits].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div key={idx} className="inline-flex items-center gap-1.5 shrink-0">
                <Icon className="w-3.5 h-3.5 text-[#00c853] shrink-0" />
                <span className="font-medium">{item.text}</span>
                <span className="text-slate-600 ml-3">•</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
