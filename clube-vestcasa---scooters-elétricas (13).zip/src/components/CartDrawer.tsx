import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  ArrowRight, 
  Send, 
  ShieldCheck, 
  AlertCircle,
  CheckCircle2,
  Bike,
  Search,
  Copy,
  Check,
  MessageCircle
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { RainbowBar } from './RainbowBar';
import { Pedido, CartItem } from '../types';
import { createOrder } from '../services/orderService';
import { getModelImage } from '../services/scooterService';

interface CartDrawerProps {
  onNavigateToConsultation?: (orderCode: string) => void;
  onExploreCatalog?: () => void;
  onStartCheckout?: (items: CartItem[]) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ 
  onNavigateToConsultation, 
  onExploreCatalog,
  onStartCheckout,
}) => {
  const { 
    items, 
    totalQuantity, 
    totalAmount, 
    isCartOpen, 
    setIsCartOpen, 
    incrementQuantity, 
    decrementQuantity, 
    removeFromCart, 
    clearCart 
  } = useCart();

  const [feedbackError, setFeedbackError] = useState<string | null>(null);
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);
  const [createdOrderCode, setCreatedOrderCode] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  if (!isCartOpen) return null;

  const formatCurrency = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const handleIncrement = (itemId: string, itemName: string) => {
    setFeedbackError(null);
    const res = incrementQuantity(itemId);
    if (!res.success && res.message) {
      setFeedbackError(res.message);
      setTimeout(() => setFeedbackError(null), 4000);
    }
  };

  const handleDecrement = (itemId: string) => {
    setFeedbackError(null);
    decrementQuantity(itemId);
  };

  // Montar mensagem detalhada para WhatsApp com lista de produtos, quantidades e subtotais
  const generateWhatsappMessage = () => {
    let msg = `Olá, equipe Vestcasa! Gostaria de fazer o pedido dos seguintes itens no meu carrinho:\n\n`;
    items.forEach((item, idx) => {
      const corTexto = item.cor ? ` (Cor: ${item.cor})` : '';
      msg += `${idx + 1}. *${item.nome_produto}*${corTexto}\n`;
      msg += `   • Quantidade: ${item.quantidade} un.\n`;
      msg += `   • Preço Unitário: ${formatCurrency(item.preco_unitario)}\n`;
      msg += `   • Subtotal: ${formatCurrency(item.subtotal)}\n\n`;
    });
    msg += `📦 *Total de Itens:* ${totalQuantity} un.\n`;
    msg += `💰 *Valor Total do Pedido:* ${formatCurrency(totalAmount)}\n\n`;
    msg += `Por favor, confirmem a disponibilidade para entrega/retirada. Obrigado!`;
    return encodeURIComponent(msg);
  };

  const handleSendWhatsapp = () => {
    const encoded = generateWhatsappMessage();
    window.open(`https://wa.me/5511971583047?text=${encoded}`, '_blank');
  };

  // Finalizar pedido e abrir modal PIX com os dados salvos (incluindo array de itens para Supabase)
  const handleCheckoutPix = async () => {
    if (items.length === 0) return;
    setIsProcessingCheckout(true);
    setFeedbackError(null);

    try {
      // Gera código de pedido único
      const randomPart = Math.floor(1000 + Math.random() * 9000);
      const codigoGerado = `VEST-CART${randomPart}`;

      // Nome do resumo de produtos
      const produtosResumo = items
        .map((i) => `${i.quantidade}x ${i.nome_produto}${i.cor ? ` (${i.cor})` : ''}`)
        .join(', ');

      const pedidoPayload = {
        codigo: codigoGerado,
        nome_cliente: 'Cliente Vestcasa (Carrinho)',
        produto: produtosResumo,
        cor: items.length === 1 ? (items[0].cor || 'Padrão') : 'Múltiplas cores',
        valor: totalAmount,
        status_pagamento: 'Pendente' as const,
        observacao: `Pedido realizado via Carrinho de Compras (${totalQuantity} itens)`,
        imagem_url: items[0]?.imagem || undefined,
        itens: items, // Salva os itens com id_produto, nome_produto, preco_unitario, quantidade, subtotal
      };

      const result = await createOrder(pedidoPayload);

      if (result.data) {
        clearCart();
        setCreatedOrderCode(result.data.codigo);
      } else if (result.error) {
        setFeedbackError(`Erro ao criar pedido: ${result.error}`);
      }
    } catch (err: any) {
      setFeedbackError(err.message || 'Falha ao processar checkout.');
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-in fade-in duration-200">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity cursor-pointer"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-l border-slate-200 animate-in slide-in-from-right duration-300">
          {/* Top Bar Decoration */}
          <div>
            <RainbowBar height="h-[4px]" />

            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-stone-50/80">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#005c2d] text-[#ffd000] flex items-center justify-center shadow-xs">
                  <ShoppingBag className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base sm:text-lg font-black text-slate-900 uppercase tracking-tight">
                      Meu Carrinho
                    </h2>
                    <span className="bg-[#00a650] text-white text-[11px] font-black px-2 py-0.5 rounded-full shadow-2xs">
                      {totalQuantity} {totalQuantity === 1 ? 'item' : 'itens'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">Clube Vestcasa • Mobilidade Elétrica</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsCartOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-xl transition-colors cursor-pointer"
                title="Fechar Carrinho"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Feedback Error / Stock Toast */}
          {feedbackError && (
            <div className="mx-4 mt-3 p-3 bg-amber-50 border border-amber-300 text-amber-900 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in slide-in-from-top-1">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span className="flex-1">{feedbackError}</span>
            </div>
          )}

          {/* Items List Area */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {createdOrderCode ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-5 animate-in fade-in">
                <div className="w-16 h-16 rounded-2xl bg-emerald-100 border border-emerald-200 flex items-center justify-center text-emerald-600 shadow-sm">
                  <CheckCircle2 className="w-9 h-9" />
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-black tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full uppercase border border-emerald-200">
                    Pedido Registrado
                  </span>
                  <h3 className="text-xl font-black text-slate-900">
                    Pedido Criado com Sucesso!
                  </h3>
                  <p className="text-xs text-slate-600 max-w-xs mx-auto leading-relaxed">
                    Guarde o código do seu pedido. Para efetuar o pagamento via PIX ou Cartão de Crédito, consulte o seu pedido informando o código abaixo.
                  </p>
                </div>

                {/* Card Código */}
                <div className="w-full bg-slate-50 border-2 border-dashed border-emerald-300 rounded-2xl p-4 space-y-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    Código do seu Pedido
                  </span>
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-2xl font-mono font-black text-[#005c2d] tracking-wider">
                      {createdOrderCode}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(createdOrderCode);
                        setCopiedCode(true);
                        setTimeout(() => setCopiedCode(false), 3000);
                      }}
                      className="p-2 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 text-slate-600 transition-colors cursor-pointer"
                      title="Copiar Código"
                    >
                      {copiedCode ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  {copiedCode && (
                    <p className="text-[11px] font-bold text-emerald-600">Código copiado com sucesso!</p>
                  )}
                </div>

                {/* Botão para Consultar Pedido e Efetuar Pagamento */}
                <div className="w-full space-y-2 pt-2">
                  <button
                    type="button"
                    id="btn-ir-consultar-pagar"
                    onClick={() => {
                      const code = createdOrderCode;
                      setCreatedOrderCode(null);
                      setIsCartOpen(false);
                      if (onNavigateToConsultation) {
                        onNavigateToConsultation(code);
                      }
                    }}
                    className="w-full py-4 bg-gradient-to-r from-[#ffd000] to-[#fbc02d] hover:brightness-105 text-slate-950 font-black text-sm rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 uppercase tracking-wide cursor-pointer"
                  >
                    <Search className="w-4 h-4 text-slate-950" />
                    <span>CONSULTAR PEDIDO PARA PAGAR</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setCreatedOrderCode(null);
                      setIsCartOpen(false);
                    }}
                    className="w-full py-2.5 text-xs text-slate-500 hover:text-slate-800 font-bold transition-colors cursor-pointer"
                  >
                    Fechar
                  </button>
                </div>
              </div>
            ) : items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-20 h-20 rounded-full bg-emerald-50 border border-emerald-100 flex items-center justify-center text-[#00a650]">
                  <ShoppingBag className="w-10 h-10 stroke-[1.5]" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-black text-slate-800 uppercase">
                    Seu carrinho está vazio
                  </h3>
                  <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
                    Escolha um dos modelos de scooters no catálogo e clique em "Adicionar ao Carrinho".
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setIsCartOpen(false);
                    if (onExploreCatalog) onExploreCatalog();
                  }}
                  className="mt-2 px-5 py-2.5 bg-[#00a650] hover:bg-[#008f43] text-white text-xs font-black rounded-xl uppercase tracking-wider transition-all shadow-sm hover:shadow-md cursor-pointer flex items-center gap-2"
                >
                  <Bike className="w-4 h-4" />
                  <span>Ver Catálogo de Scooters</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-500 font-bold px-1">
                  <span>PRODUTO E QUANTIDADE</span>
                  <button
                    type="button"
                    onClick={clearCart}
                    className="text-slate-400 hover:text-red-600 transition-colors text-[11px] font-semibold underline cursor-pointer"
                  >
                    Esvaziar carrinho
                  </button>
                </div>

                {items.map((item) => {
                  const imageSrc = item.imagem || getModelImage(item.nome_produto);

                  return (
                    <div
                      key={item.id}
                      className="bg-white rounded-2xl p-3.5 border border-slate-200/90 shadow-2xs hover:border-emerald-500/40 transition-all flex flex-col gap-3"
                    >
                      <div className="flex items-start gap-3">
                        {/* Imagem do Produto */}
                        <div className="w-20 h-20 bg-slate-50 rounded-xl border border-slate-100 p-1.5 shrink-0 flex items-center justify-center overflow-hidden">
                          <img
                            src={imageSrc}
                            alt={item.nome_produto}
                            referrerPolicy="no-referrer"
                            className="max-h-full max-w-full object-contain filter drop-shadow-xs"
                          />
                        </div>

                        {/* Dados Principais: Nome, Cor, Potência e Preço Unitário */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-1">
                            <h4 className="text-sm font-black text-slate-900 truncate">
                              {item.nome_produto}
                            </h4>
                            <button
                              type="button"
                              onClick={() => removeFromCart(item.id)}
                              className="text-slate-400 hover:text-red-500 p-1 rounded-lg hover:bg-red-50 transition-colors cursor-pointer shrink-0"
                              title="Remover produto do carrinho"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          <div className="flex flex-wrap items-center gap-1.5 mt-1 text-[11px] text-slate-500">
                            {item.potencia && (
                              <span className="bg-slate-100 text-slate-700 font-bold px-1.5 py-0.2 rounded">
                                {item.potencia}
                              </span>
                            )}
                            {item.cor && (
                              <span className="bg-emerald-50 text-emerald-800 font-semibold px-1.5 py-0.2 rounded border border-emerald-100">
                                Cor: {item.cor}
                              </span>
                            )}
                          </div>

                          <div className="mt-1 text-xs text-slate-500 font-medium">
                            Unitário: <span className="text-slate-700 font-bold">{formatCurrency(item.preco_unitario)}</span>
                          </div>

                          {typeof item.estoque === 'number' && (
                            <div className="text-[10px] text-emerald-700 font-semibold mt-0.5">
                              Estoque disponível: {item.estoque} un.
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Linha de Quantidade e Subtotal (Regras 2, 3, 4, 5, 6) */}
                      <div className="flex items-center justify-between pt-2.5 border-t border-slate-100 bg-stone-50/50 -mx-3.5 -mb-3.5 p-3 rounded-b-2xl">
                        {/* Controles de Quantidade: Botão "–", Número da Quantidade Atual, Botão "+" */}
                        <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl p-1 shadow-2xs">
                          {/* Botão "–": diminui em 1, nunca menor que 1 */}
                          <button
                            type="button"
                            onClick={() => handleDecrement(item.id)}
                            disabled={item.quantidade <= 1}
                            className={`w-7 h-7 rounded-lg flex items-center justify-center font-black transition-colors ${
                              item.quantidade <= 1
                                ? 'text-slate-300 bg-slate-50 cursor-not-allowed'
                                : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900 active:scale-95 cursor-pointer'
                            }`}
                            title="Diminuir quantidade"
                          >
                            <Minus className="w-3.5 h-3.5 stroke-[2.5]" />
                          </button>

                          {/* Número da Quantidade Atual */}
                          <span 
                            className="w-8 text-center text-xs sm:text-sm font-black text-slate-900 select-none"
                            title={`Quantidade atual: ${item.quantidade}`}
                          >
                            {item.quantidade}
                          </span>

                          {/* Botão "+": aumenta em 1 */}
                          <button
                            type="button"
                            onClick={() => handleIncrement(item.id, item.nome_produto)}
                            disabled={typeof item.estoque === 'number' && item.quantidade >= item.estoque}
                            className={`w-7 h-7 rounded-lg flex items-center justify-center font-black transition-colors ${
                              typeof item.estoque === 'number' && item.quantidade >= item.estoque
                                ? 'text-slate-300 bg-slate-50 cursor-not-allowed'
                                : 'text-white bg-[#00a650] hover:bg-[#008f43] active:scale-95 shadow-2xs cursor-pointer'
                            }`}
                            title="Aumentar quantidade"
                          >
                            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                          </button>
                        </div>

                        {/* Subtotal do Item: preço do produto × quantidade */}
                        <div className="text-right">
                          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                            Subtotal ({item.quantidade}x)
                          </span>
                          <span className="text-sm sm:text-base font-black text-[#008f43] tracking-tight">
                            {formatCurrency(item.subtotal)}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer with Totals and Checkout actions */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 bg-stone-50 border-t border-slate-200 space-y-3.5">
              {/* Summary Calculation */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-slate-600">
                  <span>Quantidade Total de Itens:</span>
                  <span className="font-black text-slate-900 bg-white px-2.5 py-0.5 rounded-md border border-slate-200">
                    {totalQuantity} un.
                  </span>
                </div>

                <div className="flex items-baseline justify-between pt-1 border-t border-slate-200/80">
                  <span className="text-sm font-bold text-slate-800 uppercase tracking-tight">
                    Total do Carrinho:
                  </span>
                  <span className="text-xl sm:text-2xl font-black text-[#008f43] tracking-tight">
                    {formatCurrency(totalAmount)}
                  </span>
                </div>
              </div>

              {/* Botões de Ação */}
              <div className="space-y-2 pt-1">
                {onStartCheckout && (
                  <button
                    type="button"
                    id="btn-iniciar-checkout-carrinho"
                    onClick={() => {
                      setIsCartOpen(false);
                      onStartCheckout(items);
                    }}
                    className="w-full py-4 bg-gradient-to-r from-[#00a650] to-[#008f43] hover:from-[#008f43] hover:to-[#007335] text-white font-black text-sm sm:text-base rounded-xl shadow-md hover:shadow-lg active:scale-[0.99] transition-all flex items-center justify-center gap-2 uppercase tracking-wide cursor-pointer"
                  >
                    <span>CONTINUAR PARA O CHECKOUT</span>
                    <ArrowRight className="w-5 h-5 text-yellow-300" />
                  </button>
                )}

                <button
                  type="button"
                  id="btn-finalizar-carrinho-whatsapp"
                  onClick={handleSendWhatsapp}
                  className="w-full py-3.5 bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs sm:text-sm rounded-xl shadow-sm hover:shadow-md active:scale-[0.99] transition-all flex items-center justify-center gap-2.5 uppercase tracking-wide cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 fill-white stroke-none" />
                  <span>OU FINALIZAR PELO WHATSAPP</span>
                </button>

                <p className="text-[11px] text-slate-500 text-center font-medium">
                  Atendimento direto e personalizado via WhatsApp oficial Vestcasa.
                </p>
              </div>

              {/* Trust Badge */}
              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#00a650]" />
                <span>Compra segura • Garantia oficial Clube Vestcasa</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
