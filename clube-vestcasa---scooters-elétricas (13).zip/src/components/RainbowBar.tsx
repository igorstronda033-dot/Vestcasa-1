import React from 'react';

interface RainbowBarProps {
  className?: string;
  height?: string;
  rounded?: string;
}

export const RAINBOW_COLORS = [
  '#f5b300', // Amarelo
  '#ff7828', // Laranja
  '#e53935', // Vermelho
  '#e91e63', // Rosa / Pink
  '#7c3aed', // Roxo / Violeta
  '#1d4ed8', // Azul Escuro
  '#00b4d8', // Ciano / Azul Claro
  '#00c853', // Verde Vivo
];

export const RainbowBar: React.FC<RainbowBarProps> = ({ 
  className = '', 
  height = 'h-2', 
  rounded = 'rounded-none' 
}) => {
  return (
    <div className={`w-full flex overflow-hidden ${height} ${rounded} ${className}`}>
      {RAINBOW_COLORS.map((color, index) => (
        <div 
          key={index} 
          className="flex-1 h-full" 
          style={{ backgroundColor: color }} 
        />
      ))}
    </div>
  );
};
