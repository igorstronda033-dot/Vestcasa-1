export type PaymentStatus = 
  | 'Pendente' 
  | 'Cliente informou pagamento' 
  | 'Pago' 
  | 'Cancelado';

export interface CartItem {
  id: string;
  id_produto: string;
  nome_produto: string;
  preco_unitario: number;
  quantidade: number;
  subtotal: number;
  cor?: string | null;
  imagem?: string | null;
  potencia?: string | null;
  estoque?: number | null;
}

export interface Pedido {
  id: string;
  codigo: string;
  nome_cliente: string;
  cpf?: string | null;
  produto: string;
  cor?: string | null;
  valor: number;
  observacao?: string | null;
  status_pagamento: PaymentStatus;
  imagem_url?: string | null;
  itens?: CartItem[] | null;
  frete?: 'sem_frete' | 'com_frete' | null;
  created_at: string;
  updated_at?: string;

  // Campos adicionais de frete e entrega
  telefone?: string | null;
  cep?: string | null;
  endereco?: string | null;
  numero?: string | null;
  complemento?: string | null;
  bairro?: string | null;
  cidade?: string | null;
  estado?: string | null;
  valor_produto?: number | null;
  valor_desconto?: number | null;
  valor_frete?: number | null;
  valor_total?: number | null;
  cupom_codigo?: string | null;
  cupom_porcentagem?: number | null;
  forma_pagamento?: string | null;
  prazo_frete?: string | null;
  nome_regiao_frete?: string | null;
  tipo_entrega?: 'retirada' | 'entrega' | null;
}

export interface CouponConfig {
  codigo: string;
  porcentagem: number;
  ativo: boolean;
  descricao?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface ShippingRule {
  id: string;
  nome_regiao: string;
  estado: string; // Ex: 'SP', 'RJ', 'MG', ou 'TODOS'
  cidade?: string | null;
  cep_inicio: string; // Ex: '01000-000'
  cep_fim: string; // Ex: '05999-999'
  valor_frete: number;
  prazo_estimado: string; // Ex: '3 a 5 dias úteis'
  ativo: boolean;
  frete_gratis: boolean;
  modelos_especificos?: string[] | null; // IDs dos modelos ou vazio/null para todas
  created_at?: string;
  updated_at?: string;
}

export interface ScooterModel {
  id: string;
  name: string;
  power: string;
  description: string;
  price: number;
  oldPrice?: number;
  tag: string;
  badge?: string;
  colors: string[];
  image: string;
  estoque?: number;
  autonomia?: string;
  velocidadeMaxima?: string;
  tempoCarga?: string;
  pesoSuportado?: string;
  freios?: string;
  bateria?: string;
  features?: string[];
  specs?: Record<string, string>;
  pixQrCodeSemFrete?: string;
  pixCopiaColaSemFrete?: string;
  pixQrCodeComFrete?: string;
  pixCopiaColaComFrete?: string;
}
