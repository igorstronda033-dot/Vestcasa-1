import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import { CartItem } from '../types';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

interface AddToCartParams {
  id: string;
  name: string;
  price: number;
  power?: string;
  image?: string;
  color?: string;
  estoque?: number;
}

interface CartContextType {
  items: CartItem[];
  totalQuantity: number;
  totalAmount: number;
  isCartOpen: boolean;
  setIsCartOpen: (isOpen: boolean) => void;
  addToCart: (product: AddToCartParams, qty?: number) => { success: boolean; message: string };
  incrementQuantity: (itemId: string) => { success: boolean; message?: string };
  decrementQuantity: (itemId: string) => void;
  updateQuantity: (itemId: string, qty: number) => { success: boolean; message?: string };
  removeFromCart: (itemId: string) => void;
  clearCart: () => void;
  lastAddedItem: CartItem | null;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const CART_STORAGE_KEY = 'vestcasa_carrinho_itens_v1';

export const CartProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(CART_STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return parsed.map((item) => {
              const qty = Math.max(1, Number(item.quantidade) || 1);
              const price = Number(item.preco_unitario) || 0;
              return {
                ...item,
                quantidade: qty,
                preco_unitario: price,
                subtotal: price * qty,
              };
            });
          }
        }
      } catch (e) {
        console.warn('Erro ao carregar carrinho local:', e);
      }
    }
    return [];
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [lastAddedItem, setLastAddedItem] = useState<CartItem | null>(null);
  const [stockMap, setStockMap] = useState<Record<string, number>>({});

  // Salvar no localStorage sempre que os itens mudarem
  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch (e) {
      console.warn('Erro ao salvar carrinho no localStorage:', e);
    }
  }, [items]);

  // Se Supabase estiver conectado, buscar estoque atualizado da tabela 'produtos' (se existir)
  useEffect(() => {
    if (!isSupabaseConfigured()) return;

    const fetchStocks = async () => {
      try {
        const { data, error } = await supabase
          .from('produtos')
          .select('id, estoque');

        if (!error && Array.isArray(data)) {
          const map: Record<string, number> = {};
          data.forEach((p: any) => {
            if (p.id && typeof p.estoque === 'number') {
              map[p.id.toLowerCase()] = p.estoque;
            }
          });
          setStockMap(map);
        }
      } catch (err) {
        // Tabela de produtos pode não existir ainda, sem problemas
      }
    };

    fetchStocks();
  }, []);

  /**
   * Cálculo automático de:
   * - Quantidade total de itens no carrinho
   * - Valor total do carrinho
   */
  const { totalQuantity, totalAmount } = useMemo(() => {
    let qtySum = 0;
    let amountSum = 0;

    for (const item of items) {
      const q = Math.max(1, item.quantidade);
      const sub = item.preco_unitario * q;
      qtySum += q;
      amountSum += sub;
    }

    return { totalQuantity: qtySum, totalAmount: amountSum };
  }, [items]);

  /**
   * Obtém o estoque disponível para um determinado produto
   */
  const getProductStock = (productId: string, defaultEstoque?: number): number | undefined => {
    const fromMap = stockMap[productId.toLowerCase()];
    if (typeof fromMap === 'number') {
      return fromMap;
    }
    if (typeof defaultEstoque === 'number') {
      return defaultEstoque;
    }
    return undefined; // Sem limite estrito cadastrado
  };

  /**
   * Regra 1 e 7:
   * - Ao adicionar, entra com quantidade 1.
   * - Se já existir no carrinho (mesmo id_produto e cor), incrementa a quantidade do existente sem duplicar.
   * - Regra 9: Respeita o estoque disponível se cadastrado.
   */
  const addToCart = (product: AddToCartParams, initialQty: number = 1): { success: boolean; message: string } => {
    const cleanColor = product.color?.trim() || null;
    const itemUniqueKey = `${product.id}-${cleanColor || 'padrao'}`;
    const stockLimit = getProductStock(product.id, product.estoque);

    const existingIndex = items.findIndex((it) => it.id === itemUniqueKey);

    if (existingIndex >= 0) {
      const currentItem = items[existingIndex];
      const proposedQty = currentItem.quantidade + Math.max(1, initialQty);

      if (typeof stockLimit === 'number' && proposedQty > stockLimit) {
        return {
          success: false,
          message: `Desculpe, só temos ${stockLimit} unidades da ${product.name} em estoque no momento.`,
        };
      }

      const updatedItems = [...items];
      const newQty = proposedQty;
      const subtotal = currentItem.preco_unitario * newQty;

      updatedItems[existingIndex] = {
        ...currentItem,
        quantidade: newQty,
        subtotal,
        estoque: stockLimit,
      };

      setItems(updatedItems);
      setLastAddedItem(updatedItems[existingIndex]);
      return {
        success: true,
        message: `Quantidade de ${product.name} aumentada para ${newQty} no carrinho!`,
      };
    } else {
      const qty = Math.max(1, initialQty);
      if (typeof stockLimit === 'number' && qty > stockLimit) {
        return {
          success: false,
          message: `Desculpe, o estoque disponível para a ${product.name} é de ${stockLimit} unidades.`,
        };
      }

      const newItem: CartItem = {
        id: itemUniqueKey,
        id_produto: product.id,
        nome_produto: product.name,
        preco_unitario: product.price,
        quantidade: qty,
        subtotal: product.price * qty,
        cor: cleanColor,
        imagem: product.image,
        potencia: product.power,
        estoque: stockLimit,
      };

      setItems((prev) => [...prev, newItem]);
      setLastAddedItem(newItem);
      return {
        success: true,
        message: `${product.name} adicionado ao carrinho com sucesso!`,
      };
    }
  };

  /**
   * Regra 3: Botão "+" aumenta a quantidade em 1.
   * Regra 9: Não permite ultrapassar o estoque se houver limite.
   */
  const incrementQuantity = (itemId: string): { success: boolean; message?: string } => {
    const item = items.find((i) => i.id === itemId);
    if (!item) return { success: false };

    const stockLimit = getProductStock(item.id_produto, item.estoque ?? undefined);
    const newQty = item.quantidade + 1;

    if (typeof stockLimit === 'number' && newQty > stockLimit) {
      return {
        success: false,
        message: `Estoque máximo atingido (${stockLimit} un. disponíveis)`,
      };
    }

    setItems((prev) =>
      prev.map((i) => {
        if (i.id === itemId) {
          return {
            ...i,
            quantidade: newQty,
            subtotal: i.preco_unitario * newQty,
          };
        }
        return i;
      })
    );

    return { success: true };
  };

  /**
   * Regra 4: Botão "–" diminui a quantidade em 1, mas NUNCA deixa menor que 1.
   */
  const decrementQuantity = (itemId: string) => {
    setItems((prev) =>
      prev.map((i) => {
        if (i.id === itemId) {
          const newQty = Math.max(1, i.quantidade - 1);
          return {
            ...i,
            quantidade: newQty,
            subtotal: i.preco_unitario * newQty,
          };
        }
        return i;
      })
    );
  };

  /**
   * Atualização direta de quantidade (caso use input numérico ou slider)
   */
  const updateQuantity = (itemId: string, requestedQty: number): { success: boolean; message?: string } => {
    const item = items.find((i) => i.id === itemId);
    if (!item) return { success: false };

    const stockLimit = getProductStock(item.id_produto, item.estoque ?? undefined);
    const safeQty = Math.max(1, requestedQty);

    if (typeof stockLimit === 'number' && safeQty > stockLimit) {
      return {
        success: false,
        message: `Estoque máximo de ${stockLimit} unidades para este produto.`,
      };
    }

    setItems((prev) =>
      prev.map((i) => {
        if (i.id === itemId) {
          return {
            ...i,
            quantidade: safeQty,
            subtotal: i.preco_unitario * safeQty,
          };
        }
        return i;
      })
    );

    return { success: true };
  };

  /**
   * Botão para remover o produto do carrinho
   */
  const removeFromCart = (itemId: string) => {
    setItems((prev) => prev.filter((i) => i.id !== itemId));
  };

  /**
   * Limpar carrinho
   */
  const clearCart = () => {
    setItems([]);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        totalQuantity,
        totalAmount,
        isCartOpen,
        setIsCartOpen,
        addToCart,
        incrementQuantity,
        decrementQuantity,
        updateQuantity,
        removeFromCart,
        clearCart,
        lastAddedItem,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = (): CartContextType => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart deve ser utilizado dentro de um CartProvider');
  }
  return context;
};
