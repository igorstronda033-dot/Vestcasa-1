import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { TrustProofSection } from './components/TrustProofSection';
import { FeaturedCarousel } from './components/FeaturedCarousel';
import { OrderConsultation } from './components/OrderConsultation';
import { ScooterCatalog } from './components/ScooterCatalog';
import { WhyBuyVestcasa } from './components/WhyBuyVestcasa';
import { FaqSection } from './components/FaqSection';
import { FooterTrust } from './components/FooterTrust';
import { PaymentModal } from './components/PaymentModal';
import { CartDrawer } from './components/CartDrawer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CheckoutModal, CheckoutScooterSelection } from './components/CheckoutModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { AdminLogin } from './components/admin/AdminLogin';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { Pedido, ScooterModel, CartItem } from './types';
import { supabase, isSupabaseConfigured } from './lib/supabase';
import { listAllOrders } from './services/orderService';
import { CartProvider } from './context/CartContext';
import { getScooterModels } from './services/scooterService';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'cliente' | 'catalogo' | 'admin'>('cliente');
  const [selectedOrderForPayment, setSelectedOrderForPayment] = useState<Pedido | null>(null);
  const [selectedDetailModel, setSelectedDetailModel] = useState<ScooterModel | null>(null);
  const [checkoutSelection, setCheckoutSelection] = useState<CheckoutScooterSelection | null>(null);
  
  // Auth state for Supabase
  const [adminUser, setAdminUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Default code from URL (e.g. ?codigo=SCO4821)
  const [defaultSearchCode, setDefaultSearchCode] = useState<string>('');
  const [pendingCount, setPendingCount] = useState<number>(0);

  const allModels = getScooterModels();

  useEffect(() => {
    // Check URL parameters for direct link to order or admin route
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      const codeFromUrl = urlParams.get('codigo') || urlParams.get('order');
      if (codeFromUrl) {
        setDefaultSearchCode(codeFromUrl);
        setCurrentTab('cliente');
      }

      if (window.location.pathname === '/admin' || window.location.hash === '#admin') {
        setCurrentTab('admin');
      }
    }

    // Check local admin session
    const localAdminLogged = localStorage.getItem('vestcasa_admin_logged') === 'true';
    if (localAdminLogged) {
      setAdminUser({ id: 'admin', email: 'ADMIN2026@i', role: 'admin' });
      setAuthLoading(false);
    }

    // Check Supabase Auth state
    if (isSupabaseConfigured()) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        if (session?.user) {
          setAdminUser(session.user);
        }
        setAuthLoading(false);
      });

      const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
        if (session?.user) {
          setAdminUser(session.user);
        }
        setAuthLoading(false);
      });

      // Fetch pending confirmation counter for Navbar
      listAllOrders().then(({ data }) => {
        if (data) {
          const awaiting = data.filter((p) => p.status_pagamento === 'Cliente informou pagamento').length;
          setPendingCount(awaiting);
        }
      });

      return () => {
        subscription.unsubscribe();
      };
    } else {
      setAuthLoading(false);
    }
  }, []);

  const handleLogout = async () => {
    localStorage.removeItem('vestcasa_admin_logged');
    localStorage.removeItem('vestcasa_admin_user');
    if (isSupabaseConfigured()) {
      try {
        await supabase.auth.signOut();
      } catch (e) {
        console.error('Error signing out from supabase:', e);
      }
    }
    setAdminUser(null);
  };

  const scrollToConsultation = () => {
    setCurrentTab('cliente');
    setTimeout(() => {
      const el = document.getElementById('input-codigo-pedido') || document.getElementById('secao-consulta');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.focus();
      }
    }, 100);
  };

  const scrollToCatalog = () => {
    setCurrentTab('cliente');
    setTimeout(() => {
      const el = document.getElementById('secao-catalogo');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const handleStartCheckout = (model: ScooterModel, color?: string, quantity?: number) => {
    setCheckoutSelection({
      model,
      color: color || model.colors[0] || 'Vermelho',
      quantity: quantity || 1,
      price: model.price,
    });
  };

  const handleStartCheckoutFromCart = (cartItems: CartItem[]) => {
    if (cartItems.length === 0) return;
    const firstItem = cartItems[0];
    const matchedModel = allModels.find((m) => m.id === firstItem.id_produto) || {
      id: firstItem.id_produto,
      name: firstItem.nome_produto,
      price: firstItem.preco_unitario,
      power: firstItem.potencia || '1000W',
      image: firstItem.imagem || allModels[0].image,
      colors: [firstItem.cor || 'Vermelho'],
      description: firstItem.nome_produto,
      speed: '32 km/h',
      range: '45-60 km',
      chargeTime: '4-6 horas',
      battery: 'Lítio 48V 15Ah',
      estoque: firstItem.estoque ?? 10,
      features: ['Garantia Oficial Vestcasa']
    };

    setCheckoutSelection({
      model: matchedModel,
      color: firstItem.cor || matchedModel.colors[0] || 'Vermelho',
      quantity: firstItem.quantidade || 1,
      price: firstItem.preco_unitario,
      items: cartItems
    });
  };

  return (
    <CartProvider>
      <div className="min-h-screen flex flex-col bg-stone-50 text-slate-900 selection:bg-emerald-500 selection:text-white font-sans">
        {/* Header Profissional com barra de benefícios e menu responsivo */}
        <Navbar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          pendingCount={pendingCount}
          onSearchClick={scrollToConsultation}
        />

        {/* Conteúdo Principal */}
        <main className="flex-1">
          {currentTab === 'cliente' && (
            <div className="animate-in fade-in duration-200">
              {/* 1. Banner Principal de Grande Impacto */}
              <HeroBanner 
                onConsultarClick={scrollToConsultation}
                onCatalogoClick={scrollToCatalog}
              />

              {/* 2. Prova de Confiança Visual */}
              <TrustProofSection />

              {/* 3. Seção de Destaques (Carrossel com Swipe Mobile) */}
              <FeaturedCarousel
                models={allModels}
                onOpenDetails={(model) => setSelectedDetailModel(model)}
                onBuyNow={(model) => handleStartCheckout(model)}
              />

              {/* 4. Portal Oficial de Consulta de Pedidos com Código */}
              <div className="py-8 bg-stone-100/60 border-y border-slate-200/80">
                <OrderConsultation
                  onOpenPayment={(pedido) => setSelectedOrderForPayment(pedido)}
                  onAdminAccess={() => {
                    setAdminUser({ id: 'admin', email: 'ADMIN2026@i', role: 'admin' });
                    setCurrentTab('admin');
                  }}
                  defaultCode={defaultSearchCode}
                />
              </div>

              {/* 5. Catálogo Completo com Cards Modernos e Estúdio de Cores */}
              <div id="secao-catalogo" className="bg-white">
                <ScooterCatalog 
                  onNavigateToConsultation={scrollToConsultation}
                  onOpenProductModal={(model) => setSelectedDetailModel(model)}
                  onBuyNow={(model, color) => handleStartCheckout(model, color)}
                />
              </div>

              {/* 6. Seção "Por que Comprar na Vestcasa?" */}
              <WhyBuyVestcasa />

              {/* 7. Perguntas Frequentes (FAQ Accordion) */}
              <FaqSection />

              {/* 8. Rodapé Profissional em Colunas */}
              <FooterTrust
                onClientClick={scrollToConsultation}
                onCatalogClick={scrollToCatalog}
                onAdminClick={() => setCurrentTab('admin')}
              />
            </div>
          )}

          {currentTab === 'catalogo' && (
            <div className="animate-in fade-in duration-200">
              <FeaturedCarousel
                models={allModels}
                onOpenDetails={(model) => setSelectedDetailModel(model)}
                onBuyNow={(model) => handleStartCheckout(model)}
              />
              <div className="bg-white">
                <ScooterCatalog 
                  onNavigateToConsultation={() => {
                    setCurrentTab('cliente');
                    scrollToConsultation();
                  }}
                  onOpenProductModal={(model) => setSelectedDetailModel(model)}
                  onBuyNow={(model, color) => handleStartCheckout(model, color)}
                />
              </div>
              <WhyBuyVestcasa />
              <FaqSection />
              <FooterTrust
                onClientClick={() => setCurrentTab('cliente')}
                onCatalogClick={scrollToCatalog}
                onAdminClick={() => setCurrentTab('admin')}
              />
            </div>
          )}

          {currentTab === 'admin' && (
            <div className="animate-in fade-in duration-200">
              {adminUser ? (
                <AdminDashboard
                  onLogout={handleLogout}
                  onViewClientArea={() => setCurrentTab('cliente')}
                />
              ) : (
                <AdminLogin
                  onSuccess={(user) => {
                    setAdminUser(user || { id: 'admin', email: 'ADMIN2026@i', role: 'admin' });
                  }}
                  onBackToClient={() => setCurrentTab('cliente')}
                />
              )}
            </div>
          )}
        </main>

        {/* Modal Profissional de Detalhes do Produto */}
        {selectedDetailModel && (
          <ProductDetailModal
            model={selectedDetailModel}
            allModels={allModels}
            onClose={() => setSelectedDetailModel(null)}
            onSelectModel={(model) => setSelectedDetailModel(model)}
            onBuyNow={(model, color, qty) => handleStartCheckout(model, color, qty)}
          />
        )}

        {/* Botão Flutuante do WhatsApp (Canto Inferior Direito) */}
        <FloatingWhatsApp />

        {/* Carrinho de Compras Drawer */}
        <CartDrawer
          onNavigateToConsultation={(orderCode) => {
            setDefaultSearchCode(orderCode);
            setCurrentTab('cliente');
            scrollToConsultation();
          }}
          onExploreCatalog={scrollToCatalog}
          onStartCheckout={handleStartCheckoutFromCart}
        />

        {/* Modal de Pagamento Seguro com QR Code e Chave PIX (Consulta / Link direto) */}
        {selectedOrderForPayment && (
          <PaymentModal
            pedido={selectedOrderForPayment}
            onClose={() => setSelectedOrderForPayment(null)}
            onPaymentReported={() => {
              // Notified
            }}
          />
        )}

        {/* Novo Fluxo de Checkout em 4 Passos */}
        {checkoutSelection && (
          <CheckoutModal
            selection={checkoutSelection}
            onClose={() => setCheckoutSelection(null)}
            onOrderCreated={(order) => {
              setDefaultSearchCode(order.codigo);
            }}
          />
        )}
      </div>
    </CartProvider>
  );
}
